# WABEK WhatsApp — Enterprise WHMCS Addon v3.2
### By WEBEK LTD · [waabek.com](https://waabek.com)

Enterprise-grade WhatsApp automation for WHMCS — Notifications, Campaigns, OTP, Abandoned Cart Recovery, Shared Inbox, and more.

---

## Requirements

| Component | Minimum |
|---|---|
| WHMCS | 8.10+ (tested on 9.0.4) |
| PHP | 8.1+ |
| MySQL | 5.7+ / MariaDB 10.3+ |

## Compatible Themes
Six · Twenty-One · Lagom · Lagom 2 · ClientX

---

## Installation

### 1. Upload Files
Upload to your WHMCS root, preserving directory structure:
```
modules/addons/wabek/       → full folder
includes/hooks/wabek_notifications.php
```

### 2. Activate
**WHMCS Admin → Setup → Addon Modules → WABEK WhatsApp → Activate**

All admin roles are automatically granted access on activation.

### 3. Configure API
**Addons → WABEK WhatsApp → Settings → API**
- **API Key** — from [waabek.com/dashboard/api-keys](https://waabek.com/dashboard/api-keys)
- **Instance ID** — from Dashboard → WhatsApp
- **Default Country Code** — e.g. `90` Turkey, `20` Egypt, `44` UK

### 4. Set Up Cron
Add to server crontab:
```bash
* * * * * php /path/to/whmcs/modules/addons/wabek/cron/queue_processor.php >> /dev/null 2>&1
```
Or use WHMCS → **Setup → Automation Settings → Custom Cron Jobs**

The cron handles:
- Message queue processing (with exponential backoff)
- Scheduled campaigns
- Abandoned cart reminders
- Daily statistics aggregation
- Webhook auto-retry

### 5. Set Webhook URL
In WABEK Dashboard → Webhooks, set:
```
https://your-whmcs.com/includes/hooks/wabek_notifications.php?wabek_webhook=1
```

---

## Admin Features (15 pages)

| Page | Description |
|---|---|
| **Dashboard** | Connection status, stats, 30-day chart, API quota |
| **Message Logs** | Full log with search, filters, CSV export |
| **Inbox** | Shared WhatsApp inbox, reply, assign, internal notes |
| **Analytics** | Delivery/read rates, top events, line chart |
| **Templates** | Create/edit/preview with version history |
| **Campaigns** | Bulk send with segmentation + CSV import |
| **Queue** | Live queue + Dead Letter Queue + retry |
| **OTP Logs** | OTP verification history |
| **Webhooks** | Activity log, inspector, replay, test tool |
| **Settings** | Full config with test notification per event |
| **Send Message** | Manual send with media attachment |
| **Media Library** | Upload & manage images/PDF/audio/video |
| **Permissions** | Per-role access control |
| **Diagnostics** | Connection debug + phone debug tool |
| **Abandoned Carts** | Recovery stats and list |

---

## Client Area Features

Accessible at `index.php?m=wabek`:

- **Dashboard** — WhatsApp status, stats, recent activity
- **Messages** — Notification history
- **Conversations** — Incoming messages with reply
- **Settings** — Number override, opt-in/out
- **OTP Verification** — Verify WhatsApp number
- WhatsApp icon in nav with unread badge
- One-click unsubscribe via `{{unsubscribe_url}}`

---

## Admin Client Profile Widget

Appears automatically on every client's profile page:
- Current WhatsApp number + source
- Quick Send form
- **WABEK WhatsApp Number** override field
- Opt-out toggle
- Recent messages (last 5)

---

## WHMCS Events (35 hooks)

**Billing:** InvoiceCreation, InvoicePaid, InvoicePaymentReminder, OverdueInvoice, OrderPaid, QuoteCreated, QuoteAccepted, AffiliateWithdrawal

**Services:** AfterModuleCreate, AfterModuleSuspend, AfterModuleUnsuspend, AfterModuleTerminate

**Support:** TicketOpen, TicketReply, TicketClose

**Domains:** DomainRegistration, DomainRenewal, DomainExpiryNotice, DomainTransferCompleted, AfterRegistrarRegistration, AfterRegistrarTransfer

**Clients:** ClientAdd, AfterClientPasswordChange, EmailVerification

**Admin:** AdminLogin, AdminLoginFailure (activity log only)

---

## Database Tables (20)

`mod_wabek_queue` · `mod_wabek_messages` · `mod_wabek_templates` · `mod_wabek_template_versions` · `mod_wabek_campaigns` · `mod_wabek_campaign_recipients` · `mod_wabek_campaign_events` · `mod_wabek_otp` · `mod_wabek_webhooks` · `mod_wabek_abandoned_carts` · `mod_wabek_statistics` · `mod_wabek_activity_log` · `mod_wabek_audit_log` · `mod_wabek_optout` · `mod_wabek_conversations` · `mod_wabek_incoming_messages` · `mod_wabek_media` · `mod_wabek_permission_map` · `mod_wabek_client_settings` · `mod_wabek_migrations`

---

## Phone Number Resolution (priority order)

1. `mod_wabek_client_settings.whatsapp_number` — WABEK override set by admin
2. `wabek_phone_custom_field` config — custom field name
3. WHMCS custom field (if `phone_field=customfield`)
4. `tblclients.phonenumber` + `tblcountries` dial code lookup
5. `localAPI('GetClientsDetails')` fallback

Normalised to E.164 digits (e.g. `905446731942`).

---

## White Label Mode

**Settings → White Label:**
- Company/brand name
- Logo URL
- Footer text
- Primary color

Hides WABEK branding for resellers.

---

## Security

- CSRF protection on all admin forms
- HMAC-SHA256 webhook signature verification
- Phone validation (blocks placeholder numbers)
- Per-role permission control
- API key masked in exports
- One-click unsubscribe with secure tokens

---

## Phone Debug Tool

Upload `modules/addons/wabek/tools/phone_debug.php` and access:
```
https://your-whmcs.com/modules/addons/wabek/tools/phone_debug.php?client_id=2
```
Shows every lookup attempt and normalization step. **Delete after use.**

---

## Support

- 📧 support@waabek.com
- 🌐 [waabek.com](https://waabek.com)
- 🇬🇧 +44 7878 704062
- 🇹🇷 +90 541 847 79 76

---

## CHANGELOG

### v3.2.0
- Added: Media Library (upload/manage images/PDF/audio/video)
- Added: White Label mode (custom brand/logo/color)
- Added: Permissions Manager (per-role access control)
- Added: Abandoned Cart admin page with analytics
- Added: Campaign CSV import (non-WHMCS contacts)
- Added: Test notification button per event in Settings
- Added: Admin failure email alerts
- Added: One-click unsubscribe links
- Added: API quota tracker on dashboard
- Added: Template version history + restore
- Added: Conversation assignment + internal notes
- Added: Media attachment in Send + Campaigns
- Added: Webhook auto-retry
- Fixed: Phone resolution (tblcountries dial code lookup)
- Fixed: WHMCS theme compatibility CSS

### v3.1.0
- Added: Shared Inbox with chat bubbles + reply
- Added: Client Area full module (5 pages)
- Added: Admin Client Profile Widget
- Added: Diagnostics + Phone Debug Tool
- Added: Analytics page with charts
- Added: Webhook Center (inspector/replay/test)
- Added: Dead Letter Queue + exponential backoff
- Fixed: CampaignService string→int type error
- Fixed: 000000000000 dummy phone removed

### v3.0.0
- Initial enterprise release

---

WEBEK LTD · Company No. 16326894 · 71-75 Shelton Street, London WC2H 9JQ

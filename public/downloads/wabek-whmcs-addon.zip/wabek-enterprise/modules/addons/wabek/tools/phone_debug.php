<?php
/**
 * WABEK Phone Debug - shows exactly what's in DB and what PhoneHelper does
 * DELETE AFTER USE
 */

$paths = [dirname(__DIR__,5).'/init.php', dirname(__DIR__,4).'/init.php', dirname(__DIR__,3).'/init.php'];
foreach ($paths as $p) { if (file_exists($p)) { require_once $p; break; } }
if (!defined('WHMCS')) die('Cannot find WHMCS init.php');
if (empty($_SESSION['adminid'])) die('Admin login required');

require_once dirname(__DIR__).'/src/Bootstrap/Autoloader.php';
\Wabek\Bootstrap\Autoloader::register(dirname(__DIR__).'/src');
\Wabek\Bootstrap\App::boot(dirname(__DIR__));

use WHMCS\Database\Capsule;

$clientId = (int)($_GET['client_id'] ?? 2);
header('Content-Type: text/html; charset=utf-8');
?><!DOCTYPE html><html><head><meta charset="UTF-8"><title>Phone Debug</title>
<style>
body{font-family:monospace;background:#0F172A;color:#E2E8F0;padding:20px;margin:0}
h2{color:#22D366;margin:20px 0 8px}
table{border-collapse:collapse;width:100%;margin-bottom:16px}
td,th{padding:6px 12px;border:1px solid #334155;text-align:left}
th{background:#1E293B;color:#94A3B8;width:200px}
.ok{color:#22D366}.err{color:#F87171}.warn{color:#FBBF24}
pre{background:#1E293B;padding:12px;border-radius:6px;color:#22D366;overflow:auto}
form{margin-bottom:20px}
input[type=number]{background:#1E293B;color:#E2E8F0;border:1px solid #334155;padding:6px 10px;border-radius:4px}
button{background:#22D366;color:#000;border:none;padding:6px 16px;border-radius:4px;cursor:pointer;margin-left:8px}
</style></head><body>
<h1 style="color:#22D366">🔍 WABEK Phone Debug</h1>
<form method="get">
  Client ID: <input type="number" name="client_id" value="<?= $clientId ?>">
  <button>Debug</button>
</form>

<?php

// ── Step 1: Raw DB ──────────────────────────────────────────────────────
$client = Capsule::table('tblclients')->where('id', $clientId)->first();
if (!$client) { echo "<p class='err'>Client #$clientId not found</p>"; exit; }

echo "<h2>Step 1: Raw tblclients</h2><table>";
foreach (['id','firstname','lastname','phonenumber'] as $f) {
    $v = $client->$f ?? null;
    $color = ($v !== null && $v !== '') ? 'ok' : 'err';
    echo "<tr><th>$f</th><td class='$color'>" . htmlspecialchars((string)$v) . "</td></tr>";
}
echo "</table>";

// ── Step 2: tblcountries columns ────────────────────────────────────────
echo "<h2>Step 2: tblcountries columns</h2>";
$cols = Capsule::schema()->getColumnListing('tblcountries');
echo "<pre>" . implode(', ', $cols) . "</pre>";

// Find phone column
$phoneCol = '';
foreach (['phonecode','calling_code','phone_code','dialcode'] as $c) {
    if (in_array($c, $cols)) { $phoneCol = $c; break; }
}
echo "<p>Phone column detected: <span class='" . ($phoneCol?'ok':'err') . "'>$phoneCol</span></p>";

// ── Step 3: tblcountries lookup ──────────────────────────────────────────
$iso = '';
foreach (['countrycode','country','iso_code'] as $__col) { $__v = $client->$__col ?? null; if ($__v !== null && $__v !== '') { $iso = strtoupper(trim((string)$__v)); break; } }
echo "<h2>Step 3: tblcountries for ISO '$iso'</h2>";
if ($iso && $phoneCol) {
    $ccRow = Capsule::table('tblcountries')->where('iso', $iso)->first();
    if ($ccRow) {
        echo "<table>";
        foreach ((array)$ccRow as $k => $v) {
            $hl = in_array($k, ['phonecode','calling_code']) ? 'ok' : '';
            echo "<tr><th>$k</th><td class='$hl'>" . htmlspecialchars((string)$v) . "</td></tr>";
        }
        echo "</table>";
        $dialCode = preg_replace('/[^0-9]/', '', (string)($ccRow->$phoneCol ?? ''));
        echo "<p class='ok'>Dial code: <strong>$dialCode</strong></p>";
    } else {
        echo "<p class='err'>No row found for ISO '$iso'</p>";
        $dialCode = '';
    }
} else {
    echo "<p class='warn'>Skipped (iso='$iso', phoneCol='$phoneCol')</p>";
    $dialCode = '';
}

// ── Step 4: Hardcoded map ────────────────────────────────────────────────
echo "<h2>Step 4: Hardcoded map for '$iso'</h2>";
$hardcoded = [
    'TR'=>'90','EG'=>'20','SA'=>'966','AE'=>'971','GB'=>'44',
    'US'=>'1','CA'=>'1','AU'=>'61','DE'=>'49','FR'=>'33',
    'IN'=>'91','PK'=>'92','NG'=>'234','KE'=>'254','ZA'=>'27',
];
$hc = $hardcoded[$iso] ?? '';
echo "<p class='" . ($hc?'ok':'warn') . "'>Hardcoded: <strong>" . ($hc?:$iso.' not in map') . "</strong></p>";

// ── Step 5: PhoneHelper::getDialCodeForISO ───────────────────────────────
echo "<h2>Step 5: PhoneHelper::getDialCodeForISO('$iso')</h2>";
$result = \Wabek\Helpers\PhoneHelper::getDialCodeForISO($iso);
echo "<p class='" . ($result?'ok':'err') . "'>Result: <strong>'$result'</strong></p>";

// ── Step 6: formatPhone ──────────────────────────────────────────────────
$raw = trim((string)($client->phonenumber ?? ''));
echo "<h2>Step 6: formatPhone('$raw', cc='$result')</h2>";
$formatted = \Wabek\Helpers\PhoneHelper::formatPhone($raw, $result);
$digits_only = preg_replace('/[^\d]/', '', $raw);
echo "<table>";
echo "<tr><th>Raw stored</th><td class='warn'>$raw</td></tr>";
echo "<tr><th>Digits only</th><td>$digits_only (" . strlen($digits_only) . " digits)</td></tr>";
echo "<tr><th>cc used</th><td>$result</td></tr>";
echo "<tr><th>len <= 10?</th><td>" . (strlen($digits_only) <= 10 ? '<span class="ok">YES -> add cc</span>' : '<span class="warn">NO -> no cc added</span>') . "</td></tr>";
echo "<tr><th>Final</th><td class='" . ($formatted?'ok':'err') . "'>" . ($formatted ?: '(empty - failed)') . "</td></tr>";
echo "</table>";

// ── Step 7: Full PhoneHelper result ─────────────────────────────────────
echo "<h2>Step 7: PhoneHelper::getClientPhoneResult($clientId)</h2>";
$full = \Wabek\Helpers\PhoneHelper::getClientPhoneResult($clientId);
echo "<table>";
echo "<tr><th>valid</th><td class='" . ($full['valid']?'ok':'err') . "'>" . ($full['valid']?'TRUE':'FALSE') . "</td></tr>";
echo "<tr><th>phone</th><td class='ok'>" . ($full['phone'] ?? '(null)') . "</td></tr>";
echo "<tr><th>e164</th><td class='ok'>" . ($full['e164'] ?? '(null)') . "</td></tr>";
echo "<tr><th>source</th><td>" . htmlspecialchars($full['source'] ?? '') . "</td></tr>";
echo "<tr><th>error</th><td class='err'>" . ($full['error'] ?? '-') . "</td></tr>";
echo "</table>";

echo "<h2>Debug Attempts</h2><pre>";
foreach (($full['debug']['attempts'] ?? []) as $a) {
    echo json_encode($a, JSON_UNESCAPED_UNICODE) . "\n";
}
echo "</pre>";

echo "<h2>Full Result</h2><pre>" . htmlspecialchars(json_encode($full, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)) . "</pre>";

?>
</body></html>

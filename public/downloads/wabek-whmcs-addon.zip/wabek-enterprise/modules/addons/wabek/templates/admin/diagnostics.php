<?php
/**
 * WABEK Connection Diagnostics Page
 * @var array  $connectionStatus
 * @var array  $diagnostics
 * @var string $csrf
 */

$statusColors = [
    'connected'        => ['bg'=>'#F0FDF4','border'=>'#BBF7D0','text'=>'#15803D'],
    'no_key'           => ['bg'=>'#FEF2F2','border'=>'#FECACA','text'=>'#B91C1C'],
    'invalid_key'      => ['bg'=>'#FEF2F2','border'=>'#FECACA','text'=>'#B91C1C'],
    'unreachable'      => ['bg'=>'#FEF2F2','border'=>'#FECACA','text'=>'#B91C1C'],
    'timeout'          => ['bg'=>'#FEF2F2','border'=>'#FECACA','text'=>'#B91C1C'],
    'ssl_error'        => ['bg'=>'#FEF2F2','border'=>'#FECACA','text'=>'#B91C1C'],
    'invalid_instance' => ['bg'=>'#FEF2F2','border'=>'#FECACA','text'=>'#B91C1C'],
    'session_expired'  => ['bg'=>'#FFF7ED','border'=>'#FED7AA','text'=>'#C2410C'],
    'rate_limited'     => ['bg'=>'#FFF7ED','border'=>'#FED7AA','text'=>'#C2410C'],
    'qr_required'      => ['bg'=>'#FFFBEB','border'=>'#FDE68A','text'=>'#92400E'],
    'not_connected'    => ['bg'=>'#FFFBEB','border'=>'#FDE68A','text'=>'#92400E'],
    'no_instance'      => ['bg'=>'#FFFBEB','border'=>'#FDE68A','text'=>'#92400E'],
    'unknown'          => ['bg'=>'#FFFBEB','border'=>'#FDE68A','text'=>'#92400E'],
];
$col = $statusColors[$connectionStatus['status']] ?? $statusColors['unknown'];

$settingsUrl  = 'addonmodules.php?module=wabek&tab=settings';
$diagnoseUrl  = 'addonmodules.php?module=wabek&tab=diagnostics';
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <h4 style="margin:0">🔍 Connection Diagnostics</h4>
  <div style="display:flex;gap:8px">
    <a href="<?= $settingsUrl ?>" class="wb-btn wb-btn-secondary wb-btn-sm">⚙️ Settings</a>
    <a href="<?= $diagnoseUrl ?>" class="wb-btn wb-btn-primary wb-btn-sm">🔄 Re-run Tests</a>
  </div>
</div>

<!-- ── Main Status Banner ─────────────────────────────────────────────── -->
<div style="padding:20px 24px;border-radius:14px;margin-bottom:24px;
     background:<?= $col['bg'] ?>;border:2px solid <?= $col['border'] ?>">
  <div style="display:flex;align-items:flex-start;gap:16px">
    <span style="font-size:32px;line-height:1;flex-shrink:0"><?= $connectionStatus['icon'] ?></span>
    <div style="flex:1">
      <div style="font-size:18px;font-weight:700;color:<?= $col['text'] ?>"><?= htmlspecialchars($connectionStatus['label']) ?></div>
      <div style="font-size:13px;color:<?= $col['text'] ?>;margin-top:6px;line-height:1.6;white-space:pre-line">
        <?= htmlspecialchars($connectionStatus['detail']) ?>
      </div>
      <?php if (!empty($connectionStatus['phone'])): ?>
      <div style="margin-top:8px;display:inline-block;background:#fff;border:1px solid <?= $col['border'] ?>;border-radius:8px;padding:4px 14px;font-family:monospace;font-size:13px;color:#0F172A">
        📱 <?= htmlspecialchars($connectionStatus['phone']) ?>
      </div>
      <?php endif; ?>
    </div>
    <div style="text-align:right;flex-shrink:0">
      <div style="font-size:11px;color:<?= $col['text'] ?>;opacity:.7">Checked at</div>
      <div style="font-size:12px;font-weight:600;color:<?= $col['text'] ?>"><?= $connectionStatus['checked_at'] ?></div>
    </div>
  </div>
</div>

<!-- ── Config Summary ────────────────────────────────────────────────── -->
<div class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header"><h4>⚙️ Current Configuration</h4></div>
  <div class="wb-card-body" style="padding:0">
    <table class="wb-table">
      <tbody>
        <tr>
          <td style="font-weight:600;color:#475569;width:200px">API URL</td>
          <td style="font-family:monospace"><?= htmlspecialchars($diagnostics['api_url'] ?? '') ?></td>
          <td>
            <?php $url = $diagnostics['api_url'] ?? ''; ?>
            <?php if (str_starts_with($url, 'https://')): ?>
              <span class="wb-badge sent">✓ HTTPS</span>
            <?php else: ?>
              <span class="wb-badge failed">⚠ Not HTTPS</span>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <td style="font-weight:600;color:#475569">API Key</td>
          <td style="font-family:monospace"><?= htmlspecialchars($diagnostics['api_key_prefix'] ?? '') ?></td>
          <td>
            <?php if (str_contains($connectionStatus['status'], 'invalid_key') || $connectionStatus['status'] === 'no_key'): ?>
              <span class="wb-badge failed">✕ Invalid / Missing</span>
            <?php else: ?>
              <span class="wb-badge sent">✓ Present</span>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <td style="font-weight:600;color:#475569">Instance ID</td>
          <td style="font-family:monospace"><?= htmlspecialchars($diagnostics['instance_id'] ?? '(not set)') ?></td>
          <td>
            <?php if ($connectionStatus['status'] === 'invalid_instance'): ?>
              <span class="wb-badge failed">✕ Not Found</span>
            <?php elseif (!empty($connectionStatus['instance'])): ?>
              <span class="wb-badge sent">✓ Found</span>
            <?php else: ?>
              <span class="wb-badge pending">-</span>
            <?php endif; ?>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<!-- ── Diagnostic Steps ───────────────────────────────────────────────── -->
<?php if (!empty($diagnostics['steps'])): ?>
<div class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header"><h4>🔬 Test Steps</h4></div>
  <div class="wb-card-body" style="padding:0">
    <table class="wb-table">
      <thead>
        <tr>
          <th style="width:30px">#</th>
          <th>Test</th>
          <th>Result</th>
          <th>Detail</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($diagnostics['steps'] as $i => $step): ?>
        <tr>
          <td style="color:#94a3b8;font-size:12px"><?= $i + 1 ?></td>
          <td style="font-weight:600;color:#0F172A"><?= htmlspecialchars($step['name'] ?? '') ?></td>
          <td>
            <?php
            $httpCode = $step['http_code'] ?? 0;
            $curlErr  = $step['curl_error'] ?? null;
            $found    = $step['found'] ?? null;

            if ($curlErr): ?>
              <span class="wb-badge failed">✕ Error</span>
            <?php elseif ($found === false): ?>
              <span class="wb-badge failed">✕ Not Found</span>
            <?php elseif ($found === true): ?>
              <span class="wb-badge sent">✓ Found</span>
            <?php elseif ($httpCode === 200): ?>
              <span class="wb-badge sent">✓ HTTP 200</span>
            <?php elseif ($httpCode === 401): ?>
              <span class="wb-badge failed">✕ HTTP 401 Unauthorized</span>
            <?php elseif ($httpCode === 429): ?>
              <span class="wb-badge failed">✕ HTTP 429 Rate Limited</span>
            <?php elseif ($httpCode >= 500): ?>
              <span class="wb-badge failed">✕ HTTP <?= $httpCode ?> Server Error</span>
            <?php elseif ($httpCode > 0): ?>
              <span class="wb-badge pending">HTTP <?= $httpCode ?></span>
            <?php else: ?>
              <span class="wb-badge pending">-</span>
            <?php endif; ?>
          </td>
          <td style="font-size:12px;color:#475569">
            <?php if ($curlErr): ?>
              <span style="color:#DC2626"><?= htmlspecialchars($curlErr) ?></span>
            <?php elseif (!empty($step['raw_status'])): ?>
              Status: <code><?= htmlspecialchars($step['raw_status']) ?></code>
              <?php if (!empty($step['phone'])): ?> · <?= htmlspecialchars($step['phone']) ?><?php endif; ?>
            <?php elseif (!empty($step['url'])): ?>
              <span style="font-family:monospace;font-size:11px;color:#94a3b8"><?= htmlspecialchars(substr($step['url'],0,60)) ?></span>
            <?php elseif (!empty($step['all_ids'])): ?>
              <?= count($step['all_ids']) ?> instance(s):
              <?php foreach (array_slice($step['all_ids'],0,3) as $id): ?>
                <code style="font-size:10px;background:#F1F5F9;padding:1px 5px;border-radius:3px"><?= htmlspecialchars(substr($id,0,12))?>...</code>
              <?php endforeach; ?>
            <?php elseif (!empty($step['response'])): ?>
              <code style="font-size:10px;background:#F1F5F9;padding:2px 6px;border-radius:4px;display:block;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <?= htmlspecialchars(substr($step['response'],0,80)) ?>
              </code>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ── Raw Debug Info ───────────────────────────────────────────── -->
<?php if (!empty($diagnostics['steps'])): ?>
<div class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header" style="cursor:pointer" onclick="document.getElementById('wbRawDebug').style.display=document.getElementById('wbRawDebug').style.display?'':'none'">
    <h4>🐛 Raw Debug Information <small style="font-weight:400;font-size:12px;color:#94a3b8">(click to expand)</small></h4>
  </div>
  <div id="wbRawDebug" style="display:none">
    <?php foreach ($diagnostics['steps'] as $i => $step): ?>
    <div style="border-bottom:1px solid #E2E8F0;padding:16px 20px">
      <div style="font-weight:700;font-size:13px;color:#0F172A;margin-bottom:10px">
        Step <?= $i+1 ?>: <?= htmlspecialchars($step['name'] ?? '') ?>
      </div>
      <table style="width:100%;border-collapse:collapse;font-size:12px">
        <?php
        $fields = [
          'url'           => 'Request URL',
          'method'        => 'Method',
          'http_code'     => 'HTTP Status',
          'time'          => 'Response Time',
          'curl_error'    => 'cURL Error',
          'parsed_error'  => 'API Error',
          'server_message'=> 'Server Message',
          'instance_id'   => 'Instance ID',
          'instances_found'=> 'Instances Found',
          'all_ids'       => 'Available Instance IDs',
        ];
        foreach ($fields as $key => $label):
          if (!isset($step[$key]) || $step[$key] === null) continue;
          $val = is_array($step[$key]) ? implode(', ', $step[$key]) : $step[$key];
          if (empty($val) && $val !== 0) continue;
        ?>
        <tr style="border-bottom:1px solid #F1F5F9">
          <td style="padding:5px 8px;font-weight:600;color:#475569;width:160px"><?= $label ?></td>
          <td style="padding:5px 8px;font-family:monospace;color:<?= $key==='http_code'&&(int)$val>=400?'#DC2626':'#0F172A' ?>">
            <?= htmlspecialchars((string)$val) ?>
          </td>
        </tr>
        <?php endforeach; ?>

        <?php if (!empty($step['headers_sent'])): ?>
        <tr style="border-bottom:1px solid #F1F5F9">
          <td style="padding:5px 8px;font-weight:600;color:#475569;vertical-align:top">Headers Sent</td>
          <td style="padding:5px 8px">
            <?php foreach ($step['headers_sent'] as $h): ?>
            <div style="font-family:monospace;font-size:11px;color:#475569"><?= htmlspecialchars($h) ?></div>
            <?php endforeach; ?>
          </td>
        </tr>
        <?php endif; ?>

        <?php if (!empty($step['response_body'])): ?>
        <tr>
          <td style="padding:5px 8px;font-weight:600;color:#475569;vertical-align:top">Response Body</td>
          <td style="padding:5px 8px">
            <pre style="font-size:11px;background:#F8FAFC;padding:8px;border-radius:6px;border:1px solid #E2E8F0;margin:0;overflow:auto;max-height:150px"><?= htmlspecialchars(
              json_encode(json_decode($step['response_body']), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE) ?: $step['response_body']
            ) ?></pre>
          </td>
        </tr>
        <?php endif; ?>
      </table>
    </div>
    <?php endforeach; ?>

    <!-- Server message for 401 -->
    <?php if (!empty($connectionStatus['server_message'])): ?>
    <div style="padding:16px 20px;background:#FEF2F2;border-top:1px solid #FECACA">
      <div style="font-weight:700;font-size:13px;color:#B91C1C;margin-bottom:6px">Exact Server Response (401)</div>
      <pre style="font-size:12px;background:#fff;padding:10px;border-radius:6px;border:1px solid #FECACA;margin:0"><?= htmlspecialchars($connectionStatus['server_message']) ?></pre>
    </div>
    <?php endif; ?>

    <!-- Full status dump -->
    <div style="padding:16px 20px;border-top:1px solid #E2E8F0">
      <div style="font-weight:600;font-size:12px;color:#64748b;margin-bottom:8px">Full Status Object</div>
      <pre style="font-size:11px;background:#F8FAFC;padding:10px;border-radius:6px;border:1px solid #E2E8F0;margin:0;overflow:auto;max-height:200px"><?= htmlspecialchars(json_encode(array_merge(
        $connectionStatus,
        ['diagnostics' => '(shown above)']
      ), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)) ?></pre>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- ── Troubleshooting Guide ─────────────────────────────────────────── -->
<div class="wb-card">
  <div class="wb-card-header"><h4>💡 Troubleshooting Guide</h4></div>
  <div class="wb-card-body">
    <?php
    $guides = [
      'invalid_key' => [
        'title' => 'API Key is invalid',
        'steps' => [
          'Go to waabek.com -> Dashboard -> API Keys',
          'Copy your API Key exactly (no spaces)',
          'Paste it in Settings -> API -> WABEK API Key',
          'If expired, create a new key',
        ]
      ],
      'no_key' => [
        'title' => 'API Key not configured',
        'steps' => [
          'Go to Settings -> API',
          'Enter your WABEK API Key',
          'Click Save All Settings',
        ]
      ],
      'unreachable' => [
        'title' => 'Cannot reach API server',
        'steps' => [
          'Check your server has outbound internet access',
          'Test: curl -I https://waabek.com from server',
          'Check if firewall blocks outbound HTTPS (port 443)',
          'Check if waabek.com is accessible from your server',
        ]
      ],
      'timeout' => [
        'title' => 'Connection timed out',
        'steps' => [
          'Server may be blocking outbound connections',
          'Try: curl --max-time 5 https://waabek.com',
          'Contact your hosting provider about outbound HTTPS',
        ]
      ],
      'ssl_error' => [
        'title' => 'SSL verification failed',
        'steps' => [
          'Update server SSL certificates: apt-get update && apt-get install ca-certificates',
          'Or temporarily disable SSL verify in Settings -> Advanced (not recommended)',
        ]
      ],
      'invalid_instance' => [
        'title' => 'Instance ID not found',
        'steps' => [
          'Go to waabek.com -> Dashboard -> WhatsApp',
          'Copy your Instance ID exactly',
          'Paste in Settings -> API -> WhatsApp Instance ID',
          'Or leave Instance ID empty to use your default instance',
        ]
      ],
      'qr_required' => [
        'title' => 'WhatsApp needs to be connected',
        'steps' => [
          'Go to waabek.com -> Dashboard -> WhatsApp',
          'Scan the QR code with your WhatsApp app',
          'Wait for the status to show "Connected"',
          'Re-run diagnostics',
        ]
      ],
      'session_expired' => [
        'title' => 'WhatsApp session expired',
        'steps' => [
          'Go to waabek.com -> Dashboard -> WhatsApp',
          'Re-scan the QR code',
          'Keep WhatsApp connected on your phone',
        ]
      ],
      'not_connected' => [
        'title' => 'WhatsApp is disconnected',
        'steps' => [
          'Go to waabek.com -> Dashboard -> WhatsApp',
          'Check the instance status',
          'Re-connect or scan QR code if needed',
        ]
      ],
    ];

    $status  = $connectionStatus['status'];
    $guide   = $guides[$status] ?? null;

    if ($status === 'connected'): ?>
    <div class="wb-alert success">
      ✅ Everything is working correctly! WhatsApp is connected and ready to send messages.
    </div>
    <?php elseif ($guide): ?>
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:16px">
      <div style="font-weight:700;font-size:14px;color:#0F172A;margin-bottom:12px">
        📋 How to fix: <?= htmlspecialchars($guide['title']) ?>
      </div>
      <ol style="margin:0;padding-left:20px;color:#475569;font-size:13px;line-height:2">
        <?php foreach ($guide['steps'] as $step): ?>
          <li><?= htmlspecialchars($step) ?></li>
        <?php endforeach; ?>
      </ol>
    </div>
    <?php else: ?>
    <p style="font-size:13px;color:#64748b">
      Check the diagnostic steps above for details.
      For help, contact <a href="mailto:support@waabek.com">support@waabek.com</a>
      or visit <a href="https://waabek.com" target="_blank">waabek.com</a>.
    </p>
    <?php endif; ?>

    <div style="margin-top:16px;padding:12px 16px;background:#F1F5F9;border-radius:8px;font-size:12px;color:#64748b">
      <strong>Webhook URL for WABEK Dashboard:</strong><br>
      <code style="font-family:monospace;font-size:11px">
        <?= htmlspecialchars((\WHMCS\Config\Setting::getValue('SystemURL') ?? 'https://your-whmcs.com') . '/includes/hooks/wabek_notifications.php?wabek_webhook=1') ?>
      </code>
      <br><small>Set this as the webhook URL in your WABEK Dashboard to receive delivery receipts and incoming messages.</small>
    </div>
  </div>
</div>

<!-- ── Phone Debug Tool ─────────────────────────────────────────── -->
<div class="wb-card" style="margin-top:20px">
  <div class="wb-card-header">
    <h4>📱 Phone Number Debug Tool</h4>
    <span style="font-size:12px;color:#94a3b8">Test phone retrieval for any client</span>
  </div>
  <div class="wb-card-body">
    <p style="font-size:13px;color:#64748b;margin-bottom:14px">
      Enter a Client ID to see exactly what phone number WABEK retrieves from WHMCS:
    </p>
    <div style="display:flex;gap:10px;align-items:flex-end;margin-bottom:16px">
      <div>
        <label class="wb-label">Client ID</label>
        <input type="number" id="wbDebugClientId" class="wb-input" style="width:130px" placeholder="e.g. 2" min="1">
      </div>
      <button onclick="wbDebugPhone()" class="wb-btn wb-btn-primary wb-btn-sm">🔍 Debug Phone</button>
    </div>

    <div id="wbPhoneDebugResult" style="display:none">
      <div style="background:#0F172A;border-radius:10px;padding:16px;margin-bottom:12px">
        <pre id="wbPhoneDebugJson" style="color:#22D366;font-size:12px;margin:0;overflow:auto;max-height:300px"></pre>
      </div>
      <table class="wb-table" id="wbPhoneDebugTable">
        <tbody></tbody>
      </table>
    </div>

    <!-- Recent clients quick test -->
    <?php if (!empty($debugClients)): ?>
    <div style="margin-top:16px">
      <div style="font-size:12px;font-weight:600;color:#475569;margin-bottom:8px">Quick test - recent clients:</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px">
        <?php foreach ($debugClients as $dc): ?>
        <button onclick="document.getElementById('wbDebugClientId').value='<?= (int)$dc->id ?>'; wbDebugPhone()"
                class="wb-btn wb-btn-secondary wb-btn-sm"
                style="font-size:11px">
          #<?= (int)$dc->id ?> <?= htmlspecialchars(substr(trim(($dc->firstname??'').' '.($dc->lastname??'')), 0, 15)) ?>
          <?php if ($dc->phonenumber): ?>
            <span style="color:#16A34A;margin-left:4px">✓</span>
          <?php else: ?>
            <span style="color:#DC2626;margin-left:4px">⚠</span>
          <?php endif; ?>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
function wbDebugPhone() {
  var id = document.getElementById('wbDebugClientId').value;
  if (!id) return;

  var result = document.getElementById('wbPhoneDebugResult');
  var json   = document.getElementById('wbPhoneDebugJson');
  var table  = document.getElementById('wbPhoneDebugTable').querySelector('tbody');

  json.textContent = 'Loading...';
  result.style.display = 'block';
  table.innerHTML = '';

  fetch('addonmodules.php?module=wabek&tab=diagnostics&debug_client_id=' + id)
    .then(function(r) { return r.json(); })
    .then(function(data) {
      json.textContent = JSON.stringify(data, null, 2);

      var fields = [
        ['Valid',             data.valid ? '✅ Yes' : '❌ No'],
        ['Client ID',         data.client_id || id],
        ['Client Name',       data.client_name || '-'],
        ['Original Phone',    data.original || '(empty)'],
        ['Normalized Phone',  data.phone || '-'],
        ['E.164 Format',      data.e164 || '-'],
        ['Country Code',      data.country_code || '-'],
        ['Country ISO',       data.country_iso || '-'],
        ['Source Used',       data.source || '-'],
        ['Error',             data.error || '-'],
      ];

      fields.forEach(function(f) {
        var tr = document.createElement('tr');
        var td1 = document.createElement('td');
        var td2 = document.createElement('td');
        td1.textContent = f[0];
        td1.style.cssText = 'font-weight:600;color:#475569;width:160px;padding:7px 14px';
        td2.innerHTML = f[1] !== '-' && f[1] !== null
          ? '<span style="font-family:monospace;color:' + (f[0]==='Error'?'#DC2626':'#0F172A') + '">' + (f[1]||'') + '</span>'
          : '<span style="color:#94a3b8">-</span>';
        td2.style.padding = '7px 14px';
        tr.appendChild(td1); tr.appendChild(td2);
        tr.style.borderBottom = '1px solid #F1F5F9';
        table.appendChild(tr);
      });

      // Show debug attempts
      if (data.debug && data.debug.attempts) {
        var tr = document.createElement('tr');
        var td1 = document.createElement('td');
        var td2 = document.createElement('td');
        td1.textContent = 'Lookup Attempts';
        td1.style.cssText = 'font-weight:600;color:#475569;vertical-align:top;padding:7px 14px';
        td2.style.padding = '7px 14px';
        data.debug.attempts.forEach(function(a) {
          var div = document.createElement('div');
          div.style.cssText = 'font-size:11px;font-family:monospace;padding:2px 0;color:#475569';
          div.textContent = a.source + ': ' + (a.value||a.error||'(empty)');
          td2.appendChild(div);
        });
        tr.appendChild(td1); tr.appendChild(td2);
        table.appendChild(tr);
      }
    })
    .catch(function(e) {
      json.textContent = 'Error: ' + e.message;
    });
}
</script>

<?php
/**
 * WABEK Permission Manager
 * @var object $roles
 * @var array  $allPerms
 * @var int    $selectedRole
 * @var array  $rolePerms
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek&tab=permissions';
$flash = $_SESSION['wabek_flash'] ?? null;
if ($flash) { echo '<div class="wb-alert '.$flash['type'].'">'.htmlspecialchars($flash['msg']).'</div>'; unset($_SESSION['wabek_flash']); }
?>

<div style="display:flex;gap:20px;align-items:flex-start">

  <!-- Role Selector -->
  <div class="wb-card" style="width:220px;flex-shrink:0">
    <div class="wb-card-header"><h4>👥 Admin Roles</h4></div>
    <div style="padding:0">
      <?php foreach ($roles as $role): ?>
      <a href="<?= $moduleLink ?>&role_id=<?= $role->id ?>"
         style="display:block;padding:10px 16px;font-size:13px;text-decoration:none;
                border-bottom:1px solid #F1F5F9;
                background:<?= $selectedRole===$role->id?'#EFF6FF':'#fff' ?>;
                color:<?= $selectedRole===$role->id?'#1D4ED8':'#0F172A' ?>;
                font-weight:<?= $selectedRole===$role->id?'600':'400' ?>">
        <?= htmlspecialchars($role->rolename ?? 'Role #'.$role->id) ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Permissions Grid -->
  <div style="flex:1">
    <?php if ($selectedRole > 0): ?>
    <div class="wb-card">
      <div class="wb-card-header">
        <h4>🔐 Permissions for: <?php
          foreach ($roles as $r) if ($r->id === $selectedRole) echo htmlspecialchars($r->rolename ?? '');
        ?></h4>
        <span style="font-size:12px;color:#94a3b8">Toggle permissions on/off. Default: all allowed.</span>
      </div>
      <div class="wb-card-body">
        <form method="post">
          <input type="hidden" name="wabek_action" value="save_permissions">
          <input type="hidden" name="role_id" value="<?= $selectedRole ?>">
          <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">

          <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px">
            <?php foreach ($allPerms as $key => $label): ?>
            <label style="display:flex;align-items:center;gap:10px;padding:12px 14px;border:1px solid #E2E8F0;border-radius:10px;cursor:pointer;
                          background:<?= ($rolePerms[$key] ?? true) ? '#F0FDF4' : '#FEF2F2' ?>;
                          border-color:<?= ($rolePerms[$key] ?? true) ? '#BBF7D0' : '#FECACA' ?>">
              <input type="checkbox" name="perm_<?= $key ?>" value="1"
                     <?= ($rolePerms[$key] ?? true) ? 'checked' : '' ?>
                     style="width:18px;height:18px;accent-color:#16A34A"
                     onchange="this.closest('label').style.background=this.checked?'#F0FDF4':'#FEF2F2';this.closest('label').style.borderColor=this.checked?'#BBF7D0':'#FECACA'">
              <div>
                <div style="font-size:13px;font-weight:600;color:#0F172A"><?= htmlspecialchars($label) ?></div>
                <div style="font-size:10px;font-family:monospace;color:#94a3b8"><?= $key ?></div>
              </div>
            </label>
            <?php endforeach; ?>
          </div>

          <div style="display:flex;gap:8px">
            <button type="submit" class="wb-btn wb-btn-primary">💾 Save Permissions</button>
            <button type="button" onclick="document.querySelectorAll('input[type=checkbox]').forEach(c=>c.checked=true)" class="wb-btn wb-btn-secondary wb-btn-sm">Allow All</button>
            <button type="button" onclick="document.querySelectorAll('input[type=checkbox]').forEach(c=>c.checked=false)" class="wb-btn wb-btn-secondary wb-btn-sm">Deny All</button>
          </div>
        </form>
      </div>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:60px;background:#fff;border:1px solid #E2E8F0;border-radius:12px">
      <div style="font-size:40px;margin-bottom:12px">👈</div>
      <div style="font-size:14px;font-weight:600;color:#475569">Select an admin role to manage its permissions</div>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php
/**
 * WABEK Dashboard Template
 * @var array  $todayStats
 * @var array  $monthStats
 * @var array  $queueStats
 * @var array  $chartData
 * @var object $recentMsgs
 * @var array  $connectionStatus
 * @var bool   $connected
 * @var array  $instances
 * @var string $apiKey
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek';
$chartDates = array_map(fn($r) => $r->date ?? '', $chartData);
$chartSent  = array_map(fn($r) => (int)($r->total ?? 0), $chartData);
$chartFail  = array_map(fn($r) => (int)($r->failed ?? 0), $chartData);

// Connection status colors
$statusColorMap = [
    'connected'        => ['bg' => '#F0FDF4', 'border' => '#BBF7D0', 'text' => '#15803D'],
    'not_connected'    => ['bg' => '#FFFBEB', 'border' => '#FDE68A', 'text' => '#92400E'],
    'qr_required'      => ['bg' => '#FFFBEB', 'border' => '#FDE68A', 'text' => '#92400E'],
    'session_expired'  => ['bg' => '#FFF7ED', 'border' => '#FED7AA', 'text' => '#C2410C'],
    'invalid_key'      => ['bg' => '#FEF2F2', 'border' => '#FECACA', 'text' => '#B91C1C'],
    'invalid_instance' => ['bg' => '#FEF2F2', 'border' => '#FECACA', 'text' => '#B91C1C'],
    'unreachable'      => ['bg' => '#FEF2F2', 'border' => '#FECACA', 'text' => '#B91C1C'],
    'unknown'          => ['bg' => '#FFFBEB', 'border' => '#FDE68A', 'text' => '#92400E'],
];
$col = $statusColorMap[$connectionStatus['status']] ?? $statusColorMap['unknown'];
?>

<!-- Connection Status Banner -->
<div style="display:flex;align-items:center;gap:14px;padding:16px 20px;border-radius:12px;margin-bottom:24px;
     background:<?= $col['bg'] ?>;border:1px solid <?= $col['border'] ?>">
  <span style="font-size:22px;line-height:1"><?= $connectionStatus['icon'] ?? '⚪' ?></span>
  <div style="flex:1">
    <div style="font-weight:700;font-size:14px;color:<?= $col['text'] ?>"><?= htmlspecialchars($connectionStatus['label']) ?></div>
    <div style="font-size:12px;color:<?= $col['text'] ?>;opacity:.85;margin-top:2px"><?= htmlspecialchars($connectionStatus['detail']) ?></div>
  </div>
  <?php if (!empty($connectionStatus['phone'])): ?>
    <div style="background:#fff;border:1px solid <?= $col['border'] ?>;border-radius:8px;padding:6px 14px;font-family:monospace;font-size:13px;color:#0F172A">
      📱 <?= htmlspecialchars($connectionStatus['phone']) ?>
    </div>
  <?php endif; ?>
  <?php if ($connectionStatus['status'] !== 'connected'): ?>
    <div style="display:flex;gap:6px">
      <a href="<?= $moduleLink ?>&tab=diagnostics" class="wb-btn wb-btn-secondary wb-btn-sm">🔍 Diagnostics</a>
      <a href="<?= $moduleLink ?>&tab=settings" class="wb-btn wb-btn-secondary wb-btn-sm">⚙️ Settings</a>
    </div>
  <?php endif; ?>
</div>

<?php if (empty($apiKey)): ?>
<div class="wb-alert warning" style="margin-bottom:20px">
  ⚠️ <strong>Setup Required:</strong> Go to
  <a href="<?= $moduleLink ?>&tab=settings"><strong>Settings -> API</strong></a> and enter your WABEK API Key to start.
</div>
<?php endif; ?>

<!-- ── API Quota Bar ─────────────────────────────────────────────────────── -->
<?php
$todayQuota  = \Wabek\Services\WhatsAppService::getTodayQuota();
$quotaLimit  = 1000; // WABEK default daily limit
$quotaPct    = min(100, round($todayQuota / $quotaLimit * 100));
$quotaColor  = $quotaPct >= 90 ? '#DC2626' : ($quotaPct >= 70 ? '#F59E0B' : '#16A34A');
?>
<?php if ($todayQuota > 0): ?>
<div style="background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:12px 16px;margin-bottom:16px;display:flex;align-items:center;gap:12px">
  <div style="font-size:12px;font-weight:600;color:#475569;white-space:nowrap">API Quota Today</div>
  <div style="flex:1;height:8px;background:#F1F5F9;border-radius:99px">
    <div style="height:100%;width:<?= $quotaPct ?>%;background:<?= $quotaColor ?>;border-radius:99px;transition:width .5s"></div>
  </div>
  <div style="font-size:12px;font-weight:700;color:<?= $quotaColor ?>;white-space:nowrap"><?= number_format($todayQuota) ?></div>
</div>
<?php endif; ?>

<!-- ── Stats Today ──────────────────────────────────────────────────────── -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
  <h5 class="wb-stats-title">Today</h5>
  <span style="font-size:11px;color:#94a3b8"><?= date('l, d F Y') ?></span>
</div>
<div class="wb-stat-cards">
  <div class="wb-stat blue">
    <p class="wb-stat-val"><?= number_format($todayStats['total']) ?></p>
    <p class="wb-stat-lbl">Messages Sent</p>
  </div>
  <div class="wb-stat green">
    <p class="wb-stat-val"><?= number_format($todayStats['delivered']) ?></p>
    <p class="wb-stat-lbl">Delivered</p>
  </div>
  <div class="wb-stat" style="color:#6D28D9">
    <p class="wb-stat-val" style="color:#6D28D9"><?= number_format($todayStats['read']) ?></p>
    <p class="wb-stat-lbl">Read</p>
  </div>
  <div class="wb-stat red">
    <p class="wb-stat-val"><?= number_format($todayStats['failed']) ?></p>
    <p class="wb-stat-lbl">Failed</p>
  </div>
  <div class="wb-stat orange">
    <p class="wb-stat-val"><?= number_format($queueStats['pending']) ?></p>
    <p class="wb-stat-lbl">In Queue</p>
  </div>
</div>

<!-- ── Stats This Month ─────────────────────────────────────────────────── -->
<h5 class="wb-stats-title" style="margin-bottom:10px">This Month - <?= date('F Y') ?></h5>
<div class="wb-stat-cards">
  <div class="wb-stat blue">
    <p class="wb-stat-val"><?= number_format($monthStats['total']) ?></p>
    <p class="wb-stat-lbl">Total Sent</p>
  </div>
  <div class="wb-stat green">
    <p class="wb-stat-val"><?= number_format($monthStats['delivered']) ?></p>
    <p class="wb-stat-lbl">Delivered</p>
  </div>
  <div class="wb-stat red">
    <p class="wb-stat-val"><?= number_format($monthStats['failed']) ?></p>
    <p class="wb-stat-lbl">Failed</p>
  </div>
  <?php
    $deliveryRate = $monthStats['total'] > 0
      ? round($monthStats['delivered'] / $monthStats['total'] * 100, 1) : 0;
    $readRate = $monthStats['total'] > 0
      ? round($monthStats['read'] / $monthStats['total'] * 100, 1) : 0;
  ?>
  <div class="wb-stat green">
    <p class="wb-stat-val"><?= $deliveryRate ?>%</p>
    <p class="wb-stat-lbl">Delivery Rate</p>
  </div>
  <div class="wb-stat" style="">
    <p class="wb-stat-val" style="color:#6D28D9"><?= $readRate ?>%</p>
    <p class="wb-stat-lbl">Read Rate</p>
  </div>
</div>

<!-- ── Chart ────────────────────────────────────────────────────────────── -->
<div class="wb-card">
  <div class="wb-card-header">
    <h4>📈 Messages - Last 30 Days</h4>
    <a href="<?= $moduleLink ?>&tab=messages" class="wb-btn wb-btn-secondary wb-btn-sm">View All Logs -></a>
  </div>
  <div class="wb-card-body">
    <div class="wb-chart-wrap">
      <canvas id="wbDashChart"></canvas>
    </div>
  </div>
</div>

<!-- ── Quick Actions ────────────────────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
  <?php
  $actions = [
    ['tab'=>'send',      'icon'=>'✉️', 'label'=>'Send Message',   'color'=>'#2563EB'],
    ['tab'=>'campaigns', 'icon'=>'📢', 'label'=>'New Campaign',   'color'=>'#16A34A'],
    ['tab'=>'templates', 'icon'=>'📄', 'label'=>'Templates',      'color'=>'#7C3AED'],
    ['tab'=>'settings',  'icon'=>'⚙️', 'label'=>'Settings',       'color'=>'#64748B'],
  ];
  foreach ($actions as $a): ?>
  <a href="<?= $moduleLink ?>&tab=<?= $a['tab'] ?>"
     style="display:flex;align-items:center;gap:10px;padding:14px 16px;background:#fff;border:1px solid #E2E8F0;border-radius:12px;text-decoration:none;transition:all .15s"
     onmouseover="this.style.borderColor='<?= $a['color'] ?>';this.style.boxShadow='0 4px 12px rgba(0,0,0,.08)'"
     onmouseout="this.style.borderColor='#E2E8F0';this.style.boxShadow='none'">
    <span style="font-size:20px"><?= $a['icon'] ?></span>
    <span style="font-size:13px;font-weight:600;color:#0F172A"><?= $a['label'] ?></span>
  </a>
  <?php endforeach; ?>
</div>

<!-- ── Recent Activity ──────────────────────────────────────────────────── -->
<div class="wb-card">
  <div class="wb-card-header">
    <h4>🕐 Recent Messages</h4>
    <a href="<?= $moduleLink ?>&tab=messages" class="wb-btn wb-btn-secondary wb-btn-sm">View All -></a>
  </div>
  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead>
        <tr>
          <th>Time</th>
          <th>Event</th>
          <th>Client</th>
          <th>Phone</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($recentMsgs) && count((array)$recentMsgs) > 0): ?>
          <?php foreach ($recentMsgs as $msg): ?>
          <tr>
            <td style="color:#64748b;white-space:nowrap;font-size:12px">
              <?= date('d M', strtotime($msg->created_at)) ?><br>
              <?= date('H:i', strtotime($msg->created_at)) ?>
            </td>
            <td>
              <code style="font-size:11px;background:#F1F5F9;padding:2px 7px;border-radius:4px;color:#475569">
                <?= htmlspecialchars($msg->event) ?>
              </code>
            </td>
            <td>
              <?php $name = trim(($msg->firstname ?? '') . ' ' . ($msg->lastname ?? '')); ?>
              <?php if ($msg->client_id): ?>
                <a href="clientssummary.php?userid=<?= $msg->client_id ?>" style="font-size:13px">
                  <?= htmlspecialchars($name ?: '#' . $msg->client_id) ?>
                </a>
              <?php else: ?>
                <span style="color:#94a3b8">-</span>
              <?php endif; ?>
            </td>
            <td style="font-family:monospace;font-size:12px;color:#475569">
              <?= htmlspecialchars($msg->phone) ?>
            </td>
            <td>
              <span class="wb-badge <?= $msg->status ?>"><?= ucfirst($msg->status) ?></span>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" style="text-align:center;padding:40px;color:#94a3b8">
              No messages yet.
              <a href="<?= $moduleLink ?>&tab=send" style="margin-left:8px">Send your first message -></a>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<style>
  .wb-stats-title { font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.6px;margin:0; }
</style>

<script>
(function() {
  var ctx = document.getElementById('wbDashChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?= json_encode(array_values($chartDates)) ?>,
      datasets: [
        {
          label: 'Sent',
          data: <?= json_encode(array_values($chartSent)) ?>,
          backgroundColor: 'rgba(37,99,235,0.75)',
          borderRadius: 4,
          borderSkipped: false,
        },
        {
          label: 'Failed',
          data: <?= json_encode(array_values($chartFail)) ?>,
          backgroundColor: 'rgba(220,38,38,0.6)',
          borderRadius: 4,
          borderSkipped: false,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top', labels: { font: { size: 12 }, boxWidth: 12 } },
        tooltip: {
          backgroundColor: '#fff',
          titleColor: '#0F172A',
          bodyColor: '#475569',
          borderColor: '#E2E8F0',
          borderWidth: 1,
          padding: 10,
        }
      },
      scales: {
        x: {
          grid: { color: '#F1F5F9' },
          ticks: { color: '#94A3B8', font: { size: 10 }, maxTicksLimit: 10 }
        },
        y: {
          grid: { color: '#F1F5F9' },
          ticks: { color: '#94A3B8', font: { size: 11 } },
          beginAtZero: true
        }
      }
    }
  });
})();
</script>

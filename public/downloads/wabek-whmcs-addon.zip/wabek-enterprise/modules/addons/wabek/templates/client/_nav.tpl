{* WABEK Client Area — Navigation Bar (included by all pages) *}
{assign var="unread_count" value=0}

<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:20px;overflow:hidden">
  {* Header *}
  <div style="background:linear-gradient(135deg,#f0fdf4,#dcfce7);padding:16px 20px;display:flex;align-items:center;gap:12px;border-bottom:1px solid #bbf7d0">
    <div style="width:40px;height:40px;background:#25D366;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/></svg>
    </div>
    <div style="flex:1">
      <div style="font-size:16px;font-weight:700;color:#15803d">WhatsApp</div>
      {if $has_phone}
        <div style="font-size:12px;color:#16a34a">{$phone_e164}
          {if $is_verified}<span style="background:#bbf7d0;color:#15803d;font-size:10px;padding:1px 6px;border-radius:99px;margin-left:4px">✓ Verified</span>{/if}
        </div>
      {else}
        <div style="font-size:12px;color:#dc2626">No number configured</div>
      {/if}
    </div>
    {if $opt_out}
      <span style="background:#fee2e2;color:#dc2626;font-size:11px;padding:3px 10px;border-radius:99px;font-weight:600">Opted Out</span>
    {/if}
  </div>

  {* Nav tabs *}
  <div style="display:flex;overflow-x:auto;border-bottom:1px solid #e2e8f0;background:#fafafa">
    {assign var="nav_items" value=[
      ['action'=>'dashboard',      'icon'=>'🏠', 'label'=>'Dashboard'],
      ['action'=>'messages',       'icon'=>'📋', 'label'=>'Messages'],
      ['action'=>'conversations',  'icon'=>'💬', 'label'=>'Conversations'],
      ['action'=>'settings',       'icon'=>'⚙️', 'label'=>'Settings'],
    ]}
    {foreach $nav_items as $item}
      {assign var="is_active" value=($action == $item.action || ($action == '' && $item.action == 'dashboard'))}
      <a href="{$modulelink}&action={$item.action}"
         style="display:inline-flex;align-items:center;gap:6px;padding:11px 16px;font-size:13px;font-weight:{if $is_active}600{else}400{/if};
                color:{if $is_active}#15803d{else}#64748b{/if};
                border-bottom:2px solid {if $is_active}#22c55e{else}transparent{/if};
                text-decoration:none;white-space:nowrap;transition:all .15s">
        {$item.icon} {$item.label}
      </a>
    {/foreach}
    {if $otp_enabled}
      <a href="{$modulelink}&action=otp"
         style="display:inline-flex;align-items:center;gap:6px;padding:11px 16px;font-size:13px;
                color:{if $action=='otp'}#15803d{else}#64748b{/if};font-weight:{if $action=='otp'}600{else}400{/if};
                border-bottom:2px solid {if $action=='otp'}#22c55e{else}transparent{/if};
                text-decoration:none;white-space:nowrap">
        🔐 Verify
      </a>
    {/if}
  </div>
</div>

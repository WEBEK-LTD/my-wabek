{* WABEK Client — Notification Preferences *}
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">📱 WhatsApp Notification Preferences</h3>
  </div>
  <div class="panel-body">
    {if $opt_out}
    <div class="alert alert-warning">
      <strong>You are currently unsubscribed</strong> from WhatsApp notifications.
    </div>
    <p>You will not receive any WhatsApp messages from us.</p>
    <a href="{$modulelink}&action=optin" class="btn btn-success">
      ✓ Re-subscribe to WhatsApp notifications
    </a>
    {else}
    <div class="alert alert-success">
      <strong>You are subscribed</strong> to WhatsApp notifications.
    </div>
    <p>You will receive important notifications like invoices, service updates, and support replies via WhatsApp.</p>
    <a href="{$modulelink}&action=optout" class="btn btn-default"
       onclick="return confirm('Unsubscribe from WhatsApp notifications?')">
      Unsubscribe from WhatsApp notifications
    </a>
    {/if}
  </div>
</div>

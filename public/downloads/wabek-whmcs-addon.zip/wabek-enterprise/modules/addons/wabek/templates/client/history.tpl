{* WABEK Client — Message History *}
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">📱 WhatsApp Message History</h3>
  </div>
  <div class="panel-body">
    {if $opt_out}
    <div class="alert alert-warning">
      You have opted out of WhatsApp notifications.
      <a href="{$modulelink}&action=optin" class="btn btn-xs btn-default" style="margin-left:10px">Re-subscribe</a>
    </div>
    {/if}

    {if count($messages) > 0}
    <div class="table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {foreach $messages as $msg}
          <tr>
            <td>{$msg.sent_at|date_format:"%d %b %Y %H:%M"}</td>
            <td>{$msg.event|replace:'_':' '|ucwords}</td>
            <td>
              {if $msg.status == 'delivered'}
                <span class="label label-success">Delivered</span>
              {elseif $msg.status == 'read'}
                <span class="label label-primary">Read</span>
              {elseif $msg.status == 'failed'}
                <span class="label label-danger">Failed</span>
              {else}
                <span class="label label-default">{$msg.status|ucfirst}</span>
              {/if}
            </td>
          </tr>
          {/foreach}
        </tbody>
      </table>
    </div>
    {else}
    <p class="text-muted text-center" style="padding:30px 0">No WhatsApp messages yet.</p>
    {/if}

    {if not $opt_out}
    <hr>
    <p>
      <a href="{$modulelink}&action=optout" class="btn btn-default btn-sm"
         onclick="return confirm('Are you sure you want to unsubscribe from WhatsApp notifications?')">
        Unsubscribe from WhatsApp notifications
      </a>
    </p>
    {/if}
  </div>
</div>

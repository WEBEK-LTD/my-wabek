{* WABEK Client — Conversations *}
{include file="../../../modules/addons/wabek/templates/client/_nav.tpl"}

{if $total_unread > 0}
<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:13px;color:#92400e">
  You have {$total_unread} unread message{if $total_unread != 1}s{/if}
</div>
{/if}

<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9">
    <span style="font-size:14px;font-weight:600;color:#0f172a">💬 Conversations</span>
  </div>

  {if count($conversations) > 0}
    {foreach $conversations as $conv}
    <a href="{$modulelink}&action=conversation&id={$conv->id}"
       style="display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid #f8fafc;text-decoration:none;background:{if $conv->unread_count > 0}#fffbeb{else}#fff{/if}">
      <div style="width:40px;height:40px;background:#e2e8f0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:700;color:#475569;flex-shrink:0">
        {$conv->phone|substr:0:1|upper}
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:{if $conv->unread_count > 0}700{else}500{/if};color:#0f172a">
          {$conv->phone}
        </div>
        <div style="font-size:12px;color:#64748b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px">
          {$conv->last_message|default:'No messages'}
        </div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        {if $conv->unread_count > 0}
          <span style="background:#2563eb;color:#fff;font-size:10px;padding:2px 7px;border-radius:99px;display:inline-block">{$conv->unread_count}</span>
        {/if}
        <div style="font-size:11px;color:#94a3b8;margin-top:3px">
          {if $conv->last_message_at}{$conv->last_message_at|date_format:"%d %b %H:%M"}{/if}
        </div>
      </div>
    </a>
    {/foreach}
  {else}
  <div style="text-align:center;padding:40px;color:#94a3b8">
    <div style="font-size:32px;margin-bottom:8px">💬</div>
    <div style="font-size:14px;font-weight:500">No conversations yet</div>
    <div style="font-size:13px;margin-top:4px">Incoming WhatsApp messages will appear here</div>
  </div>
  {/if}
</div>

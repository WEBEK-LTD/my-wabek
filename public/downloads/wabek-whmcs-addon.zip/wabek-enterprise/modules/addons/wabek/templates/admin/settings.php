<?php
/**
 * WABEK Settings Page
 * @var array       $settings
 * @var array       $templates
 * @var array       $events      ['Category' => ['event1','event2',...]]
 * @var string      $cronPath
 * @var bool        $saved
 * @var string      $csrf
 */

function wb_val(array $s, string $k, string $default = ''): string {
    return htmlspecialchars($s[$k] ?? $default, ENT_QUOTES);
}
function wb_checked(array $s, string $k, string $default = 'on'): string {
    $val = $s[$k] ?? $default;
    return in_array($val, ['on','yes','1'], true) ? 'checked' : '';
}
function wb_selected(array $s, string $k, string $option, string $default = ''): string {
    return ($s[$k] ?? $default) === $option ? 'selected' : '';
}
?>

<?php if ($saved): ?>
<div class="wb-alert success">✓ Settings saved successfully!</div>
<?php endif; ?>

<form method="post" id="wabek-settings-form">
  <input type="hidden" name="save_wabek_settings" value="1">
  <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>">

  <!-- ══ CONNECTION ══════════════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header">
      <h4>🔌 Connection & API</h4>
      <a href="https://waabek.com/dashboard" target="_blank" class="wb-btn wb-btn-secondary wb-btn-sm">Open Dashboard ↗</a>
    </div>
    <div class="wb-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

        <div class="wb-form-group">
          <label class="wb-label">WABEK API Key <span style="color:#DC2626">*</span></label>
          <input type="password" name="api_key" class="wb-input"
                 value="<?= wb_val($settings, 'api_key') ?>"
                 placeholder="wk_live_xxxxxxxxxxxxxxxx"
                 autocomplete="new-password">
          <small style="color:#64748b">From <a href="https://waabek.com/dashboard/api-keys" target="_blank">Dashboard -> API Keys</a></small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Webhook Secret <span style="font-size:10px;font-weight:400;color:#94a3b8">Optional</span></label>
          <input type="text" name="webhook_secret" class="wb-input"
                 value="<?= wb_val($settings, 'webhook_secret') ?>"
                 placeholder="Leave empty to disable signature verification"
                 style="font-family:monospace">
          <small style="color:#64748b">
            Set a secret in WABEK Dashboard -> Webhooks -> Signing Secret.<br>
            Incoming webhooks will be rejected if signature doesn't match.
          </small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">WhatsApp Instance ID</label>
          <input type="text" name="instance_id" class="wb-input"
                 value="<?= wb_val($settings, 'instance_id') ?>"
                 placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
          <small style="color:#64748b">From Dashboard -> WhatsApp. Leave empty for default.</small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">API Base URL</label>
          <input type="text" name="api_url" class="wb-input"
                 value="<?= wb_val($settings, 'api_url', 'https://waabek.com') ?>">
          <small style="color:#64748b">Do not change unless using self-hosted WABEK</small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Default Country Code</label>
          <input type="text" name="default_country_code" class="wb-input"
                 style="width:120px"
                 value="<?= wb_val($settings, 'default_country_code', '20') ?>">
          <small style="color:#64748b">Without + (20 Egypt · 44 UK · 90 Turkey · 966 Saudi · 971 UAE)</small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Client Phone Number Field</label>
          <select name="phone_field" class="wb-select" style="width:220px">
            <option value="phonenumber" <?= wb_selected($settings,'phone_field','phonenumber','phonenumber') ?>>WHMCS Phone Number</option>
            <option value="customfield" <?= wb_selected($settings,'phone_field','customfield') ?>>Custom Client Field</option>
          </select>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Custom Field Name</label>
          <input type="text" name="phone_custom_field" class="wb-input"
                 style="width:200px"
                 value="<?= wb_val($settings, 'phone_custom_field', 'WhatsApp') ?>">
          <small style="color:#64748b">Only used if "Phone Field" above is "Custom Client Field"</small>
        </div>

        <div class="wb-form-group" style="grid-column:1/-1">
          <label class="wb-label">WABEK WhatsApp Override Field <span style="background:#DBEAFE;color:#1D4ED8;font-size:10px;padding:1px 6px;border-radius:4px;font-weight:600">Optional</span></label>
          <input type="text" name="wabek_phone_custom_field" class="wb-input"
                 style="width:260px"
                 value="<?= wb_val($settings, 'wabek_phone_custom_field', '') ?>"
                 placeholder="e.g. Mobile, WhatsApp Number, Contact Number">
          <small style="color:#64748b">
            A custom field that <strong>always takes priority</strong> for WhatsApp numbers.<br>
            Use when clients store WhatsApp in a different field than their WHMCS phone.<br>
            Leave empty to use normal WHMCS phone field + country code logic.
          </small>
        </div>

      </div>
    </div>
  </div>

  <!-- ══ QUEUE ════════════════════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>⚡ Message Queue</h4></div>
    <div class="wb-card-body">

      <div class="wb-alert info" style="margin-bottom:20px">
        <strong>Recommended:</strong> The queue sends messages asynchronously via cron, preventing WHMCS from slowing down during hook execution.
      </div>

      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:20px">

        <div class="wb-form-group">
          <label class="wb-label">Enable Queue</label>
          <label style="display:flex;align-items:center;gap:10px;margin-top:8px;cursor:pointer">
            <input type="checkbox" name="queue_enabled" value="on" <?= wb_checked($settings,'queue_enabled','on') ?>
                   style="width:18px;height:18px;accent-color:#2563EB">
            <span style="font-size:13px;font-weight:500">Send via queue (recommended)</span>
          </label>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Batch Size</label>
          <input type="number" name="queue_batch_size" class="wb-input"
                 style="width:100px"
                 value="<?= wb_val($settings,'queue_batch_size','50') ?>"
                 min="1" max="500">
          <small style="color:#64748b">Messages processed per cron run</small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Delay Between Messages (ms)</label>
          <input type="number" name="queue_delay_ms" class="wb-input"
                 style="width:120px"
                 value="<?= wb_val($settings,'queue_delay_ms','500') ?>"
                 min="0" max="10000">
          <small style="color:#64748b">Rate limiting between sends</small>
        </div>

      </div>

      <div class="wb-form-group">
        <label class="wb-label">Cron Job Command</label>
        <div style="background:#0F172A;border-radius:10px;padding:14px 18px;display:flex;align-items:center;justify-content:space-between">
          <code style="color:#22D366;font-size:12px;font-family:monospace">
            * * * * * php <?= htmlspecialchars($cronPath ?? '/path/to/whmcs/modules/addons/wabek/cron/queue_processor.php', ENT_QUOTES) ?> >> /dev/null 2>&1
          </code>
          <button type="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.textContent.trim());this.textContent='Copied!';setTimeout(()=>this.textContent='Copy',2000)"
                  class="wb-btn wb-btn-secondary wb-btn-sm" style="white-space:nowrap;margin-left:12px">Copy</button>
        </div>
        <small style="color:#64748b">Add to server crontab, or use WHMCS -> Setup -> Automation Settings -> Custom Cron Jobs</small>
      </div>

    </div>
  </div>

  <!-- ══ OTP ══════════════════════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>🔐 OTP (One-Time Password)</h4></div>
    <div class="wb-card-body">
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px">

        <div class="wb-form-group">
          <label class="wb-label">Enable OTP Login</label>
          <label style="display:flex;align-items:center;gap:10px;margin-top:8px;cursor:pointer">
            <input type="checkbox" name="otp_enabled" value="on" <?= wb_checked($settings,'otp_enabled','off') ?>
                   style="width:18px;height:18px;accent-color:#2563EB">
            <span style="font-size:13px">Enable</span>
          </label>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">OTP Template Name <span style="background:#DBEAFE;color:#1D4ED8;font-size:10px;padding:1px 6px;border-radius:4px">Meta Approved</span></label>
          <input type="text" name="otp_template_name" class="wb-input" style="width:220px;font-family:monospace"
                 value="<?= wb_val($settings, 'otp_template_name', '') ?>"
                 placeholder="e.g. digits">
          <small style="color:#64748b">
            Name of your Meta-approved OTP template (e.g. <code>digits</code>).<br>
            Leave empty to send as plain text (works within 24h window only).
          </small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">OTP Expiry (minutes)</label>
          <input type="number" name="otp_expiry_minutes" class="wb-input"
                 style="width:90px" value="<?= wb_val($settings,'otp_expiry_minutes','10') ?>" min="1" max="60">
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Max Attempts</label>
          <input type="number" name="otp_max_attempts" class="wb-input"
                 style="width:90px" value="<?= wb_val($settings,'otp_max_attempts','3') ?>" min="1" max="10">
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Rate Limit (per hour)</label>
          <input type="number" name="otp_rate_limit" class="wb-input"
                 style="width:90px" value="<?= wb_val($settings,'otp_rate_limit','5') ?>" min="1" max="100">
        </div>

      </div>
    </div>
  </div>

  <!-- ══ NOTIFICATION EVENTS ════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header">
      <h4>🔔 Notification Events</h4>
      <span style="font-size:12px;color:#64748b"><?= array_sum(array_map('count', $events)) ?> events available</span>
    </div>
    <div class="wb-card-body">

      <p style="font-size:13px;color:#64748b;margin-bottom:16px">
        Enable each event and assign a message template. You can customize templates in the
        <a href="addonmodules.php?module=wabek&tab=templates">Templates</a> section.
      </p>

      <!-- Test Client Selector -->
      <div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:14px 16px;margin-bottom:20px;display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap">
        <div>
          <label class="wb-label" style="color:#92400E">🧪 Test Client</label>
          <select id="wbTestClientId" class="wb-select" style="width:280px;font-size:12px">
            <option value="">Select client to send test notifications…</option>
            <?php
            $testClients = \WHMCS\Database\Capsule::table('tblclients')
                ->where('status','Active')
                ->select('id','firstname','lastname','email')
                ->orderBy('firstname')->limit(100)->get();
            foreach ($testClients as $tc):
            ?>
            <option value="<?= (int)$tc->id ?>">
              #<?= (int)$tc->id ?> - <?= htmlspecialchars(trim($tc->firstname.' '.$tc->lastname)) ?>
              (<?= htmlspecialchars($tc->email) ?>)
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="font-size:12px;color:#92400E">
          Select a client, then click <strong>▶ Test</strong> next to any event
        </div>
      </div>

      <?php foreach ($events as $category => $eventList): ?>

      <div style="margin-bottom:24px">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <span style="font-size:11px;font-weight:700;text-transform:uppercase;color:#64748b;letter-spacing:.6px"><?= htmlspecialchars($category) ?></span>
          <div style="flex:1;height:1px;background:#E2E8F0"></div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:12px">

          <?php foreach ($eventList as $event):
            $enabledKey  = 'event_' . $event . '_enabled';
            $templateKey = 'event_' . $event . '_template';
            $isEnabled   = wb_checked($settings, $enabledKey, 'on') === 'checked';
            $eventLabel  = ucwords(str_replace('_', ' ', $event));
          ?>
          <div style="border:1px solid <?= $isEnabled ? '#BBF7D0' : '#E2E8F0' ?>;border-radius:10px;padding:14px;
                      background:<?= $isEnabled ? '#F0FDF4' : '#FAFAFA' ?>;transition:all .15s">

            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
              <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0;user-select:none">
                <input type="checkbox" name="<?= $enabledKey ?>" value="on"
                       <?= $isEnabled ? 'checked' : '' ?>
                       style="width:16px;height:16px;accent-color:#16A34A"
                       onchange="this.closest('div[style]').style.background=this.checked?'#F0FDF4':'#FAFAFA';
                                 this.closest('div[style]').style.borderColor=this.checked?'#BBF7D0':'#E2E8F0'">
                <strong style="font-size:13px;color:#0F172A"><?= htmlspecialchars($eventLabel) ?></strong>
              </label>
              <code style="font-size:10px;background:#E2E8F0;color:#475569;padding:2px 7px;border-radius:4px"><?= $event ?></code>
            </div>

            <div>
              <div style="display:flex;align-items:flex-end;gap:6px">
                <div style="flex:1">
                  <label style="font-size:11px;font-weight:500;color:#64748b;display:block;margin-bottom:4px">Template</label>
                  <select name="<?= $templateKey ?>" class="wb-select" style="font-size:12px;width:100%">
                <option value="<?= $event ?>" <?= wb_selected($settings,$templateKey,$event,$event) ?>>
                  [default] <?= htmlspecialchars($event) ?>
                </option>
                <?php foreach ($templates as $tpl):
                  if ($tpl->slug === $event) continue; ?>
                <option value="<?= htmlspecialchars($tpl->slug) ?>"
                        <?= wb_selected($settings,$templateKey,$tpl->slug) ?>>
                  <?= htmlspecialchars($tpl->name) ?> (<?= htmlspecialchars($tpl->category) ?>)
                </option>
                <?php endforeach; ?>
              </select>
                </div>
                <!-- Test button -->
                <form method="post" style="flex-shrink:0">
                  <input type="hidden" name="wabek_action" value="test_notification">
                  <input type="hidden" name="test_event" value="<?= $event ?>">
                  <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
                  <input type="hidden" name="test_client_id" id="tc_<?= $event ?>_cid" value="">
                  <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm"
                          style="white-space:nowrap;font-size:11px"
                          onclick="var cid=document.getElementById('wbTestClientId').value;if(!cid){alert('Select a test client first');return false;}document.getElementById('tc_<?= $event ?>_cid').value=cid">
                    ▶ Test
                  </button>
                </form>
              </div>
            </div>

          </div>
          <?php endforeach; ?>

        </div>
      </div>

      <?php endforeach; ?>

    </div>
  </div>

  <!-- ══ WHITE LABEL ════════════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header">
      <h4>🏷️ White Label</h4>
      <span style="background:#DBEAFE;color:#1D4ED8;font-size:11px;padding:2px 8px;border-radius:4px">For resellers & agencies</span>
    </div>
    <div class="wb-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

        <div class="wb-form-group" style="grid-column:1/-1">
          <label class="wb-label">Enable White Label</label>
          <label style="display:flex;align-items:center;gap:10px;cursor:pointer;margin-top:8px">
            <input type="checkbox" name="white_label_enabled" value="on"
                   <?= wb_checked($settings,'white_label_enabled','off') ?>
                   style="width:18px;height:18px;accent-color:#2563EB"
                   onchange="document.getElementById('wbWhiteLabelFields').style.display=this.checked?'grid':'none'">
            <span style="font-size:13px">Hide WABEK branding - show your own company name</span>
          </label>
        </div>

        <div id="wbWhiteLabelFields" style="display:<?= wb_checked($settings,'white_label_enabled','off')==='checked'?'grid':'none' ?>;grid-template-columns:1fr 1fr;gap:20px;grid-column:1/-1">
          <div class="wb-form-group">
            <label class="wb-label">Company / Brand Name</label>
            <input type="text" name="white_label_company" class="wb-input"
                   value="<?= wb_val($settings,'white_label_company') ?>"
                   placeholder="e.g. Your Company WhatsApp">
          </div>
          <div class="wb-form-group">
            <label class="wb-label">Logo URL</label>
            <input type="text" name="white_label_logo" class="wb-input"
                   value="<?= wb_val($settings,'white_label_logo') ?>"
                   placeholder="https://yoursite.com/logo.png">
          </div>
          <div class="wb-form-group" style="grid-column:1/-1">
            <label class="wb-label">Footer Text</label>
            <input type="text" name="white_label_footer" class="wb-input"
                   value="<?= wb_val($settings,'white_label_footer') ?>"
                   placeholder="Powered by Your Company">
            <small style="color:#64748b">Shown at the bottom of client area pages</small>
          </div>
          <div class="wb-form-group">
            <label class="wb-label">Primary Color</label>
            <div style="display:flex;gap:8px;align-items:center">
              <input type="color" name="white_label_color" class="wb-input" style="width:60px;height:38px;padding:2px"
                     value="<?= wb_val($settings,'white_label_color','#25D366') ?>">
              <input type="text" name="white_label_color_hex" class="wb-input" style="width:110px;font-family:monospace"
                     value="<?= wb_val($settings,'white_label_color','#25D366') ?>" placeholder="#25D366">
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- ══ IMPORT/EXPORT ════════════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>💾 Backup & Restore</h4></div>
    <div class="wb-card-body">
      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-start">
        <!-- Export Settings -->
        <form method="post" style="display:inline">
          <input type="hidden" name="wabek_action" value="export_settings">
          <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
          <div class="wb-form-group" style="margin:0">
            <button type="submit" class="wb-btn wb-btn-secondary">📥 Export Settings</button>
            <div style="font-size:11px;color:#94a3b8;margin-top:4px">API Key is masked in export</div>
          </div>
        </form>
        <!-- Import Settings -->
        <form method="post" enctype="multipart/form-data" style="display:inline">
          <input type="hidden" name="wabek_action" value="import_settings">
          <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
          <div class="wb-form-group" style="margin:0">
            <label class="wb-label">Restore Settings from Backup</label>
            <div style="display:flex;gap:8px">
              <input type="file" name="import_settings_file" class="wb-input" accept=".json" style="padding:5px 10px">
              <button type="submit" class="wb-btn wb-btn-primary wb-btn-sm">Restore</button>
            </div>
            <div style="font-size:11px;color:#DC2626;margin-top:4px">⚠ This overwrites current settings (API key excluded)</div>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- ══ MAINTENANCE ══════════════════════════════════════════════════════ -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>🛠️ Maintenance</h4></div>
    <div class="wb-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

        <div class="wb-form-group">
          <label class="wb-label">Log Retention (days)</label>
          <input type="number" name="log_retention_days" class="wb-input"
                 style="width:100px" value="<?= wb_val($settings,'log_retention_days','90') ?>" min="0">
          <small style="color:#64748b">Auto-delete logs older than N days. 0 = keep forever.</small>
        </div>

        <div class="wb-form-group">
          <label class="wb-label">Admin Failure Alerts</label>
          <label style="display:flex;align-items:center;gap:10px;margin-top:8px;cursor:pointer">
            <input type="checkbox" name="admin_notifications" value="on" <?= wb_checked($settings,'admin_notifications','on') ?>
                   style="width:18px;height:18px;accent-color:#2563EB">
            <span style="font-size:13px">Notify admin on repeated send failures</span>
          </label>
        </div>

      </div>
    </div>
  </div>

  <!-- ══ SAVE ═════════════════════════════════════════════════════════════ -->
  <div style="display:flex;align-items:center;gap:12px;margin-bottom:40px;
              padding:16px 20px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px">
    <button type="submit" class="wb-btn wb-btn-primary" style="padding:11px 32px;font-size:14px">
      💾 Save All Settings
    </button>
    <span style="font-size:12px;color:#94a3b8">All changes will be applied immediately</span>
  </div>

</form>

{* WABEK Client — Settings / Preferences *}
{include file="../../../modules/addons/wabek/templates/client/_nav.tpl"}

{if $saved}
<div style="background:#f0fdf4;border:1px solid #86efac;border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:13px;color:#15803d">
  ✓ Settings saved successfully
</div>
{/if}

{* Current Number *}
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:16px;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9">
    <span style="font-size:14px;font-weight:600;color:#0f172a">📱 WhatsApp Number</span>
  </div>
  <div style="padding:16px 18px">
    {if $has_phone}
    <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#f0fdf4;border-radius:8px;margin-bottom:14px;border:1px solid #bbf7d0">
      <span style="font-size:18px">📱</span>
      <div>
        <div style="font-weight:600;color:#15803d">{$phone_e164}</div>
        <div style="font-size:12px;color:#64748b">via {$phone_source}</div>
      </div>
    </div>
    {else}
    <div style="padding:10px 14px;background:#fef2f2;border-radius:8px;margin-bottom:14px;border:1px solid #fecaca;color:#b91c1c;font-size:13px">
      No WhatsApp number configured
    </div>
    {/if}

    <form method="post">
      <input type="hidden" name="wabek_post_action" value="save_settings">
      <div style="margin-bottom:14px">
        <label style="display:block;font-size:12px;font-weight:600;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px">
          My WhatsApp Number
        </label>
        <input type="text" name="whatsapp_number"
          value="{$client_settings->whatsapp_raw|default:''}"
          placeholder="+905446731942"
          style="width:100%;max-width:280px;padding:9px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;font-family:monospace">
        <div style="font-size:11px;color:#94a3b8;margin-top:4px">
          Include country code. e.g. +905446731942 or 905446731942<br>
          Leave empty to use your WHMCS account phone number.
        </div>
      </div>
      <button type="submit" style="background:#2563eb;color:#fff;border:none;padding:8px 20px;border-radius:8px;cursor:pointer;font-weight:600;font-size:13px">
        Save Number
      </button>
    </form>
  </div>
</div>

{* Notifications *}
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:16px;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9">
    <span style="font-size:14px;font-weight:600;color:#0f172a">🔔 Notifications</span>
  </div>
  <div style="padding:16px 18px">
    {if $opt_out}
    <div style="padding:10px 14px;background:#fef2f2;border-radius:8px;margin-bottom:14px;border:1px solid #fecaca;font-size:13px;color:#b91c1c">
      You are currently <strong>unsubscribed</strong> from WhatsApp notifications.
    </div>
    <a href="{$modulelink}&action=optin" class="btn btn-success btn-sm">✓ Re-subscribe to WhatsApp notifications</a>
    {else}
    <div style="padding:10px 14px;background:#f0fdf4;border-radius:8px;margin-bottom:14px;border:1px solid #bbf7d0;font-size:13px;color:#15803d">
      You are <strong>subscribed</strong> to WhatsApp notifications.
    </div>
    <a href="{$modulelink}&action=optout" class="btn btn-default btn-sm"
       onclick="return confirm('Unsubscribe from WhatsApp notifications?')">
      Unsubscribe
    </a>
    {/if}
  </div>
</div>

{* Verification *}
{if $otp_enabled}
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9">
    <span style="font-size:14px;font-weight:600;color:#0f172a">🔐 Verification</span>
  </div>
  <div style="padding:16px 18px">
    {if $is_verified}
      <div style="display:flex;align-items:center;gap:8px;color:#15803d;font-size:13px">
        <span style="font-size:18px">✅</span> Number verified
      </div>
    {else}
      <p style="font-size:13px;color:#64748b;margin-bottom:12px">
        Verify your WhatsApp number to enable secure login and additional features.
      </p>
      <a href="{$modulelink}&action=otp" class="btn btn-primary btn-sm">🔐 Verify My Number</a>
    {/if}
  </div>
</div>
{/if}

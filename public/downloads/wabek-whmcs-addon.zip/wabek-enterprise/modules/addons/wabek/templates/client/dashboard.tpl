{* WABEK Client Area — Dashboard *}
{include file="../../../modules/addons/wabek/templates/client/_nav.tpl"}

{* Status + Stats *}
<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px">

  {* WhatsApp Status Card *}
  <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px">
    <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">WhatsApp Status</div>
    {if $has_phone}
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
        <span style="width:8px;height:8px;background:#22c55e;border-radius:50%;display:inline-block;flex-shrink:0"></span>
        <span style="font-size:14px;font-weight:600;color:#0f172a">{$phone_e164}</span>
      </div>
      <div style="font-size:12px;color:#64748b">via {$phone_source}</div>
      {if $is_verified}
        <div style="margin-top:8px"><span style="background:#dcfce7;color:#15803d;font-size:11px;padding:3px 10px;border-radius:99px;font-weight:600">✓ Verified</span></div>
      {elseif $otp_enabled}
        <div style="margin-top:8px">
          <a href="{$modulelink}&action=otp" style="background:#f0fdf4;color:#15803d;font-size:12px;padding:4px 12px;border-radius:8px;text-decoration:none;border:1px solid #86efac">
            🔐 Verify Number →
          </a>
        </div>
      {/if}
      <a href="https://wa.me/{$phone_number}" target="_blank"
         style="display:inline-flex;align-items:center;gap:6px;margin-top:10px;background:#25D366;color:#fff;font-size:12px;padding:5px 14px;border-radius:20px;text-decoration:none;font-weight:600">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/></svg>
        Open Chat
      </a>
    {else}
      <div style="color:#dc2626;font-size:13px;margin-bottom:8px">No number configured</div>
      <a href="{$modulelink}&action=settings" style="font-size:12px;color:#2563eb">Add WhatsApp number →</a>
    {/if}
  </div>

  {* Stats Card *}
  <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px">
    <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Activity</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div style="text-align:center;background:#eff6ff;border-radius:8px;padding:10px">
        <div style="font-size:20px;font-weight:700;color:#2563eb">{$stats.sent}</div>
        <div style="font-size:11px;color:#64748b">Sent</div>
      </div>
      <div style="text-align:center;background:#f0fdf4;border-radius:8px;padding:10px">
        <div style="font-size:20px;font-weight:700;color:#16a34a">{$stats.received}</div>
        <div style="font-size:11px;color:#64748b">Received</div>
      </div>
    </div>
    {if $stats.last_msg_at}
      <div style="font-size:11px;color:#94a3b8;margin-top:8px;text-align:center">
        Last activity: {$stats.last_msg_at|date_format:"%d %b %Y"}
      </div>
    {/if}
  </div>
</div>

{* Recent Conversations *}
{if count($conversations) > 0}
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:16px;overflow:hidden">
  <div style="padding:12px 16px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:13px;font-weight:600;color:#0f172a">💬 Recent Conversations</span>
    <a href="{$modulelink}&action=conversations" style="font-size:12px;color:#2563eb">View all →</a>
  </div>
  {foreach $conversations as $conv}
  <a href="{$modulelink}&action=conversation&id={$conv->id}"
     style="display:flex;align-items:center;gap:12px;padding:10px 16px;border-bottom:1px solid #f8fafc;text-decoration:none">
    <div style="width:36px;height:36px;background:#e2e8f0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#475569;flex-shrink:0">
      {$conv->phone|substr:0:1}
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-size:13px;font-weight:{if $conv->unread_count > 0}600{else}400{/if};color:#0f172a">
        {$conv->phone}
      </div>
      <div style="font-size:12px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
        {$conv->last_message|default:'No messages'}
      </div>
    </div>
    <div style="text-align:right;flex-shrink:0">
      {if $conv->unread_count > 0}
        <span style="background:#2563eb;color:#fff;font-size:10px;padding:1px 6px;border-radius:99px">{$conv->unread_count}</span>
      {/if}
      <div style="font-size:10px;color:#94a3b8;margin-top:2px">
        {if $conv->last_message_at}{$conv->last_message_at|date_format:"%H:%M"}{/if}
      </div>
    </div>
  </a>
  {/foreach}
</div>
{/if}

{* Recent Messages *}
{if count($recent_msgs) > 0}
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
  <div style="padding:12px 16px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:13px;font-weight:600;color:#0f172a">📋 Recent Notifications</span>
    <a href="{$modulelink}&action=messages" style="font-size:12px;color:#2563eb">View all →</a>
  </div>
  {foreach $recent_msgs as $msg}
  <div style="display:flex;align-items:center;gap:10px;padding:8px 16px;border-bottom:1px solid #f8fafc">
    <span style="font-size:11px;color:#94a3b8;white-space:nowrap;width:55px">{$msg->created_at|date_format:"%d %b"}</span>
    <span style="font-size:11px;background:#f1f5f9;color:#475569;padding:1px 7px;border-radius:4px;flex-shrink:0">
      {$msg->event|replace:'_':' '|capitalize}
    </span>
    <span style="flex:1"></span>
    {if $msg->status == 'delivered'}
      <span style="background:#dcfce7;color:#15803d;font-size:10px;padding:1px 7px;border-radius:99px;font-weight:600">Delivered</span>
    {elseif $msg->status == 'read'}
      <span style="background:#ede9fe;color:#6d28d9;font-size:10px;padding:1px 7px;border-radius:99px;font-weight:600">Read</span>
    {elseif $msg->status == 'failed'}
      <span style="background:#fee2e2;color:#b91c1c;font-size:10px;padding:1px 7px;border-radius:99px;font-weight:600">Failed</span>
    {else}
      <span style="background:#f1f5f9;color:#64748b;font-size:10px;padding:1px 7px;border-radius:99px">{$msg->status|capitalize}</span>
    {/if}
  </div>
  {/foreach}
</div>
{/if}

{if count($recent_msgs) == 0 && count($conversations) == 0}
<div style="text-align:center;padding:40px 20px;background:#fff;border:1px solid #e2e8f0;border-radius:12px">
  <div style="font-size:40px;margin-bottom:8px">💬</div>
  <div style="font-size:14px;font-weight:600;color:#475569">No activity yet</div>
  <div style="font-size:13px;color:#94a3b8;margin-top:4px">Your WhatsApp notifications will appear here</div>
</div>
{/if}

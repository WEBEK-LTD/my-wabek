<?php /** @var object $items @var int $total @var int $page */ ?>
<div class="wb-card">
  <div class="wb-card-header"><h4>🔐 OTP Verification Logs</h4><span style="font-size:12px;color:#94a3b8"><?= number_format($total) ?> total</span></div>
  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead><tr><th>Time</th><th>Client</th><th>Phone</th><th>Purpose</th><th>Status</th><th>Attempts</th><th>Expires</th><th>IP</th></tr></thead>
      <tbody>
        <?php foreach ($items as $otp): ?>
        <tr>
          <td style="font-size:12px;color:#64748b;white-space:nowrap"><?= date('d M H:i', strtotime($otp->created_at)) ?></td>
          <td>
            <?php if ($otp->client_id): ?>
            <a href="clientssummary.php?userid=<?= $otp->client_id ?>"><?= htmlspecialchars(trim(($otp->firstname??'').(' '.($otp->lastname??''))) ?: '#'.$otp->client_id) ?></a>
            <?php else: echo '-'; endif; ?>
          </td>
          <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($otp->phone) ?></td>
          <td><code style="font-size:11px;background:#F1F5F9;padding:2px 6px;border-radius:4px"><?= htmlspecialchars($otp->purpose) ?></code></td>
          <td>
            <?php if ($otp->is_verified): ?>
              <span class="wb-badge sent">Verified</span>
            <?php elseif ($otp->is_expired || strtotime($otp->expires_at) < time()): ?>
              <span class="wb-badge failed">Expired</span>
            <?php else: ?>
              <span class="wb-badge pending">Pending</span>
            <?php endif; ?>
          </td>
          <td style="color:<?= $otp->attempts >= $otp->max_attempts ? '#DC2626' : '#64748b' ?>"><?= $otp->attempts ?>/<?= $otp->max_attempts ?></td>
          <td style="font-size:11px;color:#64748b"><?= date('H:i:s', strtotime($otp->expires_at)) ?></td>
          <td style="font-size:11px;color:#94a3b8"><?= htmlspecialchars($otp->ip_address ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if ($items->isEmpty()): ?>
        <tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">No OTP records yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
/** @var array $result @var object|null $viewing @var array $templates @var string $csrf */
$moduleLink = 'addonmodules.php?module=wabek&tab=campaigns';
$flash = $_SESSION['wabek_flash'] ?? null;
if ($flash) { echo '<div class="wb-alert ' . $flash['type'] . '">' . htmlspecialchars($flash['msg']) . '</div>'; unset($_SESSION['wabek_flash']); }
$statusColors = ['draft'=>'pending','scheduled'=>'queued','running'=>'sent','paused'=>'failed','completed'=>'delivered','cancelled'=>'failed'];
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
  <h4 style="margin:0">📢 Campaigns</h4>
  <button class="wb-btn wb-btn-primary" onclick="document.getElementById('newCampaignModal').style.display='flex'">+ New Campaign</button>
</div>

<div class="wb-card" style="overflow-x:auto">
  <table class="wb-table">
    <thead>
      <tr><th>Name</th><th>Status</th><th>Recipients</th><th>Sent</th><th>Delivered</th><th>Failed</th><th>Delivery %</th><th>Scheduled</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <?php foreach ($result['items'] as $c): ?>
      <?php $rate = $c->sent_count > 0 ? round($c->delivered_count / $c->sent_count * 100) : 0; ?>
      <tr>
        <td><strong><?= htmlspecialchars($c->name) ?></strong></td>
        <td><span class="wb-badge <?= $statusColors[$c->status] ?? 'pending' ?>"><?= ucfirst($c->status) ?></span></td>
        <td><?= number_format($c->total_recipients) ?></td>
        <td><?= number_format($c->sent_count) ?></td>
        <td><?= number_format($c->delivered_count) ?></td>
        <td style="color:#DC2626"><?= number_format($c->failed_count) ?></td>
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div style="flex:1;height:6px;background:#E2E8F0;border-radius:99px;min-width:60px">
              <div style="height:100%;width:<?= $rate ?>%;background:#16A34A;border-radius:99px"></div>
            </div>
            <span style="font-size:12px"><?= $rate ?>%</span>
          </div>
        </td>
        <td style="font-size:12px;color:#64748b"><?= $c->scheduled_at ? date('d M Y H:i', strtotime($c->scheduled_at)) : '-' ?></td>
        <td>
          <div style="display:flex;gap:4px">
            <a href="<?= $moduleLink ?>&view=<?= $c->id ?>" class="wb-btn wb-btn-secondary wb-btn-sm">View</a>
            <?php if ($c->status === 'draft' || $c->status === 'paused'): ?>
            <form method="post" style="display:inline">
              <input type="hidden" name="wabek_action" value="campaign_action">
              <input type="hidden" name="campaign_id" value="<?= $c->id ?>">
              <input type="hidden" name="campaign_action" value="<?= $c->status === 'paused' ? 'resume' : 'start' ?>">
              <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
              <button type="submit" class="wb-btn wb-btn-success wb-btn-sm">▶ <?= $c->status === 'paused' ? 'Resume' : 'Start' ?></button>
            </form>
            <?php endif; ?>
            <?php if ($c->status === 'running'): ?>
            <form method="post" style="display:inline">
              <input type="hidden" name="wabek_action" value="campaign_action">
              <input type="hidden" name="campaign_id" value="<?= $c->id ?>">
              <input type="hidden" name="campaign_action" value="pause">
              <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
              <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm">⏸ Pause</button>
            </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($result['items'])): ?>
      <tr><td colspan="9" style="text-align:center;padding:40px;color:#94a3b8">No campaigns yet. Create your first one!</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- New Campaign Modal -->
<div id="newCampaignModal" class="modal-overlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:1000;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:16px;width:560px;max-width:95vw;max-height:90vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="padding:20px;border-bottom:1px solid #E2E8F0;display:flex;justify-content:space-between">
      <h5 style="margin:0">New Campaign</h5>
      <button onclick="document.getElementById('newCampaignModal').style.display='none'" style="background:none;border:none;font-size:18px;cursor:pointer">✕</button>
    </div>
    <form method="post" enctype="multipart/form-data" style="padding:20px">
      <input type="hidden" name="wabek_action" value="create_campaign">
      <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">

      <div class="wb-form-group">
        <label class="wb-label">Campaign Name *</label>
        <input type="text" name="campaign_name" class="wb-input" placeholder="e.g. June 2025 Promotion" required>
      </div>
      <div class="wb-form-group">
        <label class="wb-label">Message *</label>
        <textarea name="campaign_message" class="wb-textarea" rows="5" placeholder="Hi {{name}}, ..." required></textarea>
        <small style="color:#94a3b8">Variables: {{name}} {{phone}} {{email}}</small>
      </div>
      <!-- Segmentation -->
      <div style="border:1px solid #E2E8F0;border-radius:10px;padding:16px;margin-bottom:16px;background:#F8FAFC">
        <div style="font-size:12px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.4px;margin-bottom:12px">
          Target Audience (optional)
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <div>
            <label class="wb-label">Client Status</label>
            <select name="seg_status" class="wb-select" style="font-size:12px">
              <option value="">All Active Clients</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Closed">Closed</option>
            </select>
          </div>
          <div>
            <label class="wb-label">Country</label>
            <input type="text" name="seg_country" class="wb-input" style="font-size:12px" placeholder="e.g. EG, GB, TR">
          </div>
          <div>
            <label class="wb-label">Client Group</label>
            <input type="text" name="seg_group" class="wb-input" style="font-size:12px" placeholder="Group ID (number)">
          </div>
          <div>
            <label class="wb-label">Currency</label>
            <input type="text" name="seg_currency" class="wb-input" style="font-size:12px" placeholder="Currency ID (number)">
          </div>
        </div>
      </div>

      <div class="wb-form-group">
        <label class="wb-label">Schedule (optional)</label>
        <input type="datetime-local" name="scheduled_at" class="wb-input">
        <small style="color:#94a3b8">Leave empty to start immediately when you click Start</small>
      </div>
      <div class="wb-form-group">
        <label class="wb-label">Delay Between Messages (ms)</label>
        <input type="number" name="delay_ms" class="wb-input" value="500" min="0" max="10000" style="width:120px">
      </div>

      <!-- Media Attachment -->
      <div class="wb-form-group">
        <label class="wb-label">Attach Media <span style="font-size:10px;color:#94a3b8">Optional</span></label>
        <div style="display:flex;gap:8px">
          <select name="campaign_media_type" class="wb-select" style="width:130px">
            <option value="">No media</option>
            <option value="image">🖼 Image</option>
            <option value="document">📄 Document</option>
            <option value="audio">🔊 Audio</option>
            <option value="video">🎬 Video</option>
          </select>
          <input type="url" name="campaign_media_url" class="wb-input" placeholder="https://...media URL">
        </div>
      </div>
      <!-- CSV Upload option -->
      <div style="border-top:1px solid #E2E8F0;padding-top:14px;margin-top:14px">
        <label class="wb-label" style="margin-bottom:6px">
          OR Upload Recipients CSV
          <span style="font-size:10px;font-weight:400;color:#94a3b8"> (overrides segment - format: phone,name per row)</span>
        </label>
        <input type="file" name="recipients_csv" class="wb-input" accept=".csv,.txt"
               style="padding:5px 10px;font-size:12px">
        <div style="font-size:11px;color:#94a3b8;margin-top:4px">
          CSV format: <code>905551234567,Ahmed Mohamed</code> (one per line, no header row)
        </div>
      </div>

      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">
        <button type="button" onclick="document.getElementById('newCampaignModal').style.display='none'" class="wb-btn wb-btn-secondary">Cancel</button>
        <button type="submit" class="wb-btn wb-btn-primary">Create Campaign</button>
      </div>
    </form>
  </div>
</div>

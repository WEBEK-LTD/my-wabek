<?php
/**
 * @var object $carts
 * @var array  $analytics
 * @var int    $total
 * @var string $status
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek&tab=abandoned_cart';
$statusColors = ['open'=>'pending','reminded_1'=>'queued','reminded_2'=>'queued','reminded_3'=>'queued','recovered'=>'sent','expired'=>'failed'];
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <h4 style="margin:0">🛒 Abandoned Cart Recovery</h4>
  <?php if (!\Wabek\Config\Settings::bool('abandoned_cart_enabled',false)): ?>
  <div class="wb-alert warning" style="margin:0;padding:6px 14px;font-size:12px">
    ⚠ Disabled - enable in <a href="addonmodules.php?module=wabek&tab=settings">Settings</a>
  </div>
  <?php endif; ?>
</div>

<!-- Analytics Cards -->
<div class="wb-stat-cards" style="grid-template-columns:repeat(5,1fr);margin-bottom:24px">
  <?php foreach ([
    ['Total Carts',    $analytics['total'],           'blue'],
    ['Recovered',      $analytics['recovered'],        'green'],
    ['Recovery Rate',  $analytics['recovery_rate'].'%','green'],
    ['Revenue',        '$'.number_format($analytics['revenue'],2), 'green'],
    ['Reminders Sent', $analytics['reminders_sent'],  'blue'],
  ] as [$lbl,$val,$clr]): ?>
  <div class="wb-stat <?= $clr ?>">
    <p class="wb-stat-val"><?= htmlspecialchars((string)$val) ?></p>
    <p class="wb-stat-lbl"><?= $lbl ?></p>
  </div>
  <?php endforeach; ?>
</div>

<!-- Reminder Schedule Info -->
<div class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header"><h4>⏰ Reminder Schedule</h4></div>
  <div class="wb-card-body">
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px">
      <?php foreach ([
        ['1st Reminder','30 minutes','abandoned_cart_1'],
        ['2nd Reminder','4 hours',   'abandoned_cart_2'],
        ['3rd Reminder','24 hours',  'abandoned_cart_3'],
      ] as [$label,$delay,$tpl]): ?>
      <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:14px">
        <div style="font-weight:700;color:#0F172A;margin-bottom:4px"><?= $label ?></div>
        <div style="font-size:12px;color:#64748b">Sent after: <strong><?= $delay ?></strong></div>
        <div style="font-size:11px;color:#94a3b8;margin-top:4px">
          Template: <code style="background:#E2E8F0;padding:1px 5px;border-radius:3px"><?= $tpl ?></code>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="margin-top:12px;font-size:12px;color:#64748b">
      Cron processes reminders every minute.
      Cart is marked recovered automatically when checkout completes.
    </div>
  </div>
</div>

<!-- Filter + Table -->
<div class="wb-card">
  <div class="wb-card-header">
    <h4>📋 Abandoned Carts</h4>
    <div style="display:flex;gap:6px">
      <?php foreach ([''=> 'All', 'open'=>'Open', 'reminded_1'=>'R1', 'reminded_2'=>'R2', 'reminded_3'=>'R3', 'recovered'=>'Recovered', 'expired'=>'Expired'] as $s=>$l): ?>
      <a href="<?= $moduleLink ?>&status=<?= $s ?>"
         class="wb-btn wb-btn-<?= $status===$s?'primary':'secondary' ?> wb-btn-sm"><?= $l ?></a>
      <?php endforeach; ?>
      <span style="font-size:12px;color:#94a3b8;align-self:center"><?= number_format($total) ?></span>
    </div>
  </div>
  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead><tr><th>Time</th><th>Client</th><th>Email</th><th>Cart Value</th><th>Items</th><th>Status</th><th>Reminders</th><th>Recovered</th></tr></thead>
      <tbody>
        <?php foreach ($carts as $cart): ?>
        <tr>
          <td style="font-size:11px;color:#64748b;white-space:nowrap">
            <?= date('d M Y', strtotime($cart->created_at)) ?><br>
            <?= date('H:i', strtotime($cart->created_at)) ?>
          </td>
          <td>
            <?php if ($cart->client_id): ?>
              <a href="clientssummary.php?userid=<?= $cart->client_id ?>">
                <?= htmlspecialchars(trim(($cart->firstname??'').(' '.($cart->lastname??''))) ?: '#'.$cart->client_id) ?>
              </a>
            <?php else: echo '<span style="color:#94a3b8">Guest</span>'; endif; ?>
          </td>
          <td style="font-size:12px;color:#64748b"><?= htmlspecialchars($cart->email ?? '') ?></td>
          <td style="font-weight:600">
            <?= htmlspecialchars($cart->currency ?? '') ?> <?= number_format((float)$cart->cart_value, 2) ?>
          </td>
          <td style="font-size:12px">
            <?php
            $items = json_decode($cart->cart_items ?? '[]', true);
            echo count($items) . ' item' . (count($items) !== 1 ? 's' : '');
            ?>
          </td>
          <td><span class="wb-badge <?= $statusColors[$cart->status] ?? 'pending' ?>"><?= ucfirst(str_replace('_',' ',$cart->status)) ?></span></td>
          <td style="text-align:center"><?= $cart->reminders_sent ?>/3</td>
          <td style="color:#16A34A;font-size:12px">
            <?= $cart->recovered_at ? date('d M H:i', strtotime($cart->recovered_at)) : '-' ?>
            <?php if ($cart->recovered_value): ?>
              <br><small>$<?= number_format((float)$cart->recovered_value,2) ?></small>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if ($carts->isEmpty()): ?>
        <tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">No abandoned carts yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

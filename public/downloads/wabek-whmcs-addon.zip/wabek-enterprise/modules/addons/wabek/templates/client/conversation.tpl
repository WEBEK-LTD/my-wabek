{* WABEK Client — Single Conversation View *}
{include file="../../../modules/addons/wabek/templates/client/_nav.tpl"}

<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">

  {* Conversation Header *}
  <div style="padding:14px 18px;border-bottom:1px solid #e2e8f0;background:#f8fafc;display:flex;align-items:center;gap:12px">
    <a href="{$modulelink}&action=conversations" style="color:#64748b;text-decoration:none;font-size:18px">←</a>
    <div style="width:36px;height:36px;background:#e2e8f0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#475569;flex-shrink:0">
      {$conversation->phone|substr:0:1|upper}
    </div>
    <div>
      <div style="font-size:14px;font-weight:600;color:#0f172a">{$conversation->phone}</div>
      <div style="font-size:11px;color:#94a3b8">{$conversation->status|capitalize}</div>
    </div>
  </div>

  {* Messages *}
  <div id="wbConvMsgs" style="padding:16px;display:flex;flex-direction:column;gap:10px;min-height:300px;max-height:450px;overflow-y:auto;background:#f8fafc">
    {if count($messages) > 0}
      {foreach $messages as $msg}
      <div style="display:flex;justify-content:{if $msg->direction == 'outbound'}flex-end{else}flex-start{/if}">
        <div style="max-width:75%;padding:10px 14px;border-radius:{if $msg->direction == 'outbound'}16px 4px 16px 16px{else}4px 16px 16px 16px{/if};
                    background:{if $msg->direction == 'outbound'}#25D366{else}#fff{/if};
                    color:{if $msg->direction == 'outbound'}#fff{else}#0f172a{/if};
                    border:{if $msg->direction == 'outbound'}none{else}1px solid #e2e8f0{/if};
                    box-shadow:0 1px 3px rgba(0,0,0,.06)">
          {if $msg->message_type != 'text' && $msg->media_url}
          <div style="font-size:10px;opacity:.7;margin-bottom:4px">📎 {$msg->message_type}</div>
          {/if}
          <div style="font-size:13px;line-height:1.5;white-space:pre-wrap">{$msg->content|htmlspecialchars}</div>
          <div style="font-size:10px;opacity:.65;margin-top:4px;text-align:right">
            {if $msg->received_at}{$msg->received_at|date_format:"%H:%M"}{/if}
            {if $msg->direction == 'outbound'} ✓{/if}
          </div>
        </div>
      </div>
      {/foreach}
    {else}
      <div style="text-align:center;color:#94a3b8;font-size:13px;margin:auto">No messages yet</div>
    {/if}
  </div>

  {* Reply Box *}
  {if $has_phone}
  <div style="padding:12px 16px;border-top:1px solid #e2e8f0;background:#fff">
    <form method="post">
      <input type="hidden" name="wabek_post_action" value="reply">
      <input type="hidden" name="conversation_id" value="{$conversation->id}">
      <div style="display:flex;gap:10px;align-items:flex-end">
        <textarea name="message" rows="2" placeholder="Type a message..."
          style="flex:1;padding:9px 12px;border:1px solid #cbd5e1;border-radius:10px;font-size:13px;resize:none;font-family:inherit"
          onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();this.closest('form').submit()}"
          required></textarea>
        <button type="submit"
          style="background:#25D366;color:#fff;border:none;padding:10px 18px;border-radius:10px;cursor:pointer;font-weight:600;font-size:13px">
          Send
        </button>
      </div>
    </form>
  </div>
  {/if}

</div>

<script>
var msgs = document.getElementById('wbConvMsgs');
if (msgs) msgs.scrollTop = msgs.scrollHeight;
</script>

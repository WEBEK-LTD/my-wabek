{* WABEK Client Error *}
<div class="panel panel-danger">
  <div class="panel-heading"><h3 class="panel-title">Error</h3></div>
  <div class="panel-body">
    <p class="text-danger">{$error|default:'An error occurred. Please try again.'}</p>
    <a href="index.php?m=wabek" class="btn btn-default btn-sm">← Back to WhatsApp</a>
  </div>
</div>
<?php
/** @var array $result @var array $filters @var array $events @var string $csrf */
$moduleLink = 'addonmodules.php?module=wabek&tab=messages';
$items  = $result['items'];
$total  = $result['total'];
$pages  = $result['pages'];
$page   = $result['page'];

// Flash message
if (!empty($_SESSION['wabek_flash'])) {
  $flash = $_SESSION['wabek_flash'];
  echo '<div class="wb-alert ' . $flash['type'] . '">' . htmlspecialchars($flash['msg']) . '</div>';
  unset($_SESSION['wabek_flash']);
}
?>

<div class="wb-card">
  <div class="wb-card-header">
    <h4>📋 Message Logs</h4>
    <div style="display:flex;gap:8px">
      <form method="post" style="display:inline">
        <input type="hidden" name="wabek_action" value="export_csv">
        <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
        <input type="hidden" name="status"    value="<?= htmlspecialchars($filters['status']) ?>">
        <input type="hidden" name="date_from" value="<?= htmlspecialchars($filters['date_from']) ?>">
        <input type="hidden" name="date_to"   value="<?= htmlspecialchars($filters['date_to']) ?>">
        <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm">📥 Export CSV</button>
      </form>
      <span style="font-size:12px;color:#64748b;align-self:center"><?= number_format($total) ?> total</span>
    </div>
  </div>

  <!-- Filters -->
  <div style="padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#F8FAFC">
    <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <input type="hidden" name="module" value="wabek">
      <input type="hidden" name="tab"    value="messages">
      <div>
        <label class="wb-label">Status</label>
        <select name="status" class="wb-select" style="width:130px">
          <option value="">All Statuses</option>
          <?php foreach (['queued','sent','delivered','read','failed'] as $s): ?>
          <option value="<?= $s ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="wb-label">Event</label>
        <select name="event" class="wb-select" style="width:160px">
          <option value="">All Events</option>
          <?php foreach ($events as $e): ?>
          <option value="<?= htmlspecialchars($e) ?>" <?= $filters['event'] === $e ? 'selected' : '' ?>><?= htmlspecialchars($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="wb-label">Search Phone/Name</label>
        <input type="text" name="search" class="wb-input" style="width:180px" value="<?= htmlspecialchars($filters['search']) ?>" placeholder="Search...">
      </div>
      <div>
        <label class="wb-label">From</label>
        <input type="date" name="date_from" class="wb-input" style="width:140px" value="<?= htmlspecialchars($filters['date_from']) ?>">
      </div>
      <div>
        <label class="wb-label">To</label>
        <input type="date" name="date_to" class="wb-input" style="width:140px" value="<?= htmlspecialchars($filters['date_to']) ?>">
      </div>
      <div style="display:flex;gap:6px">
        <button type="submit" class="wb-btn wb-btn-primary wb-btn-sm">🔍 Filter</button>
        <a href="addonmodules.php?module=wabek&tab=messages" class="wb-btn wb-btn-secondary wb-btn-sm">✕ Clear</a>
      </div>
    </form>
  </div>

  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead>
        <tr>
          <th>Date</th><th>Event</th><th>Client</th>
          <th>Phone</th><th>Status</th><th>Message ID</th><th>Error</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $msg): ?>
        <tr>
          <td style="white-space:nowrap;color:#64748b">
            <?= date('d M Y', strtotime($msg->sent_at ?? $msg->created_at)) ?><br>
            <small><?= date('H:i:s', strtotime($msg->sent_at ?? $msg->created_at)) ?></small>
          </td>
          <td><code style="font-size:11px;background:#F1F5F9;padding:2px 6px;border-radius:4px"><?= htmlspecialchars($msg->event) ?></code></td>
          <td>
            <?php $name = trim(($msg->firstname ?? '') . ' ' . ($msg->lastname ?? '')); ?>
            <?php if ($msg->client_id): ?>
              <a href="clientssummary.php?userid=<?= $msg->client_id ?>"><?= htmlspecialchars($name ?: '#' . $msg->client_id) ?></a><br>
              <small style="color:#94a3b8"><?= htmlspecialchars($msg->email ?? '') ?></small>
            <?php else: echo '-'; endif; ?>
          </td>
          <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($msg->phone) ?></td>
          <td><span class="wb-badge <?= $msg->status ?>"><?= ucfirst($msg->status) ?></span></td>
          <td style="font-family:monospace;font-size:11px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= htmlspecialchars(substr($msg->message_id ?? '', 0, 35)) ?><?= strlen($msg->message_id ?? '') > 35 ? '...' : '' ?>
          </td>
          <td style="color:#DC2626;font-size:11px;max-width:160px"><?= htmlspecialchars($msg->error_msg ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($items)): ?>
        <tr><td colspan="7" style="text-align:center;padding:40px;color:#94a3b8">No messages found matching your filters.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($pages > 1): ?>
  <div style="padding:12px 20px;border-top:1px solid #E2E8F0">
    <div class="wb-pagination">
      <?php if ($page > 1): ?>
        <a href="<?= $moduleLink ?>&p=<?= $page-1 ?>&<?= http_build_query(array_filter($filters)) ?>">‹ Prev</a>
      <?php endif; ?>
      <?php for ($i = max(1,$page-3); $i <= min($pages,$page+3); $i++): ?>
        <?php if ($i === $page): ?>
          <span class="active"><?= $i ?></span>
        <?php else: ?>
          <a href="<?= $moduleLink ?>&p=<?= $i ?>&<?= http_build_query(array_filter($filters)) ?>"><?= $i ?></a>
        <?php endif; ?>
      <?php endfor; ?>
      <?php if ($page < $pages): ?>
        <a href="<?= $moduleLink ?>&p=<?= $page+1 ?>&<?= http_build_query(array_filter($filters)) ?>">Next ›</a>
      <?php endif; ?>
      <span style="font-size:12px;color:#94a3b8;margin-left:8px">Page <?= $page ?> of <?= $pages ?></span>
    </div>
  </div>
  <?php endif; ?>
</div>

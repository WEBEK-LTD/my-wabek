<?php
/**
 * WABEK Shared Inbox
 * @var object $conversations
 * @var object|null $viewing
 * @var int $total
 * @var int $unreadCount
 * @var string $status
 * @var string $search
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek&tab=inbox';
?>

<div style="display:grid;grid-template-columns:340px 1fr;gap:0;height:calc(100vh - 220px);min-height:500px;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;background:#fff">

  <!-- ── Conversations List ── -->
  <div style="border-right:1px solid #E2E8F0;display:flex;flex-direction:column">

    <!-- Header -->
    <div style="padding:14px 16px;border-bottom:1px solid #E2E8F0;background:#F8FAFC">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <h5 style="margin:0;font-size:14px;font-weight:700">
          💬 Inbox
          <?php if ($unreadCount > 0): ?>
          <span style="background:#DC2626;color:#fff;font-size:10px;padding:1px 6px;border-radius:99px;margin-left:4px"><?= $unreadCount ?></span>
          <?php endif; ?>
        </h5>
      </div>
      <!-- Search -->
      <form method="get">
        <input type="hidden" name="module" value="wabek">
        <input type="hidden" name="tab" value="inbox">
        <input type="hidden" name="status" value="<?= htmlspecialchars($status) ?>">
        <input type="text" name="search" class="wb-input" placeholder="Search phone or name..."
               value="<?= htmlspecialchars($search) ?>" style="font-size:12px;padding:7px 12px">
      </form>
      <!-- Status filter -->
      <div style="display:flex;gap:4px;margin-top:8px">
        <?php foreach (['open','pending','resolved'] as $s): ?>
        <a href="<?= $moduleLink ?>&status=<?= $s ?>"
           style="padding:3px 10px;border-radius:6px;font-size:11px;font-weight:600;text-decoration:none;
                  background:<?= $status===$s?'#2563EB':'#F1F5F9' ?>;color:<?= $status===$s?'#fff':'#475569' ?>">
          <?= ucfirst($s) ?>
        </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- List -->
    <div style="overflow-y:auto;flex:1">
      <?php if ($conversations->isEmpty()): ?>
        <div style="padding:40px 20px;text-align:center;color:#94a3b8;font-size:13px">
          No conversations yet.<br>
          <small>Incoming WhatsApp messages will appear here.</small>
        </div>
      <?php else: ?>
        <?php foreach ($conversations as $conv):
          $clientName = trim(($conv->firstname??'') . ' ' . ($conv->lastname??'')) ?: $conv->phone;
          $isActive   = isset($_GET['conv']) && (int)$_GET['conv'] === $conv->id;
        ?>
        <a href="<?= $moduleLink ?>&status=<?= htmlspecialchars($status) ?>&conv=<?= $conv->id ?>"
           style="display:block;padding:12px 16px;border-bottom:1px solid #F1F5F9;text-decoration:none;
                  background:<?= $isActive ? '#EFF6FF' : ($conv->unread_count > 0 ? '#FFFBEB' : '#fff') ?>;
                  border-left:3px solid <?= $isActive ? '#2563EB' : 'transparent' ?>"
           onmouseover="if(!<?= $isActive?'true':'false' ?>)this.style.background='#F8FAFC'"
           onmouseout="this.style.background='<?= $isActive ? '#EFF6FF' : ($conv->unread_count > 0 ? '#FFFBEB' : '#fff') ?>'">
          <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;gap:6px">
                <div style="width:32px;height:32px;border-radius:50%;background:#E2E8F0;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#475569;flex-shrink:0">
                  <?= strtoupper(substr($clientName, 0, 1)) ?>
                </div>
                <div style="min-width:0">
                  <div style="font-size:13px;font-weight:<?= $conv->unread_count > 0 ? '700' : '500' ?>;color:#0F172A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                    <?= htmlspecialchars($clientName) ?>
                  </div>
                  <div style="font-size:11px;color:#94a3b8;font-family:monospace"><?= htmlspecialchars($conv->phone) ?></div>
                </div>
              </div>
              <div style="font-size:12px;color:#64748b;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-left:38px">
                <?= htmlspecialchars(substr($conv->last_message ?? 'No messages', 0, 50)) ?>
              </div>
            </div>
            <div style="flex-shrink:0;text-align:right;margin-left:8px">
              <div style="font-size:10px;color:#94a3b8">
                <?= $conv->last_message_at ? date('H:i', strtotime($conv->last_message_at)) : '' ?>
              </div>
              <?php if ($conv->unread_count > 0): ?>
              <span style="background:#2563EB;color:#fff;font-size:10px;padding:1px 6px;border-radius:99px;display:inline-block;margin-top:3px">
                <?= $conv->unread_count ?>
              </span>
              <?php endif; ?>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

  </div>

  <!-- ── Conversation View ── -->
  <div style="display:flex;flex-direction:column">
    <?php if ($viewing): ?>

    <!-- Conversation Header -->
    <div style="padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#F8FAFC;display:flex;align-items:center;gap:12px">
      <div style="width:38px;height:38px;border-radius:50%;background:#DBEAFE;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:700;color:#1D4ED8">
        <?= strtoupper(substr($viewing->client_name ?? $viewing->phone, 0, 1)) ?>
      </div>
      <div style="flex:1">
        <div style="font-weight:600;font-size:14px;color:#0F172A">
          <?= htmlspecialchars($viewing->client_name ?: $viewing->phone) ?>
        </div>
        <div style="font-size:12px;color:#64748b;font-family:monospace"><?= htmlspecialchars($viewing->phone) ?></div>
      </div>
      <!-- Actions -->
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <?php if ($viewing->client_id): ?>
          <a href="clientssummary.php?userid=<?= $viewing->client_id ?>" class="wb-btn wb-btn-secondary wb-btn-sm" target="_blank">👤 Client</a>
        <?php endif; ?>
        <!-- Status -->
        <form method="post" style="display:inline">
          <input type="hidden" name="wabek_action" value="update_conversation">
          <input type="hidden" name="conv_id" value="<?= $viewing->id ?>">
          <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
          <select name="conv_status" class="wb-select" style="font-size:12px;padding:5px 10px"
                  onchange="this.form.submit()">
            <?php foreach (['open','pending','resolved','spam'] as $s): ?>
            <option value="<?= $s ?>" <?= $viewing->status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
          </select>
        </form>
        <!-- Assign -->
        <?php
        $admins = \WHMCS\Database\Capsule::table('tbladmins')->select('id','firstname','lastname')->get();
        ?>
        <form method="post" style="display:inline">
          <input type="hidden" name="wabek_action" value="assign_conversation">
          <input type="hidden" name="conv_id" value="<?= $viewing->id ?>">
          <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
          <select name="assign_to" class="wb-select" style="font-size:12px;padding:5px 10px"
                  onchange="this.form.submit()">
            <option value="">Unassigned</option>
            <?php foreach ($admins as $adm): ?>
            <option value="<?= $adm->id ?>" <?= ($viewing->assigned_to ?? 0) == $adm->id ? 'selected' : '' ?>>
              <?= htmlspecialchars(trim($adm->firstname.' '.$adm->lastname)) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </form>
        <!-- Notes button -->
        <button onclick="document.getElementById('wbNotePanel').style.display=document.getElementById('wbNotePanel').style.display?'':'block'"
                class="wb-btn wb-btn-secondary wb-btn-sm">📝 Note</button>
      </div>
    </div>

    <!-- Messages -->
    <div id="wbMessages" style="flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:10px;background:#F8FAFC">
      <?php if (!empty($viewing->messages)): ?>
        <?php foreach ($viewing->messages as $msg): ?>
        <div style="display:flex;justify-content:<?= $msg->direction === 'outbound' ? 'flex-end' : 'flex-start' ?>">
          <div style="max-width:70%;padding:10px 14px;border-radius:<?= $msg->direction==='outbound'?'16px 4px 16px 16px':'4px 16px 16px 16px' ?>;
                      background:<?= $msg->direction==='outbound'?'#2563EB':'#fff' ?>;
                      color:<?= $msg->direction==='outbound'?'#fff':'#0F172A' ?>;
                      border:<?= $msg->direction==='outbound'?'none':'1px solid #E2E8F0' ?>;
                      box-shadow:0 1px 3px rgba(0,0,0,.06)">
            <?php if ($msg->message_type !== 'text' && $msg->media_url): ?>
              <div style="font-size:11px;opacity:.7;margin-bottom:4px">📎 <?= htmlspecialchars($msg->message_type) ?></div>
            <?php endif; ?>
            <div style="font-size:13px;line-height:1.5;white-space:pre-wrap"><?= htmlspecialchars($msg->content ?? '') ?></div>
            <div style="font-size:10px;opacity:.6;margin-top:4px;text-align:right">
              <?= $msg->received_at ? date('H:i', strtotime($msg->received_at)) : '' ?>
              <?php if ($msg->direction === 'outbound'): ?> ✓<?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div style="text-align:center;color:#94a3b8;font-size:13px;margin:auto">No messages in this conversation yet.</div>
      <?php endif; ?>
    </div>

    <!-- Internal Note Panel -->
    <div id="wbNotePanel" style="display:none;padding:10px 16px;background:#FFFBEB;border-top:1px solid #FDE68A">
      <form method="post" style="display:flex;gap:8px">
        <input type="hidden" name="wabek_action" value="add_note">
        <input type="hidden" name="conv_id" value="<?= $viewing->id ?>">
        <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
        <input type="text" name="note_text" class="wb-input" style="flex:1;font-size:12px"
               placeholder="Internal note (not sent to client)..." required>
        <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm">Save Note</button>
      </form>
    </div>

    <!-- Reply Box -->
    <div style="padding:14px 20px;border-top:1px solid #E2E8F0;background:#fff">
      <form method="post" style="display:flex;gap:10px;align-items:flex-end">
        <input type="hidden" name="wabek_action" value="reply_conversation">
        <input type="hidden" name="conv_id" value="<?= $viewing->id ?>">
        <input type="hidden" name="phone" value="<?= htmlspecialchars($viewing->phone) ?>">
        <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
        <textarea name="message" class="wb-input" rows="2"
                  placeholder="Type a message... (Enter to send)"
                  style="flex:1;resize:none;font-size:13px"
                  onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();this.closest('form').submit()}"></textarea>
        <button type="submit" class="wb-btn wb-btn-primary" style="padding:10px 18px">
          Send ↗
        </button>
      </form>
    </div>

    <script>
    // Auto-scroll to bottom
    var msgs = document.getElementById('wbMessages');
    if (msgs) msgs.scrollTop = msgs.scrollHeight;
    </script>

    <?php else: ?>
    <!-- Empty State -->
    <div style="flex:1;display:flex;align-items:center;justify-content:center;background:#F8FAFC">
      <div style="text-align:center;color:#94a3b8">
        <div style="font-size:48px;margin-bottom:12px">💬</div>
        <div style="font-size:14px;font-weight:500;color:#475569">Select a conversation</div>
        <div style="font-size:12px;margin-top:4px">Choose from the left to view messages</div>
      </div>
    </div>
    <?php endif; ?>
  </div>

</div>

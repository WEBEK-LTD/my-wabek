{* WABEK Client — OTP Verification *}
{include file="../../../modules/addons/wabek/templates/client/_nav.tpl"}

<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;max-width:480px;margin:0 auto;overflow:hidden">
  <div style="padding:16px 20px;border-bottom:1px solid #f1f5f9;background:#f8fafc">
    <h4 style="margin:0;font-size:15px;font-weight:600;color:#0f172a">🔐 WhatsApp Verification</h4>
  </div>
  <div style="padding:24px 20px">

    {if $disabled}
      <div class="alert alert-warning">WhatsApp OTP verification is not currently enabled.</div>

    {elseif $otp_sent}
      {* Step 2: Enter code *}
      <div style="text-align:center;margin-bottom:20px">
        <div style="font-size:36px;margin-bottom:8px">📱</div>
        <div style="font-size:15px;font-weight:600;color:#0f172a">Enter Verification Code</div>
        <div style="font-size:13px;color:#64748b;margin-top:4px">
          We sent a 6-digit code to your WhatsApp {if $phone_e164}<strong>{$phone_e164}</strong>{/if}
        </div>
      </div>

      {if $otp_error}
      <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;margin-bottom:14px;color:#b91c1c;font-size:13px">
        {$otp_error}
      </div>
      {/if}

      <form method="post" action="{$modulelink}&action=otp_verify">
        <input type="hidden" name="purpose" value="verification">
        <div style="margin-bottom:16px">
          <input type="text" name="otp_code" maxlength="6" pattern="[0-9]{ldelim}6{rdelim}"
            autofocus autocomplete="one-time-code" required
            placeholder="• • • • • •"
            style="width:100%;text-align:center;font-size:28px;letter-spacing:12px;padding:14px;border:2px solid #25D366;border-radius:10px;font-family:monospace;color:#0f172a">
        </div>
        <button type="submit" style="width:100%;background:#25D366;color:#fff;border:none;padding:12px;border-radius:10px;cursor:pointer;font-weight:700;font-size:15px">
          ✓ Verify
        </button>
      </form>

      <div style="text-align:center;margin-top:14px">
        <a href="{$modulelink}&action=otp" style="font-size:13px;color:#64748b">
          Didn't receive the code? Send again →
        </a>
      </div>

    {else}
      {* Step 1: Request code *}
      <div style="text-align:center;margin-bottom:20px">
        <div style="font-size:36px;margin-bottom:8px">📲</div>
        <div style="font-size:15px;font-weight:600;color:#0f172a">Verify Your WhatsApp</div>
        <div style="font-size:13px;color:#64748b;margin-top:4px">
          We'll send a 6-digit verification code to your WhatsApp number
        </div>
      </div>

      {if $has_phone}
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;margin-bottom:16px;text-align:center">
        <div style="font-size:16px;font-weight:700;color:#15803d">{$phone_e164}</div>
        <div style="font-size:12px;color:#64748b">via {$phone_source}</div>
      </div>

      <form method="post">
        <input type="hidden" name="send_otp" value="1">
        <button type="submit" style="width:100%;background:#25D366;color:#fff;border:none;padding:12px;border-radius:10px;cursor:pointer;font-weight:700;font-size:15px">
          📤 Send Verification Code
        </button>
      </form>

      <div style="text-align:center;margin-top:10px;font-size:12px;color:#94a3b8">
        Not your number?
        <a href="{$modulelink}&action=settings" style="color:#2563eb">Update in Settings →</a>
      </div>

      {else}
      <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px 16px;margin-bottom:16px;color:#b91c1c;font-size:13px">
        No WhatsApp number configured.
      </div>
      <a href="{$modulelink}&action=settings" class="btn btn-primary btn-sm">Add WhatsApp Number →</a>
      {/if}
    {/if}
  </div>
</div>

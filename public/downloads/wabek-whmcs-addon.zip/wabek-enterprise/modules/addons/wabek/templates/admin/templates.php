<?php
/** @var array $templates @var array $categories @var object|null $editing @var string $csrf */
$moduleLink = 'addonmodules.php?module=wabek&tab=templates';
$flash = $_SESSION['wabek_flash'] ?? null;
if ($flash) { echo '<div class="wb-alert ' . $flash['type'] . '">' . htmlspecialchars($flash['msg']) . '</div>'; unset($_SESSION['wabek_flash']); }
?>

<div style="display:grid;grid-template-columns:<?= $editing ? '1fr 400px' : '1fr' ?>;gap:20px">

  <!-- Import Form -->
  <div id="wbImportTpl" style="display:none;padding:14px;background:#FFFBEB;border-bottom:1px solid #FDE68A">
    <form method="post" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:flex-end">
      <input type="hidden" name="wabek_action" value="import_templates">
      <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
      <div>
        <label class="wb-label">Import Templates JSON</label>
        <input type="file" name="import_file" class="wb-input" accept=".json" required style="padding:5px 10px">
      </div>
      <button type="submit" class="wb-btn wb-btn-primary wb-btn-sm">Import</button>
    </form>
  </div>

  <!-- Template List -->
  <div>
    <div class="wb-card">
      <div class="wb-card-header">
        <h4>📄 Message Templates</h4>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <?php foreach ($categories as $cat): ?>
          <a href="<?= $moduleLink ?>&category=<?= urlencode($cat) ?>" class="wb-btn wb-btn-secondary wb-btn-sm <?= ($_GET['category'] ?? '') === $cat ? 'active' : '' ?>"><?= htmlspecialchars(ucfirst($cat)) ?></a>
          <?php endforeach; ?>
          <a href="<?= $moduleLink ?>&edit=new" class="wb-btn wb-btn-primary wb-btn-sm">+ New</a>
          <!-- Export -->
          <form method="post" style="display:inline">
            <input type="hidden" name="wabek_action" value="export_templates">
            <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
            <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm">📥 Export JSON</button>
          </form>
          <!-- Import -->
          <button onclick="document.getElementById('wbImportTpl').style.display=document.getElementById('wbImportTpl').style.display?'':'block'" class="wb-btn wb-btn-secondary wb-btn-sm">📤 Import</button>
        </div>
      </div>
      <div style="overflow-x:auto">
        <table class="wb-table">
          <thead>
            <tr><th>Name</th><th>Category</th><th>Variables</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($templates as $tpl): ?>
            <tr>
              <td>
                <strong><?= htmlspecialchars($tpl->name) ?></strong><br>
                <small style="color:#94a3b8;font-family:monospace"><?= htmlspecialchars($tpl->slug) ?></small>
              </td>
              <td><span class="wb-badge pending"><?= htmlspecialchars($tpl->category) ?></span></td>
              <td>
                <?php $vars = json_decode($tpl->variables ?? '[]', true); ?>
                <?php foreach (array_slice($vars, 0, 4) as $v): ?>
                <code style="font-size:10px;background:#F1F5F9;padding:1px 5px;border-radius:3px">{{<?= htmlspecialchars($v) ?>}}</code>
                <?php endforeach; ?>
                <?php if (count($vars) > 4): ?><small style="color:#94a3b8">+<?= count($vars)-4 ?> more</small><?php endif; ?>
              </td>
              <td>
                <?php if ($tpl->is_active): ?>
                  <span class="wb-badge sent">Active</span>
                <?php else: ?>
                  <span class="wb-badge failed">Inactive</span>
                <?php endif; ?>
                <?php if ($tpl->is_system): ?>
                  <span class="wb-badge pending" style="margin-left:4px">System</span>
                <?php endif; ?>
              </td>
              <td>
                <div style="display:flex;gap:4px">
                  <a href="<?= $moduleLink ?>&edit=<?= $tpl->id ?>" class="wb-btn wb-btn-secondary wb-btn-sm">Edit</a>
                  <a href="<?= $moduleLink ?>&duplicate=<?= $tpl->id ?>" class="wb-btn wb-btn-secondary wb-btn-sm">Copy</a>
                  <?php if (!$tpl->is_system): ?>
                  <form method="post" onsubmit="return confirm('Delete this template?')">
                    <input type="hidden" name="wabek_action" value="delete_template">
                    <input type="hidden" name="template_id" value="<?= $tpl->id ?>">
                    <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
                    <button type="submit" class="wb-btn wb-btn-danger wb-btn-sm">Del</button>
                  </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Edit Panel -->
  <?php if ($editing !== null): ?>
  <div>
    <div class="wb-card">
      <div class="wb-card-header"><h4><?= $editing === 'new' ? '+ New Template' : 'Edit: ' . htmlspecialchars($editing->name ?? '') ?></h4></div>
      <div class="wb-card-body">
        <form method="post" id="tplForm">
          <input type="hidden" name="wabek_action" value="save_template">
          <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
          <input type="hidden" name="template_id" value="<?= ($editing !== 'new') ? $editing->id : 0 ?>">

          <div class="wb-form-group">
            <label class="wb-label">Name *</label>
            <input type="text" name="name" class="wb-input" value="<?= htmlspecialchars(($editing !== 'new') ? $editing->name : '') ?>" required>
          </div>
          <div class="wb-form-group">
            <label class="wb-label">Slug * <small>(unique identifier)</small></label>
            <input type="text" name="slug" class="wb-input" value="<?= htmlspecialchars(($editing !== 'new') ? $editing->slug : '') ?>"
                   <?= ($editing !== 'new' && $editing->is_system) ? 'readonly' : '' ?> required>
          </div>
          <div class="wb-form-group">
            <label class="wb-label">Category</label>
            <select name="category" class="wb-select">
              <?php foreach (['billing','services','support','domains','clients','security','marketing','general'] as $cat): ?>
              <option value="<?= $cat ?>" <?= (($editing !== 'new') && $editing->category === $cat) ? 'selected' : '' ?>><?= ucfirst($cat) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="wb-form-group">
            <label class="wb-label">Message Content *</label>
            <textarea name="content" class="wb-textarea" rows="8" required><?= htmlspecialchars(($editing !== 'new') ? $editing->content : '') ?></textarea>
            <small style="color:#94a3b8">Use {{variable_name}} for dynamic content</small>
          </div>
          <div class="wb-form-group">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
              <input type="checkbox" name="is_active" value="1" <?= ($editing === 'new' || $editing->is_active) ? 'checked' : '' ?>>
              <span style="font-size:13px;font-weight:500">Active</span>
            </label>
          </div>

          <!-- Preview -->
          <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:12px;margin-bottom:14px">
            <div style="font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:8px">Preview (sample data)</div>
            <pre id="tplPreview" style="font-size:12px;white-space:pre-wrap;margin:0;color:#0F172A;font-family:inherit"></pre>
          </div>

          <div style="display:flex;gap:8px">
            <button type="submit" class="wb-btn wb-btn-primary">Save Template</button>
            <a href="<?= $moduleLink ?>" class="wb-btn wb-btn-secondary">Cancel</a>
          </div>
        </form>

        <!-- Version History -->
        <?php if ($editing !== 'new' && $editing): ?>
        <?php $versions = \Wabek\Models\Template::versions($editing->id); ?>
        <?php if (!empty($versions)): ?>
        <div style="margin-top:16px">
          <div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px">
            Version History (<?= count($versions) ?>)
          </div>
          <?php foreach ($versions as $ver): ?>
          <div style="border:1px solid #E2E8F0;border-radius:8px;padding:10px;margin-bottom:6px;font-size:12px">
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div>
                <span style="font-weight:600">v<?= $ver->version ?></span>
                <span style="color:#64748b;margin-left:6px"><?= date('d M Y H:i', strtotime($ver->created_at)) ?></span>
                <?php $name = trim(($ver->firstname??'').(' '.($ver->lastname??''))); ?>
                <?php if ($name): ?><span style="color:#94a3b8;margin-left:4px">by <?= htmlspecialchars($name) ?></span><?php endif; ?>
              </div>
              <form method="post" style="display:inline">
                <input type="hidden" name="wabek_action" value="restore_version">
                <input type="hidden" name="version_id" value="<?= $ver->id ?>">
                <input type="hidden" name="template_id" value="<?= $editing->id ?>">
                <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
                <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm"
                        onclick="return confirm('Restore this version?')">↩ Restore</button>
              </form>
            </div>
            <div style="color:#94a3b8;margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%">
              <?= htmlspecialchars(substr($ver->content, 0, 80)) ?>...
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        </form>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
// Live template preview
(function() {
  const ta = document.querySelector('textarea[name="content"]');
  const preview = document.getElementById('tplPreview');
  if (!ta || !preview) return;

  const sampleVars = {
    name:'Ahmed Mohamed', email:'ahmed@example.com', company:'ACME Hosting',
    invoice_id:'INV-1234', amount:'99.00', currency:'USD',
    due_date:'31 Dec 2025', domain:'example.com', service:'Web Hosting',
    ticket_id:'TKT-5678', subject:'Help needed', otp:'123456',
    expiry_minutes:'10', days:'7', portal_url:'https://portal.example.com',
    reset_link:'https://portal.example.com/reset?token=xxx',
    order_id:'ORD-001', total:'199.00', message:'Check out our latest offer!'
  };

  function updatePreview() {
    let text = ta.value;
    Object.entries(sampleVars).forEach(([k,v]) => {
      text = text.replace(new RegExp('\\{\\{' + k + '\\}\\}', 'g'), v);
    });
    preview.textContent = text;
  }

  ta.addEventListener('input', updatePreview);
  updatePreview();
})();
</script>

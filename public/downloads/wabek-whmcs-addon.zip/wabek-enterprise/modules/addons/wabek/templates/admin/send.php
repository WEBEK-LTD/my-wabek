<?php
/**
 * WABEK Send Message
 * @var mixed  $result
 * @var object $clients
 * @var array  $clientPhones  - pre-normalized phones keyed by client ID
 * @var string $csrf
 */
$errorCodes = [
    '131026' => 'Message Undeliverable - recipient may have opted out or blocked the number',
    '131047' => 'Re-engagement message - customer is outside the 24-hour window, use a template',
    '131009' => 'Invalid phone number - check E.164 format',
    '131000' => 'Message failed to send - generic failure',
    '131042' => 'Business account issue - check Meta Business Manager',
    '130429' => 'Rate limit hit - slow down sending',
    '132000' => 'Template parameter count mismatch',
    '132001' => 'Template not found or not approved',
];

$resultMsg  = '';
$resultType = '';

if ($result !== null) {
    if ($result['success']) {
        $resultType = 'success';
        $resultMsg  = '✓ Message sent! ID: ' . htmlspecialchars($result['messageId'] ?? '');
        if (!empty($result['phone_normalized'])) {
            $resultMsg .= ' | Phone: ' . htmlspecialchars($result['phone_e164'] ?? $result['phone_normalized']);
        }
    } else {
        $resultType = 'danger';
        $errCode    = (string)($result['error_code'] ?? '');
        $serverErr  = htmlspecialchars($result['error'] ?? 'Unknown error');
        $codeDesc   = '';

        // Extract Meta error code from error string
        if (preg_match('/\(#(\d+)\)/', $serverErr, $m)) {
            $errCode = $m[1];
        }
        if ($errCode && isset($errorCodes[$errCode])) {
            $codeDesc = ' - ' . $errorCodes[$errCode];
        }

        $resultMsg = "✕ Failed: {$serverErr}";
        if ($codeDesc) {
            $resultMsg .= "<br><small style='opacity:.8'>{$errCode}: {$codeDesc}</small>";
        }

        // Show accepted-but-failed case
        if (!empty($result['accepted']) && !$result['success']) {
            $resultMsg .= "<br><small style='color:#F59E0B'>⚠ Message was accepted by Meta but delivery failed (error #{$errCode})</small>";
        }
    }
}
?>

<?php if ($resultMsg): ?>
<div class="wb-alert <?= $resultType ?>" style="margin-bottom:16px">
  <?= $resultMsg ?>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 360px;gap:20px">

  <!-- Send Form -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>✉️ Send WhatsApp Message</h4></div>
    <div class="wb-card-body">
      <form method="post" id="wbSendForm">
        <input type="hidden" name="wb_send"      value="1">
        <input type="hidden" name="_wabek_csrf"  value="<?= htmlspecialchars($csrf) ?>">

        <!-- Client Selector -->
        <div class="wb-form-group">
          <label class="wb-label">Select Client (optional)</label>
          <select id="wbClientSelect" name="selected_client_id" class="wb-select">
            <option value="">- Type phone manually below -</option>
            <?php foreach ($clients as $cl):
              $normalizedPhone = $clientPhones[(int)$cl->id] ?? '';
            ?>
            <option value="<?= (int)$cl->id ?>"
                    data-phone="<?= htmlspecialchars($normalizedPhone) ?>"
                    data-raw="<?= htmlspecialchars($cl->phonenumber ?? '') ?>"
                    data-name="<?= htmlspecialchars(trim(($cl->firstname??'').' '.($cl->lastname??''))) ?>"
                    data-email="<?= htmlspecialchars($cl->email ?? '') ?>">
              #<?= (int)$cl->id ?> - <?= htmlspecialchars(trim(($cl->firstname??'').' '.($cl->lastname??''))) ?>
              <?= $normalizedPhone ? ' ('.$normalizedPhone.')' : ' ⚠ no phone' ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Phone Preview (shown after client selected) -->
        <div id="wbPhonePreview" style="display:none;background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:12px;margin-bottom:14px;font-size:13px">
          <div style="font-weight:600;color:#15803D;margin-bottom:6px">📱 Client Phone Preview</div>
          <table style="border-collapse:collapse;font-size:12px">
            <tr><td style="color:#64748b;padding:2px 12px 2px 0;width:130px">Client</td><td id="pvName" style="color:#0F172A;font-weight:500"></td></tr>
            <tr><td style="color:#64748b;padding:2px 12px 2px 0">Client ID</td><td id="pvId" style="font-family:monospace;color:#0F172A"></td></tr>
            <tr><td style="color:#64748b;padding:2px 12px 2px 0">Original Phone</td><td id="pvRaw" style="font-family:monospace;color:#475569"></td></tr>
            <tr><td style="color:#64748b;padding:2px 12px 2px 0">Normalized Phone</td><td id="pvNorm" style="font-family:monospace;color:#16A34A;font-weight:600"></td></tr>
          </table>
          <div id="pvWarning" style="display:none;background:#FEF2F2;border:1px solid #FECACA;border-radius:6px;padding:8px;margin-top:8px;color:#B91C1C;font-size:12px"></div>
        </div>

        <!-- Phone Input -->
        <div class="wb-form-group">
          <label class="wb-label">Phone Number <span style="color:#DC2626">*</span></label>
          <input type="text" name="phone" id="wbPhoneInput" class="wb-input"
                 placeholder="905446731942 or +905446731942"
                 value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                 style="font-family:monospace;font-size:15px;letter-spacing:1px"
                 autocomplete="off">
          <small style="color:#64748b">
            Enter with country code. e.g. <code>905446731942</code> (Turkey) or <code>201234567890</code> (Egypt).<br>
            The <code>+</code> prefix is optional - it will be handled automatically.
          </small>
        </div>

        <!-- Message -->
        <div class="wb-form-group">
          <label class="wb-label">Message <span style="color:#DC2626">*</span></label>
          <textarea name="message" class="wb-textarea" rows="5"
                    placeholder="Type your message here..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
        </div>

        <!-- Media Attachment -->
        <div class="wb-form-group">
          <label class="wb-label">Attach Media <span style="font-size:10px;color:#94a3b8;font-weight:400">(optional)</span></label>
          <div style="display:flex;gap:8px;align-items:flex-end">
            <select name="media_type" class="wb-select" style="width:120px">
              <option value="">No media</option>
              <option value="image">🖼 Image</option>
              <option value="document">📄 Document</option>
              <option value="audio">🔊 Audio</option>
              <option value="video">🎬 Video</option>
            </select>
            <input type="url" name="media_url" class="wb-input" placeholder="https://... or pick from library"
                   id="wbMediaUrl" style="flex:1">
            <button type="button" onclick="wbPickMedia()" class="wb-btn wb-btn-secondary wb-btn-sm">📚 Library</button>
          </div>
          <input type="text" name="media_caption" class="wb-input" style="margin-top:6px"
                 placeholder="Caption (optional)" value="">
        </div>

        <!-- Instance Selector (if multiple instances available) -->
        <?php if (!empty($instances)): ?>
        <div class="wb-form-group">
          <label class="wb-label">WhatsApp Instance</label>
          <select name="instance_id" class="wb-select" style="width:280px">
            <option value="">Default Instance</option>
            <?php foreach ($instances as $inst): ?>
            <option value="<?= htmlspecialchars($inst['id'] ?? '') ?>"
                    <?= ($inst['id'] ?? '') === \Wabek\Config\Settings::instanceId() ? 'selected' : '' ?>>
              <?= htmlspecialchars($inst['name'] ?? $inst['id'] ?? 'Instance') ?>
              (<?= htmlspecialchars($inst['status'] ?? '') ?>)
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>

        <div style="display:flex;align-items:center;gap:12px">
          <button type="submit" class="wb-btn wb-btn-primary" id="wbSendBtn">📤 Send Now</button>
          <span id="wbSendWarning" style="display:none;font-size:12px;color:#DC2626"></span>
        </div>
      </form>
    </div>
  </div>

  <!-- Reference + Last Result -->
  <div>
    <div class="wb-card" style="margin-bottom:16px">
      <div class="wb-card-header"><h4>🌍 Country Codes</h4></div>
      <div class="wb-card-body" style="padding:0">
        <table style="font-size:12px;width:100%;border-collapse:collapse">
          <?php foreach ([
            ['🇪🇬','Egypt',       '20',  '201234567890'],
            ['🇹🇷','Turkey',      '90',  '905551234567'],
            ['🇸🇦','Saudi Arabia','966', '966501234567'],
            ['🇦🇪','UAE',         '971', '971501234567'],
            ['🇬🇧','UK',          '44',  '447878704062'],
            ['🇺🇸','USA',         '1',   '12125551234'],
          ] as [$flag,$country,$code,$ex]): ?>
          <tr style="border-bottom:1px solid #F1F5F9">
            <td style="padding:7px 12px"><?= $flag ?> <?= $country ?></td>
            <td style="padding:7px 8px;color:#64748b">+<?= $code ?></td>
            <td style="padding:7px 12px;font-family:monospace;font-size:10px;color:#94a3b8"><?= $ex ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </div>
    </div>

    <!-- Meta Error Reference -->
    <div class="wb-card">
      <div class="wb-card-header"><h4>📋 Meta Error Codes</h4></div>
      <div class="wb-card-body" style="padding:0">
        <table style="font-size:11px;width:100%;border-collapse:collapse">
          <?php foreach ($errorCodes as $code => $desc): ?>
          <tr style="border-bottom:1px solid #F1F5F9">
            <td style="padding:6px 12px;font-family:monospace;color:#DC2626;font-weight:600;white-space:nowrap"><?= $code ?></td>
            <td style="padding:6px 12px;color:#475569"><?= $desc ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </div>
    </div>
  </div>

</div>

<script>
(function() {
  var sel    = document.getElementById('wbClientSelect');
  var phone  = document.getElementById('wbPhoneInput');
  var prev   = document.getElementById('wbPhonePreview');
  var warn   = document.getElementById('wbSendWarning');
  var btn    = document.getElementById('wbSendBtn');

  if (!sel) return;

  sel.addEventListener('change', function() {
    var opt = this.options[this.selectedIndex];
    var id  = opt.value;
    if (!id) {
      prev.style.display = 'none';
      phone.value  = '';
      return;
    }

    var normalizedPhone = opt.dataset.phone  || '';
    var rawPhone        = opt.dataset.raw    || '';
    var name            = opt.dataset.name   || '';
    var email           = opt.dataset.email  || '';

    document.getElementById('pvName').textContent = name + (email ? ' (' + email + ')' : '');
    document.getElementById('pvId').textContent   = '#' + id;
    document.getElementById('pvRaw').textContent  = rawPhone || '(empty)';
    prev.style.display = 'block';

    // Show raw phone from WHMCS — backend (PhoneHelper) handles normalization on send
    var rawPhone = opt.dataset.phone || '';
    phone.value  = rawPhone;  // show what WHMCS has — backend will normalize

    document.getElementById('pvNorm').textContent =
      rawPhone ? ('Will normalize: ' + rawPhone) : '⚠ No phone — enter manually';
    document.getElementById('pvWarning').style.display = rawPhone ? 'none' : 'block';
    if (!rawPhone) {
      document.getElementById('pvWarning').textContent = 'No phone on file. Enter number manually.';
    }
    btn.disabled       = false;
    warn.style.display = 'none';
  });

  // Media Library picker
window.wbPickMedia = function() {
  // Open media library in modal
  var modal = document.getElementById('wbMediaPickerModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'wbMediaPickerModal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center';
    modal.innerHTML = '<div style="background:#fff;border-radius:12px;width:700px;max-width:95vw;max-height:80vh;overflow:auto">' +
      '<div style="padding:16px 20px;border-bottom:1px solid #E2E8F0;display:flex;justify-content:space-between;align-items:center">' +
      '<strong>Media Library</strong>' +
      '<button onclick="document.getElementById('wbMediaPickerModal').remove()" style="background:none;border:none;font-size:20px;cursor:pointer">✕</button>' +
      '</div>' +
      '<div id="wbMediaPickerGrid" style="padding:16px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px">' +
      '<div style="text-align:center;padding:30px;color:#94a3b8;grid-column:1/-1">Loading...</div></div></div>';
    document.body.appendChild(modal);

    // Load media via fetch
    fetch('addonmodules.php?module=wabek&tab=media&picker=1')
      .then(r => r.json())
      .then(function(data) {
        var grid = document.getElementById('wbMediaPickerGrid');
        if (!data.items || !data.items.length) {
          grid.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;grid-column:1/-1">No media files. <a href="addonmodules.php?module=wabek&tab=media" target="_blank">Upload first -></a></div>';
          return;
        }
        grid.innerHTML = '';
        data.items.forEach(function(item) {
          var div = document.createElement('div');
          div.style.cssText = 'border:1px solid #E2E8F0;border-radius:8px;overflow:hidden;cursor:pointer';
          div.innerHTML = '<div style="height:80px;background:#F8FAFC;display:flex;align-items:center;justify-content:center">' +
            (item.media_type==='image' ? '<img src="'+item.url+'" style="max-width:100%;max-height:100%;object-fit:cover">' : '<span style="font-size:28px">' + {image:'🖼️',document:'📄',audio:'🔊',video:'🎬'}[item.media_type] + '</span>') +
            '</div>' +
            '<div style="padding:6px;font-size:10px;color:#475569;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+item.original_name+'</div>';
          div.onclick = function() {
            document.getElementById('wbMediaUrl').value = item.url;
            document.querySelector('[name="media_type"]').value = item.media_type;
            document.getElementById('wbMediaPickerModal').remove();
          };
          div.onmouseover = function() { this.style.borderColor='#2563EB'; };
          div.onmouseout  = function() { this.style.borderColor='#E2E8F0'; };
          grid.appendChild(div);
        });
      })
      .catch(function() {
        document.getElementById('wbMediaPickerGrid').innerHTML =
          '<div style="text-align:center;padding:30px;color:#94a3b8;grid-column:1/-1">Could not load media library</div>';
      });
  }
};

// Validate phone on form submit
  document.getElementById('wbSendForm').addEventListener('submit', function(e) {
    var p = phone.value.replace(/\D/g, '');
    if (!p || p.length < 7) {
      e.preventDefault();
      warn.style.display = 'inline';
      warn.textContent   = 'Enter a valid phone number (7–15 digits)';
      return;
    }
    if (p === '000000000000' || p === '0000000000' || p === '1234567890') {
      e.preventDefault();
      warn.style.display = 'inline';
      warn.textContent   = 'This appears to be a placeholder number - sending blocked';
      return;
    }
    warn.style.display = 'none';
  });
})();
</script>

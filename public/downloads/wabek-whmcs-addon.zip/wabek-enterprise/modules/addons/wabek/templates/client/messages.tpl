{* WABEK Client — Message History *}
{include file="../../../modules/addons/wabek/templates/client/_nav.tpl"}

<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:14px;font-weight:600;color:#0f172a">📋 Message History</span>
    <span style="font-size:12px;color:#94a3b8">{$total} messages</span>
  </div>

  {if count($messages) > 0}
  <div class="table-responsive">
    <table class="table" style="margin:0;font-size:13px">
      <thead style="background:#f8fafc">
        <tr>
          <th style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.4px;border-top:none;padding:10px 16px">Date</th>
          <th style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.4px;border-top:none">Notification</th>
          <th style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.4px;border-top:none">Status</th>
        </tr>
      </thead>
      <tbody>
        {foreach $messages as $msg}
        <tr>
          <td style="color:#64748b;white-space:nowrap;padding:10px 16px">
            {$msg->created_at|date_format:"%d %b %Y"}<br>
            <small>{$msg->created_at|date_format:"%H:%M"}</small>
          </td>
          <td>
            <span style="background:#f1f5f9;color:#475569;font-size:11px;padding:2px 8px;border-radius:4px">
              {$msg->event|replace:'_':' '|capitalize}
            </span>
          </td>
          <td>
            {if $msg->status == 'delivered'}
              <span style="background:#dcfce7;color:#15803d;font-size:11px;padding:2px 10px;border-radius:99px;font-weight:600">✓ Delivered</span>
            {elseif $msg->status == 'read'}
              <span style="background:#ede9fe;color:#6d28d9;font-size:11px;padding:2px 10px;border-radius:99px;font-weight:600">✓✓ Read</span>
            {elseif $msg->status == 'sent'}
              <span style="background:#dbeafe;color:#1d4ed8;font-size:11px;padding:2px 10px;border-radius:99px;font-weight:600">✓ Sent</span>
            {elseif $msg->status == 'failed'}
              <span style="background:#fee2e2;color:#b91c1c;font-size:11px;padding:2px 10px;border-radius:99px;font-weight:600">✕ Failed</span>
            {else}
              <span style="background:#f1f5f9;color:#64748b;font-size:11px;padding:2px 10px;border-radius:99px">{$msg->status|capitalize}</span>
            {/if}
          </td>
        </tr>
        {/foreach}
      </tbody>
    </table>
  </div>

  {* Pagination *}
  {if $pages > 1}
  <div style="padding:12px 16px;border-top:1px solid #f1f5f9;display:flex;gap:4px;align-items:center">
    {if $page > 1}<a href="{$modulelink}&action=messages&p={$page-1}" class="btn btn-default btn-xs">‹</a>{/if}
    {section name=pag start=1 loop=$pages+1}
      {assign var="i" value=$smarty.section.pag.index}
      {if $i >= $page-3 && $i <= $page+3}
        {if $i == $page}
          <span class="btn btn-primary btn-xs">{$i}</span>
        {else}
          <a href="{$modulelink}&action=messages&p={$i}" class="btn btn-default btn-xs">{$i}</a>
        {/if}
      {/if}
    {/section}
    {if $page < $pages}<a href="{$modulelink}&action=messages&p={$page+1}" class="btn btn-default btn-xs">›</a>{/if}
  </div>
  {/if}

  {else}
  <div style="text-align:center;padding:40px;color:#94a3b8">
    <div style="font-size:32px;margin-bottom:8px">📭</div>
    <div style="font-size:14px;font-weight:500">No messages yet</div>
    <div style="font-size:13px;margin-top:4px">Notifications will appear here once sent</div>
  </div>
  {/if}
</div>

<?php
/**
 * WABEK Webhook Center
 * @var object $webhooks
 * @var int    $total
 * @var array  $types
 * @var string $filter
 * @var int    $page
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek&tab=webhooks';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['wabek_action'] ?? '';

    // Replay webhook
    if ($action === 'replay_webhook') {
        $id = (int)($_POST['webhook_id'] ?? 0);
        $wh = \WHMCS\Database\Capsule::table('mod_wabek_webhooks')->where('id', $id)->first();
        if ($wh && $wh->payload) {
            $data = json_decode($wh->payload, true);
            if ($data) {
                // Re-process
                $event  = $data['event'] ?? '';
                $msgId  = $data['messageId'] ?? $data['id'] ?? null;
                $status = $data['status'] ?? null;
                if ($msgId && $status) {
                    \Wabek\Models\Message::updateStatus($msgId, $status);
                    $_SESSION['wabek_flash'] = ['type' => 'success', 'msg' => "Webhook #{$id} replayed successfully."];
                }
            }
        }
    }

    // Test webhook
    if ($action === 'test_webhook') {
        $event = \Wabek\Middleware\AuthMiddleware::sanitize($_POST['webhook_event'] ?? 'message.status');
        $phone = preg_replace('/\D/', '', $_POST['webhook_phone'] ?? '');
        $msgId = 'test_' . uniqid();

        \WHMCS\Database\Capsule::table('mod_wabek_webhooks')->insert([
            'event_type' => $event,
            'message_id' => $msgId,
            'phone'      => $phone ?: null,
            'status'     => 'sent',
            'payload'    => json_encode(['event' => $event, 'messageId' => $msgId, 'phone' => $phone, 'status' => 'sent', '_test' => true]),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $_SESSION['wabek_flash'] = ['type' => 'success', 'msg' => "Test webhook created: {$event} (ID: {$msgId})"];
    }
}

$flash = $_SESSION['wabek_flash'] ?? null;
if ($flash) { echo '<div class="wb-alert '.$flash['type'].'">'.htmlspecialchars($flash['msg']).'</div>'; unset($_SESSION['wabek_flash']); }
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <h4 style="margin:0">🔔 Webhook Center</h4>
  <div style="display:flex;gap:8px">
    <button class="wb-btn wb-btn-secondary wb-btn-sm"
            onclick="document.getElementById('wbTestTool').style.display=document.getElementById('wbTestTool').style.display==='none'?'block':'none'">
      🧪 Test Webhook
    </button>
  </div>
</div>

<!-- Stats -->
<?php
$statRows = \WHMCS\Database\Capsule::table('mod_wabek_webhooks')
    ->select('event_type', \WHMCS\Database\Capsule::raw('COUNT(*) as count'))
    ->groupBy('event_type')->orderBy('count','desc')->limit(5)->get();
?>
<div class="wb-stat-cards" style="grid-template-columns:repeat(<?= max(2, $statRows->count()) ?>,1fr);margin-bottom:20px">
  <?php foreach ($statRows as $r): ?>
  <div class="wb-stat blue">
    <p class="wb-stat-val"><?= number_format($r->count) ?></p>
    <p class="wb-stat-lbl"><?= htmlspecialchars($r->event_type) ?></p>
  </div>
  <?php endforeach; ?>
  <?php if ($statRows->isEmpty()): ?>
  <div class="wb-stat blue"><p class="wb-stat-val">0</p><p class="wb-stat-lbl">No webhooks yet</p></div>
  <?php endif; ?>
</div>

<!-- Test Tool -->
<div id="wbTestTool" style="display:none" class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header"><h4>🧪 Webhook Test Tool</h4></div>
  <div class="wb-card-body">
    <p style="font-size:13px;color:#64748b;margin-bottom:14px">
      Create a test webhook entry to verify your integration.<br>
      <strong>Webhook URL</strong> to configure in WABEK Dashboard:
      <code style="background:#F1F5F9;padding:2px 8px;border-radius:4px;font-size:12px">
        <?= htmlspecialchars((\WHMCS\Config\Setting::getValue('SystemURL') ?? 'https://your-whmcs.com') . '/includes/hooks/wabek_notifications.php?wabek_webhook=1') ?>
      </code>
    </p>
    <form method="post" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
      <input type="hidden" name="wabek_action" value="test_webhook">
      <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
      <div class="wb-form-group" style="margin:0">
        <label class="wb-label">Event Type</label>
        <select name="webhook_event" class="wb-select" style="width:180px">
          <option value="message.status">message.status</option>
          <option value="message.delivered">message.delivered</option>
          <option value="message.read">message.read</option>
          <option value="message.failed">message.failed</option>
          <option value="message.incoming">message.incoming</option>
          <option value="instance.connected">instance.connected</option>
        </select>
      </div>
      <div class="wb-form-group" style="margin:0">
        <label class="wb-label">Test Phone (optional)</label>
        <input type="text" name="webhook_phone" class="wb-input" style="width:160px" placeholder="201234567890">
      </div>
      <button type="submit" class="wb-btn wb-btn-primary wb-btn-sm">Create Test Entry</button>
    </form>
  </div>
</div>

<!-- Webhook Inspector + Logs -->
<div class="wb-card">
  <div class="wb-card-header">
    <h4>📋 Webhook Activity Log</h4>
    <div style="display:flex;gap:6px;align-items:center">
      <span style="font-size:12px;color:#94a3b8"><?= number_format($total) ?> total</span>
      <a href="<?= $moduleLink ?>" class="wb-btn wb-btn-secondary wb-btn-sm <?= !$filter?'':'active' ?>">All</a>
      <?php foreach ($types as $type): ?>
      <a href="<?= $moduleLink ?>&type=<?= urlencode($type) ?>"
         class="wb-btn wb-btn-secondary wb-btn-sm <?= $filter===$type?'active':'' ?>"><?= htmlspecialchars($type) ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead>
        <tr>
          <th>Time</th>
          <th>Event</th>
          <th>Message ID</th>
          <th>Phone</th>
          <th>Status</th>
          <th>Error</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($webhooks as $wh): ?>
        <tr id="wh-<?= $wh->id ?>">
          <td style="font-size:11px;color:#64748b;white-space:nowrap">
            <?= date('d M Y', strtotime($wh->created_at)) ?><br>
            <?= date('H:i:s', strtotime($wh->created_at)) ?>
          </td>
          <td>
            <code style="font-size:11px;background:#F1F5F9;padding:2px 6px;border-radius:4px">
              <?= htmlspecialchars($wh->event_type) ?>
            </code>
          </td>
          <td style="font-family:monospace;font-size:10px;max-width:140px">
            <span title="<?= htmlspecialchars($wh->message_id ?? '') ?>">
              <?= htmlspecialchars(substr($wh->message_id ?? '', 0, 20)) ?><?= strlen($wh->message_id ?? '') > 20 ? '…' : '' ?>
            </span>
          </td>
          <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($wh->phone ?? '-') ?></td>
          <td>
            <?php if ($wh->status): ?>
            <span class="wb-badge <?= in_array($wh->status,['delivered','read','sent'])?$wh->status:'failed' ?>">
              <?= htmlspecialchars($wh->status) ?>
            </span>
            <?php else: ?>-<?php endif; ?>
          </td>
          <td style="font-size:11px;color:#DC2626;max-width:150px">
            <?= $wh->error_code ? "<strong>#{$wh->error_code}</strong> " : '' ?>
            <?= htmlspecialchars(substr($wh->error_msg ?? '', 0, 60)) ?>
          </td>
          <td>
            <div style="display:flex;gap:4px">
              <!-- Inspector -->
              <button class="wb-btn wb-btn-secondary wb-btn-sm"
                      onclick="toggleInspector(<?= $wh->id ?>)" title="Inspect payload">🔍</button>
              <!-- Replay -->
              <?php if (!empty($wh->payload)): ?>
              <form method="post" style="display:inline">
                <input type="hidden" name="wabek_action" value="replay_webhook">
                <input type="hidden" name="webhook_id" value="<?= $wh->id ?>">
                <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
                <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm" title="Replay this webhook">↺</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <!-- Inspector Row (hidden) -->
        <tr id="wh-inspect-<?= $wh->id ?>" style="display:none;background:#F8FAFC">
          <td colspan="7" style="padding:12px 20px">
            <div style="font-size:11px;font-weight:700;color:#64748b;margin-bottom:6px">
              🔍 Webhook Inspector - ID <?= $wh->id ?>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
              <div>
                <div style="font-size:11px;font-weight:600;color:#64748b;margin-bottom:4px">Parsed Fields</div>
                <table style="font-size:11px;border-collapse:collapse;width:100%">
                  <?php foreach ([
                    'ID'         => $wh->id,
                    'Event'      => $wh->event_type,
                    'Message ID' => $wh->message_id,
                    'Phone'      => $wh->phone,
                    'Status'     => $wh->status,
                    'Error Code' => $wh->error_code,
                    'Error'      => $wh->error_msg,
                    'Received'   => $wh->created_at,
                  ] as $k => $v): if ($v === null) continue; ?>
                  <tr style="border-bottom:1px solid #E2E8F0">
                    <td style="padding:3px 8px;color:#64748b;font-weight:600;width:90px"><?= $k ?></td>
                    <td style="padding:3px 8px;font-family:monospace;color:#0F172A"><?= htmlspecialchars((string)$v) ?></td>
                  </tr>
                  <?php endforeach; ?>
                </table>
              </div>
              <div>
                <div style="font-size:11px;font-weight:600;color:#64748b;margin-bottom:4px">Raw Payload</div>
                <pre style="font-size:10px;background:#0F172A;color:#22D366;padding:10px;border-radius:8px;margin:0;overflow:auto;max-height:200px"><?=
                  htmlspecialchars(json_encode(json_decode($wh->payload ?? '{}'), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE) ?: ($wh->payload ?? '(empty)'))
                ?></pre>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if ($webhooks->isEmpty()): ?>
        <tr>
          <td colspan="7" style="text-align:center;padding:48px;color:#94a3b8">
            <div style="font-size:32px;margin-bottom:8px">🔔</div>
            No webhook events received yet.<br>
            <small>Configure the Webhook URL in your WABEK Dashboard to start receiving events.</small>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if (ceil($total / 50) > 1): ?>
  <div style="padding:12px 20px;border-top:1px solid #E2E8F0">
    <div class="wb-pagination">
      <?php for ($i = 1; $i <= ceil($total/50); $i++): ?>
      <a href="<?= $moduleLink ?>&p=<?= $i ?><?= $filter ? '&type='.urlencode($filter) : '' ?>"
         class="<?= $i === ($page ?? 1) ? 'active' : '' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
function toggleInspector(id) {
  var row = document.getElementById('wh-inspect-' + id);
  if (row) row.style.display = row.style.display === 'none' ? 'table-row' : 'none';
}
</script>

<?php
/**
 * WABEK Media Library
 * @var array  $result
 * @var string $filterType
 * @var int    $page
 * @var mixed  $uploadResult
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek&tab=media';

$flash = $_SESSION['wabek_flash'] ?? null;
if ($flash) {
    echo '<div class="wb-alert ' . $flash['type'] . '">' . htmlspecialchars($flash['msg']) . '</div>';
    unset($_SESSION['wabek_flash']);
}
if ($uploadResult !== null) {
    if ($uploadResult['success']) {
        echo '<div class="wb-alert success">✓ File uploaded: <strong>' . htmlspecialchars($uploadResult['url']) . '</strong></div>';
    } else {
        echo '<div class="wb-alert danger">✕ Upload failed: ' . htmlspecialchars($uploadResult['error']) . '</div>';
    }
}
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <h4 style="margin:0">🖼️ Media Library</h4>
  <button class="wb-btn wb-btn-primary" onclick="document.getElementById('wbUploadPanel').style.display=document.getElementById('wbUploadPanel').style.display?'':'block'">
    ↑ Upload File
  </button>
</div>

<!-- Upload Panel -->
<div id="wbUploadPanel" style="display:none" class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header"><h4>Upload New File</h4></div>
  <div class="wb-card-body">
    <form method="post" enctype="multipart/form-data" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
      <input type="hidden" name="wabek_action" value="upload_media">
      <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
      <div class="wb-form-group" style="margin:0">
        <label class="wb-label">Select File</label>
        <input type="file" name="media_file" class="wb-input"
               accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.mp3,.ogg,.mp4,.3gp,.vcf"
               style="padding:6px 10px" required>
        <small style="color:#64748b">Images, PDF, Audio, Video · Max 16MB</small>
      </div>
      <button type="submit" class="wb-btn wb-btn-success">⬆ Upload</button>
    </form>
  </div>
</div>

<!-- Filter Tabs -->
<div style="display:flex;gap:6px;margin-bottom:16px;flex-wrap:wrap">
  <?php foreach ([''=>'All', 'image'=>'🖼 Images', 'document'=>'📄 Documents', 'audio'=>'🔊 Audio', 'video'=>'🎬 Video'] as $type => $label): ?>
  <a href="<?= $moduleLink ?>&type=<?= urlencode($type) ?>"
     class="wb-btn wb-btn-<?= $filterType === $type ? 'primary' : 'secondary' ?> wb-btn-sm">
    <?= $label ?>
  </a>
  <?php endforeach; ?>
  <span style="margin-left:auto;font-size:12px;color:#94a3b8;align-self:center">
    <?= number_format($result['total']) ?> files
  </span>
</div>

<!-- Grid -->
<?php if (!empty($result['items']) && $result['items']->isNotEmpty()): ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px;margin-bottom:20px">
  <?php foreach ($result['items'] as $file): ?>
  <div class="wb-card" style="margin:0;position:relative" id="media-<?= $file->id ?>">
    <!-- Preview -->
    <div style="height:130px;background:#F8FAFC;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:12px 12px 0 0">
      <?php if ($file->media_type === 'image' && $file->url): ?>
        <img src="<?= htmlspecialchars($file->url) ?>" alt=""
             style="max-width:100%;max-height:100%;object-fit:cover"
             onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div style="display:none;font-size:36px;align-items:center;justify-content:center;width:100%;height:100%">🖼️</div>
      <?php else: ?>
        <span style="font-size:40px"><?= match($file->media_type) {
          'document' => '📄',
          'audio'    => '🔊',
          'video'    => '🎬',
          'vcard'    => '👤',
          default    => '📎',
        } ?></span>
      <?php endif; ?>
    </div>

    <!-- Info -->
    <div style="padding:10px">
      <div style="font-size:12px;font-weight:600;color:#0F172A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
           title="<?= htmlspecialchars($file->original_name) ?>">
        <?= htmlspecialchars($file->original_name) ?>
      </div>
      <div style="font-size:11px;color:#94a3b8;margin-top:2px">
        <?= \Wabek\Services\MediaService::formatSize((int)$file->file_size) ?>
        · <?= date('d M Y', strtotime($file->created_at)) ?>
      </div>
      <?php if ($file->used_count > 0): ?>
      <div style="font-size:10px;color:#64748b;margin-top:2px">Used <?= $file->used_count ?>×</div>
      <?php endif; ?>
    </div>

    <!-- Actions -->
    <div style="padding:0 10px 10px;display:flex;gap:6px">
      <!-- Copy URL -->
      <button onclick="navigator.clipboard.writeText('<?= htmlspecialchars($file->url) ?>');this.textContent='Copied!';setTimeout(()=>this.textContent='📋 Copy',2000)"
              class="wb-btn wb-btn-secondary wb-btn-sm" style="flex:1;font-size:11px">
        📋 Copy URL
      </button>
      <!-- Delete -->
      <form method="post" style="display:inline">
        <input type="hidden" name="wabek_action" value="delete_media">
        <input type="hidden" name="media_id" value="<?= $file->id ?>">
        <input type="hidden" name="_wabek_csrf" value="<?= htmlspecialchars($csrf) ?>">
        <button type="submit" class="wb-btn wb-btn-danger wb-btn-sm"
                onclick="return confirm('Delete this file?')" title="Delete">🗑</button>
      </form>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($result['pages'] > 1): ?>
<div class="wb-pagination">
  <?php for ($i = 1; $i <= $result['pages']; $i++): ?>
    <a href="<?= $moduleLink ?>&p=<?= $i ?>&type=<?= urlencode($filterType) ?>"
       class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php else: ?>
<div style="text-align:center;padding:60px;background:#fff;border:1px dashed #CBD5E1;border-radius:12px">
  <div style="font-size:48px;margin-bottom:12px">🖼️</div>
  <div style="font-size:15px;font-weight:600;color:#475569">No media files yet</div>
  <div style="font-size:13px;color:#94a3b8;margin-top:4px">Upload images, PDFs, audio or video files</div>
  <button onclick="document.getElementById('wbUploadPanel').style.display='block'"
          class="wb-btn wb-btn-primary" style="margin-top:16px">↑ Upload First File</button>
</div>
<?php endif; ?>

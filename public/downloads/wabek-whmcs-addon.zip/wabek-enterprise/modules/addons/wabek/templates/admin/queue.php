<?php
/** @var object $items @var int $total @var array $stats @var string $status */
$moduleLink = 'addonmodules.php?module=wabek&tab=queue';
?>
<div class="wb-stat-cards" style="grid-template-columns:repeat(4,1fr)">
  <div class="wb-stat orange"><p class="wb-stat-val"><?= $stats['pending'] ?></p><p class="wb-stat-lbl">Pending</p></div>
  <div class="wb-stat blue"><p class="wb-stat-val"><?= $stats['processing'] ?></p><p class="wb-stat-lbl">Processing</p></div>
  <div class="wb-stat green"><p class="wb-stat-val"><?= $stats['sent'] ?></p><p class="wb-stat-lbl">Sent</p></div>
  <div class="wb-stat red"><p class="wb-stat-val"><?= $stats['failed'] ?></p><p class="wb-stat-lbl">Failed</p></div>
</div>

<div class="wb-card">
  <div class="wb-card-header">
    <h4>⚡ Message Queue</h4>
    <div style="display:flex;gap:6px">
      <?php foreach (['','pending','processing','sent','failed','cancelled'] as $s): ?>
      <a href="<?= $moduleLink ?>&status=<?= $s ?>" class="wb-btn wb-btn-secondary wb-btn-sm <?= $status === $s ? 'active' : '' ?>">
        <?= $s ? ucfirst($s) : 'All' ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead><tr><th>ID</th><th>Event</th><th>Phone</th><th>Status</th><th>Attempts</th><th>Scheduled</th><th>Error</th></tr></thead>
      <tbody>
        <?php foreach ($items as $item): ?>
        <tr>
          <td style="color:#94a3b8">#<?= $item->id ?></td>
          <td><code style="font-size:11px;background:#F1F5F9;padding:2px 6px;border-radius:4px"><?= htmlspecialchars($item->event) ?></code></td>
          <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($item->phone) ?></td>
          <td><span class="wb-badge <?= $item->status ?>"><?= ucfirst($item->status) ?></span></td>
          <td style="color:#64748b"><?= $item->attempts ?>/<?= $item->max_attempts ?></td>
          <td style="font-size:12px;color:#64748b"><?= $item->scheduled_at ? date('d M H:i', strtotime($item->scheduled_at)) : '-' ?></td>
          <td style="color:#DC2626;font-size:11px;max-width:150px"><?= htmlspecialchars(substr($item->error ?? '', 0, 60)) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if ($items->isEmpty()): ?>
        <tr><td colspan="7" style="text-align:center;padding:40px;color:#94a3b8">Queue is empty.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Dead Letter Queue -->
<?php
$dlq = \Wabek\Models\QueueItem::deadLetter(1, 20);
if ($dlq['total'] > 0): ?>
<div class="wb-card" style="border-color:#FECACA">
  <div class="wb-card-header" style="background:#FEF2F2">
    <h4 style="color:#B91C1C">💀 Dead Letter Queue (<?= $dlq['total'] ?> items)</h4>
    <form method="post">
      <input type="hidden" name="wabek_action" value="requeue_dead_all">
      <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm"
              onclick="return confirm('Requeue all failed messages for retry?')">
        ↺ Requeue All
      </button>
    </form>
  </div>
  <div style="overflow-x:auto">
    <table class="wb-table">
      <thead><tr><th>ID</th><th>Event</th><th>Phone</th><th>Attempts</th><th>Last Error</th><th>Failed At</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($dlq['items'] as $item): ?>
        <tr>
          <td style="color:#94a3b8">#<?= $item->id ?></td>
          <td><code style="font-size:11px;background:#F1F5F9;padding:2px 6px;border-radius:4px"><?= htmlspecialchars($item->event) ?></code></td>
          <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($item->phone) ?></td>
          <td style="color:#DC2626;font-weight:600"><?= $item->attempts ?>/<?= $item->max_attempts ?></td>
          <td style="color:#DC2626;font-size:11px;max-width:200px"><?= htmlspecialchars(substr($item->error ?? '', 0, 80)) ?></td>
          <td style="font-size:12px;color:#64748b"><?= date('d M H:i', strtotime($item->updated_at)) ?></td>
          <td>
            <form method="post" style="display:inline">
              <input type="hidden" name="wabek_action" value="requeue_item">
              <input type="hidden" name="queue_id" value="<?= $item->id ?>">
              <button type="submit" class="wb-btn wb-btn-secondary wb-btn-sm">↺ Retry</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

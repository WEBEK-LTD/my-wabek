<?php
/**
 * WABEK Analytics
 * @var array  $todayStats
 * @var array  $monthStats
 * @var array  $allTimeStats
 * @var array  $topEvents
 * @var array  $topCountries
 * @var array  $dailyChart
 * @var string $period
 * @var string $csrf
 */
$moduleLink = 'addonmodules.php?module=wabek&tab=analytics';
$period     = $_GET['period'] ?? '30';
?>

<!-- Period selector -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <h4 style="margin:0">📊 Analytics</h4>
  <div style="display:flex;gap:6px">
    <?php foreach (['7'=>'7 days','30'=>'30 days','90'=>'90 days'] as $d=>$l): ?>
    <a href="<?= $moduleLink ?>&period=<?= $d ?>"
       class="wb-btn wb-btn-<?= $period===$d?'primary':'secondary' ?> wb-btn-sm"><?= $l ?></a>
    <?php endforeach; ?>
  </div>
</div>

<!-- Key Metrics -->
<div class="wb-stat-cards" style="grid-template-columns:repeat(5,1fr);margin-bottom:24px">
  <?php
  $dr = $monthStats['total'] > 0 ? round($monthStats['delivered'] / $monthStats['total'] * 100, 1) : 0;
  $rr = $monthStats['total'] > 0 ? round($monthStats['read']      / $monthStats['total'] * 100, 1) : 0;
  $fr = $monthStats['total'] > 0 ? round($monthStats['failed']    / $monthStats['total'] * 100, 1) : 0;
  foreach ([
    ['Total Sent',    $monthStats['total'],     'blue'],
    ['Delivered',     $monthStats['delivered'], 'green'],
    ['Read',          $monthStats['read'],      '', '#6D28D9'],
    ['Failed',        $monthStats['failed'],    'red'],
    ['Delivery Rate', $dr.'%',                  'green'],
  ] as [$label,$val,$color,$custom_color]): ?>
  <div class="wb-stat <?= $color ?>">
    <p class="wb-stat-val" <?= isset($custom_color)?'style="color:'.$custom_color.'"':''  ?>><?= is_numeric($val) ? number_format((float)$val) : $val ?></p>
    <p class="wb-stat-lbl"><?= $label ?></p>
  </div>
  <?php endforeach; ?>
</div>

<!-- Chart -->
<div class="wb-card" style="margin-bottom:20px">
  <div class="wb-card-header"><h4>📈 Daily Messages - Last <?= $period ?> Days</h4></div>
  <div class="wb-card-body">
    <div class="wb-chart-wrap" style="height:280px">
      <canvas id="wbAnalyticsChart"></canvas>
    </div>
  </div>
</div>

<!-- Two columns: Top Events + Status Breakdown -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">

  <!-- Top Events -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>🔔 Top Events</h4></div>
    <div style="overflow:hidden">
      <table class="wb-table">
        <thead><tr><th>Event</th><th>Sent</th><th>Delivered</th><th>Rate</th></tr></thead>
        <tbody>
          <?php foreach ($topEvents as $ev): ?>
          <?php $evDr = $ev->total > 0 ? round($ev->delivered / $ev->total * 100) : 0; ?>
          <tr>
            <td><code style="font-size:11px;background:#F1F5F9;padding:2px 6px;border-radius:4px"><?= htmlspecialchars($ev->event) ?></code></td>
            <td><?= number_format($ev->total) ?></td>
            <td><?= number_format($ev->delivered) ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:6px">
                <div style="flex:1;height:5px;background:#E2E8F0;border-radius:99px;min-width:40px">
                  <div style="height:100%;width:<?= $evDr ?>%;background:#16A34A;border-radius:99px"></div>
                </div>
                <span style="font-size:11px;color:#64748b"><?= $evDr ?>%</span>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($topEvents)): ?>
          <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:20px">No data yet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Status Breakdown -->
  <div class="wb-card">
    <div class="wb-card-header"><h4>📊 Status Breakdown</h4></div>
    <div class="wb-card-body">
      <?php
      $statuses = [
        ['Sent',      $monthStats['sent'],      '#2563EB'],
        ['Delivered', $monthStats['delivered'], '#16A34A'],
        ['Read',      $monthStats['read'],      '#7C3AED'],
        ['Failed',    $monthStats['failed'],    '#DC2626'],
      ];
      $maxVal = max(array_column($statuses, 1)) ?: 1;
      foreach ($statuses as [$label, $val, $color]):
      ?>
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span style="font-size:13px;font-weight:500;color:#0F172A"><?= $label ?></span>
          <span style="font-size:12px;color:#64748b"><?= number_format($val) ?></span>
        </div>
        <div style="height:8px;background:#F1F5F9;border-radius:99px">
          <div style="height:100%;width:<?= $maxVal>0?round($val/$maxVal*100):0 ?>%;background:<?= $color ?>;border-radius:99px;transition:width .5s"></div>
        </div>
      </div>
      <?php endforeach; ?>

      <div style="border-top:1px solid #E2E8F0;padding-top:14px;margin-top:4px">
        <div style="display:flex;justify-content:space-between">
          <span style="font-size:12px;color:#64748b">Delivery Rate</span>
          <strong style="font-size:14px;color:#16A34A"><?= $dr ?>%</strong>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:4px">
          <span style="font-size:12px;color:#64748b">Read Rate</span>
          <strong style="font-size:14px;color:#7C3AED"><?= $rr ?>%</strong>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:4px">
          <span style="font-size:12px;color:#64748b">Failure Rate</span>
          <strong style="font-size:14px;color:#DC2626"><?= $fr ?>%</strong>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- All Time Stats -->
<div class="wb-card">
  <div class="wb-card-header"><h4>🏆 All Time Statistics</h4></div>
  <div class="wb-card-body">
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px">
      <?php foreach ([
        ['Total Messages',  $allTimeStats['total'],     '#2563EB'],
        ['Total Delivered', $allTimeStats['delivered'], '#16A34A'],
        ['Total Read',      $allTimeStats['read'],      '#7C3AED'],
        ['Total Failed',    $allTimeStats['failed'],    '#DC2626'],
      ] as [$label,$val,$color]): ?>
      <div style="text-align:center;padding:14px;background:#F8FAFC;border-radius:10px">
        <div style="font-size:24px;font-weight:700;color:<?= $color ?>"><?= number_format($val) ?></div>
        <div style="font-size:12px;color:#64748b;margin-top:2px"><?= $label ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script>
(function() {
  var ctx = document.getElementById('wbAnalyticsChart');
  if (!ctx) return;
  var labels   = <?= json_encode(array_column($dailyChart, 'date')) ?>;
  var sentData = <?= json_encode(array_column($dailyChart, 'total')) ?>;
  var dlvData  = <?= json_encode(array_column($dailyChart, 'delivered')) ?>;
  var failData = <?= json_encode(array_column($dailyChart, 'failed')) ?>;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        { label: 'Sent',      data: sentData, borderColor: '#2563EB', backgroundColor: 'rgba(37,99,235,.08)', tension: .3, fill: true, pointRadius: 2 },
        { label: 'Delivered', data: dlvData,  borderColor: '#16A34A', backgroundColor: 'rgba(22,163,74,.05)',  tension: .3, fill: false, pointRadius: 2 },
        { label: 'Failed',    data: failData, borderColor: '#DC2626', backgroundColor: 'rgba(220,38,38,.05)',  tension: .3, fill: false, pointRadius: 2 },
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: { legend: { position: 'top', labels: { font: { size: 12 }, boxWidth: 12 } } },
      scales: {
        x: { grid: { color: '#F1F5F9' }, ticks: { color: '#94A3B8', font: { size: 10 }, maxTicksLimit: 15 } },
        y: { grid: { color: '#F1F5F9' }, ticks: { color: '#94A3B8' }, beginAtZero: true }
      }
    }
  });
})();
</script>

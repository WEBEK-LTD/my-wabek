/* WABEK Enterprise Admin JS */
(function() {
  'use strict';

  // Auto-hide flash alerts
  document.querySelectorAll('.wb-alert').forEach(function(el) {
    if (el.classList.contains('success')) {
      setTimeout(function() {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity    = '0';
        setTimeout(function() { el.remove(); }, 600);
      }, 4000);
    }
  });

  // Confirm dangerous actions
  document.querySelectorAll('[data-confirm]').forEach(function(el) {
    el.addEventListener('click', function(e) {
      if (!confirm(el.dataset.confirm)) e.preventDefault();
    });
  });

  // Campaign modal close on backdrop click
  var modal = document.getElementById('newCampaignModal');
  if (modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) modal.style.display = 'none';
    });
  }

  // Slug auto-generate from name
  var nameField = document.querySelector('input[name="name"]');
  var slugField = document.querySelector('input[name="slug"]');
  if (nameField && slugField && !slugField.readOnly) {
    nameField.addEventListener('input', function() {
      slugField.value = nameField.value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_|_$/g, '');
    });
  }

  // Phone field: only allow digits
  document.querySelectorAll('input[name="phone"], input[name="test_phone"]').forEach(function(el) {
    el.addEventListener('input', function() {
      this.value = this.value.replace(/[^0-9+]/g, '');
    });
  });

})();

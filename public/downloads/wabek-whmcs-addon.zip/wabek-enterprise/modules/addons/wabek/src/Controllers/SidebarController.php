<?php
declare(strict_types=1);

namespace Wabek\Controllers;

use Wabek\Models\QueueItem;
use WHMCS\Database\Capsule;

class SidebarController
{
    private array $vars;

    public function __construct(array $vars)
    {
        $this->vars = $vars;
    }

    public function render(): string
    {
        $moduleLink = $this->vars['modulelink'] ?? 'addonmodules.php?module=wabek';
        $currentTab = $_GET['tab'] ?? 'dashboard';

        $queuePending = 0;
        try {
            $queuePending = Capsule::table('mod_wabek_queue')
                ->where('status', 'pending')->count();
        } catch (\Throwable $e) {}

        // Count unread inbox messages
        $unreadInbox = 0;
        try {
            $unreadInbox = Capsule::table('mod_wabek_conversations')
                ->where('status', 'open')
                ->sum('unread_count');
        } catch (\Throwable $e) {}

        $nav = [
            ['tab' => 'dashboard',  'icon' => 'fa-tachometer-alt', 'label' => 'Dashboard'],
            ['tab' => 'send',       'icon' => 'fa-paper-plane',    'label' => 'Send Message'],
            ['tab' => 'inbox',      'icon' => 'fa-inbox',          'label' => 'Inbox', 'badge' => (int)$unreadInbox],
            ['tab' => 'messages',   'icon' => 'fa-list',           'label' => 'Message Logs'],
            ['tab' => 'analytics',  'icon' => 'fa-chart-bar',      'label' => 'Analytics'],
            ['tab' => 'templates',  'icon' => 'fa-file-alt',       'label' => 'Templates'],
            ['tab' => 'campaigns',  'icon' => 'fa-bullhorn',       'label' => 'Campaigns'],
            ['tab' => 'queue',      'icon' => 'fa-tasks',          'label' => 'Queue', 'badge' => $queuePending],
            ['tab' => 'otp',        'icon' => 'fa-key',            'label' => 'OTP Logs'],
            ['tab' => 'media',      'icon' => 'fa-images',         'label' => 'Media Library'],
            ['tab' => 'abandoned_cart','icon' => 'fa-shopping-cart', 'label' => 'Abandoned Carts'],
            ['tab' => 'webhooks',   'icon' => 'fa-bell',           'label' => 'Webhooks'],
            ['tab' => 'settings',   'icon' => 'fa-cog',            'label' => 'Settings'],
            ['tab' => 'permissions','icon' => 'fa-user-shield',   'label' => 'Permissions'],
            ['tab' => 'diagnostics','icon' => 'fa-stethoscope',   'label' => 'Diagnostics'],
        ];

        $html = '<ul class="list-group wabek-sidebar">';
        $brandName = \Wabek\Config\Settings::brandName();
        $brandColor = \Wabek\Config\Settings::get('white_label_color', '#25D366');

        $html .= '<li class="list-group-item wabek-sidebar-title">';
        $html .= '<i class="fab fa-whatsapp" style="color:' . htmlspecialchars($brandColor) . ';margin-right:6px"></i>';
        $html .= '<strong>' . htmlspecialchars($brandName) . '</strong>';
        $html .= '</li>';

        foreach ($nav as $item) {
            $active = ($currentTab === $item['tab']) ? ' active' : '';
            $url    = $moduleLink . '&tab=' . $item['tab'];
            $badge  = '';

            if (!empty($item['badge']) && $item['badge'] > 0) {
                $badge = ' <span class="badge badge-warning">' . $item['badge'] . '</span>';
            }

            $html .= '<li class="list-group-item' . $active . '">';
            $html .= '<a href="' . $url . '" style="' . ($active ? 'color:#fff' : '') . '">';
            $html .= '<i class="fas ' . $item['icon'] . ' fa-fw" style="margin-right:6px"></i>';
            $html .= $item['label'] . $badge;
            $html .= '</a></li>';
        }

        $html .= '</ul>';
        return $html;
    }
}

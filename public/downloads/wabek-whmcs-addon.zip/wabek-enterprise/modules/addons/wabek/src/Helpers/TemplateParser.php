<?php
declare(strict_types=1);

namespace Wabek\Helpers;

class TemplateParser
{
    public static function parse(string $template, array $vars): string
    {
        foreach ($vars as $key => $value) {
            $template = str_replace(
                ['{{' . $key . '}}', '{' . $key . '}'],
                htmlspecialchars((string) $value, ENT_NOQUOTES),
                $template
            );
        }
        return $template;
    }

    public static function extractVariables(string $template): array
    {
        preg_match_all('/\{\{(\w+)\}\}/', $template, $matches);
        return array_unique($matches[1] ?? []);
    }

    public static function preview(string $template, array $sampleVars = []): string
    {
        $defaults = [
            'name'            => 'Ahmed Mohamed',
            'email'           => 'ahmed@example.com',
            'company'         => 'ACME Hosting',
            'invoice_id'      => '1234',
            'amount'          => '99.00',
            'currency'        => 'USD',
            'due_date'        => date('d M Y', strtotime('+7 days')),
            'domain'          => 'example.com',
            'service'         => 'Web Hosting',
            'ticket_id'       => 'TKT-5678',
            'subject'         => 'Help with my account',
            'otp'             => '123456',
            'expiry_minutes'  => '10',
            'days'            => '7',
            'portal_url'      => 'https://example.com/portal',
            'reset_link'      => 'https://example.com/reset?token=xxx',
            'order_id'        => 'ORD-001',
            'total'           => '199.00',
            'cart_items'      => '• Web Hosting Plan ($99/yr)',
            'message'         => 'We have an exciting offer for you!',
        ];

        return self::parse($template, array_merge($defaults, $sampleVars));
    }
}

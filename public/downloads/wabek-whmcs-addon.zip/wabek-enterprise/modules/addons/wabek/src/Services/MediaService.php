<?php
declare(strict_types=1);

namespace Wabek\Services;

use WHMCS\Database\Capsule;
use Wabek\Bootstrap\App;

class MediaService
{
    private const ALLOWED_MIME = [
        'image/jpeg'       => ['jpg','jpeg'],
        'image/png'        => ['png'],
        'image/gif'        => ['gif'],
        'image/webp'       => ['webp'],
        'application/pdf'  => ['pdf'],
        'audio/mpeg'       => ['mp3'],
        'audio/ogg'        => ['ogg'],
        'video/mp4'        => ['mp4'],
        'video/3gpp'       => ['3gp'],
        'text/vcard'       => ['vcf'],
    ];

    private const MAX_SIZE_MB = 16;

    public static function upload(array $file, int $adminId = 0): array
    {
        // Validate
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'error' => 'Upload error code: ' . $file['error']];
        }

        $sizeMb = $file['size'] / (1024 * 1024);
        if ($sizeMb > self::MAX_SIZE_MB) {
            return ['success' => false, 'error' => "File too large ({$sizeMb}MB). Max: " . self::MAX_SIZE_MB . "MB"];
        }

        $mime = mime_content_type($file['tmp_name']);
        if (!isset(self::ALLOWED_MIME[$mime])) {
            return ['success' => false, 'error' => "File type not allowed: {$mime}"];
        }

        $mediaType = self::getMediaType($mime);
        $ext       = self::ALLOWED_MIME[$mime][0];
        $filename  = bin2hex(random_bytes(12)) . '.' . $ext;
        $uploadDir = App::rootDir() . '/media/';

        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

        $destPath = $uploadDir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            return ['success' => false, 'error' => 'Failed to save file'];
        }

        // Generate URL
        $systemUrl = \WHMCS\Config\Setting::getValue('SystemURL') ?? '';
        $url       = rtrim($systemUrl, '/') . '/modules/addons/wabek/media/' . $filename;

        // Store in DB
        $id = (int) Capsule::table('mod_wabek_media')->insertGetId([
            'filename'      => $filename,
            'original_name' => $file['name'],
            'mime_type'     => $mime,
            'file_size'     => $file['size'],
            'storage_path'  => $destPath,
            'url'           => $url,
            'media_type'    => $mediaType,
            'uploaded_by'   => $adminId,
            'used_count'    => 0,
            'created_at'    => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ]);

        return [
            'success'    => true,
            'id'         => $id,
            'filename'   => $filename,
            'url'        => $url,
            'media_type' => $mediaType,
            'mime'       => $mime,
            'size_mb'    => round($sizeMb, 2),
        ];
    }

    private static function tableExists(): bool
    {
        static $checked = null;
        if ($checked === null) {
            $checked = Capsule::schema()->hasTable('mod_wabek_media');
        }
        return $checked;
    }

    public static function list(string $type = '', int $page = 1, int $perPage = 24): array
    {
        if (!self::tableExists()) return ['items' => collect(), 'total' => 0, 'pages' => 0];
        $q = Capsule::table('mod_wabek_media')->orderBy('created_at', 'desc');
        if ($type) $q->where('media_type', $type);
        $total = $q->count();
        $items = $q->offset(($page-1)*$perPage)->limit($perPage)->get();
        return ['items' => $items, 'total' => $total, 'pages' => (int)ceil($total/$perPage)];
    }

    public static function delete(int $id): bool
    {
        $row = Capsule::table('mod_wabek_media')->where('id', $id)->first();
        if (!$row) return false;

        if (file_exists($row->storage_path)) {
            @unlink($row->storage_path);
        }
        Capsule::table('mod_wabek_media')->where('id', $id)->delete();
        return true;
    }

    public static function incrementUsage(int $id): void
    {
        Capsule::table('mod_wabek_media')->where('id', $id)->increment('used_count');
    }

    public static function find(int $id): ?object
    {
        return Capsule::table('mod_wabek_media')->where('id', $id)->first();
    }

    private static function getMediaType(string $mime): string
    {
        if (str_starts_with($mime, 'image/'))      return 'image';
        if ($mime === 'application/pdf')            return 'document';
        if (str_starts_with($mime, 'audio/'))      return 'audio';
        if (str_starts_with($mime, 'video/'))      return 'video';
        if ($mime === 'text/vcard')                 return 'vcard';
        return 'document';
    }

    public static function formatSize(int $bytes): string
    {
        if ($bytes >= 1048576) return round($bytes/1048576, 1) . ' MB';
        if ($bytes >= 1024)    return round($bytes/1024, 1)    . ' KB';
        return $bytes . ' B';
    }
}

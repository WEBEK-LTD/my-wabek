<?php
declare(strict_types=1);

namespace Wabek\Models;

use WHMCS\Database\Capsule;

class Template
{
    public static function find(string $slug): ?object
    {
        return Capsule::table('mod_wabek_templates')
            ->where('slug', $slug)
            ->where('is_active', true)
            ->first();
    }

    public static function all(string $category = ''): array
    {
        $q = Capsule::table('mod_wabek_templates')->orderBy('category')->orderBy('name');
        if ($category) $q->where('category', $category);
        return $q->get()->toArray();
    }

    public static function save(array $data, int $changedBy = 0): void
    {
        if (!empty($data['id'])) {
            $id = (int) $data['id'];

            // Save version snapshot BEFORE update
            $existing = Capsule::table('mod_wabek_templates')->where('id', $id)->first();
            if ($existing && !empty($data['content']) && $data['content'] !== $existing->content
                && Capsule::schema()->hasTable('mod_wabek_template_versions')) {
                try {
                    Capsule::table('mod_wabek_template_versions')->insert([
                        'template_id' => $id,
                        'content'     => $existing->content,
                        'version'     => $existing->version ?? 1,
                        'changed_by'  => $changedBy ?: null,
                        'notes'       => 'Auto-saved before edit',
                        'created_at'  => date('Y-m-d H:i:s'),
                        'updated_at'  => date('Y-m-d H:i:s'),
                    ]);
                } catch (\Throwable $e) {}
                $data['version'] = (int)($existing->version ?? 1) + 1;
            }

            unset($data['id']);
            $data['updated_at'] = date('Y-m-d H:i:s');
            Capsule::table('mod_wabek_templates')->where('id', $id)->update($data);
        } else {
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['updated_at'] = date('Y-m-d H:i:s');
            Capsule::table('mod_wabek_templates')->insert($data);
        }
    }

    public static function versions(int $templateId): array
    {
        // Guard: table may not exist on old installations
        if (!Capsule::schema()->hasTable('mod_wabek_template_versions')) {
            return [];
        }
        return Capsule::table('mod_wabek_template_versions as v')
            ->leftJoin('tbladmins as a', 'a.id', '=', 'v.changed_by')
            ->select('v.*', 'a.firstname', 'a.lastname')
            ->where('v.template_id', $templateId)
            ->orderBy('v.created_at', 'desc')
            ->limit(20)
            ->get()
            ->toArray();
    }

    public static function restoreVersion(int $versionId, int $templateId): bool
    {
        $ver = Capsule::table('mod_wabek_template_versions')
            ->where('id', $versionId)
            ->where('template_id', $templateId)
            ->first();
        if (!$ver) return false;

        self::save(['id' => $templateId, 'content' => $ver->content]);
        return true;
    }

    public static function delete(int $id): void
    {
        Capsule::table('mod_wabek_templates')
            ->where('id', $id)
            ->where('is_system', false)
            ->delete();
    }

    public static function duplicate(int $id): void
    {
        $tpl = Capsule::table('mod_wabek_templates')->where('id', $id)->first();
        if (!$tpl) return;

        Capsule::table('mod_wabek_templates')->insert([
            'slug'       => $tpl->slug . '_copy_' . time(),
            'name'       => $tpl->name . ' (Copy)',
            'category'   => $tpl->category,
            'content'    => $tpl->content,
            'variables'  => $tpl->variables,
            'is_active'  => false,
            'is_system'  => false,
            'version'    => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function categories(): array
    {
        return Capsule::table('mod_wabek_templates')
            ->distinct()
            ->orderBy('category')
            ->pluck('category')
            ->toArray();
    }
}

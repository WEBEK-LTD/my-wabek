<?php
declare(strict_types=1);

namespace Wabek\Services;

use Wabek\Models\Campaign;
use Wabek\Config\Settings;
use Wabek\Helpers\PhoneHelper;
use Wabek\Models\Message;
use WHMCS\Database\Capsule;

class CampaignService
{
    // ── Create Campaign ────────────────────────────────────────────────────
    public static function create(string $name, string $message, array $options = []): int
    {
        return Campaign::create([
            'name'         => $name,
            'message'      => $message,
            'template_key' => $options['template_key'] ?? '',
            'instance_id'  => $options['instance_id']  ?? Settings::instanceId(),
            'segment'      => json_encode($options['segment'] ?? []),
            'delay_ms'     => (int)($options['delay_ms'] ?? Settings::int('queue_delay_ms', 500)),
            'scheduled_at' => $options['scheduled_at'] ?? null,
            'created_by'   => (int)($options['admin_id'] ?? 0),
        ]);
    }

    // ── Build Recipients ───────────────────────────────────────────────────
    public static function buildRecipients(int $campaignId, array $segment): int
    {
        $clients = self::getClientsBySegment($segment);
        $count   = 0;
        $skipped = 0;

        foreach ($clients as $client) {
            // ── CRITICAL: Cast to int - Capsule returns strings in strict_types mode
            $clientId = (int) $client->id;

            if ($clientId <= 0) {
                logActivity("WABEK Campaign #{$campaignId}: skipped - invalid client id: " . var_export($client->id, true));
                $skipped++;
                continue;
            }

            // Get phone with full result for logging
            $phoneResult = PhoneHelper::getClientPhoneResult($clientId);

            if (!$phoneResult['valid']) {
                logActivity(sprintf(
                    'WABEK Campaign #%d: skipped client #%d - phone invalid: original="%s" source=%s error=%s',
                    $campaignId, $clientId,
                    $phoneResult['original'] ?? '(empty)',
                    $phoneResult['source']   ?? 'unknown',
                    $phoneResult['error']    ?? 'unknown'
                ));
                $skipped++;
                continue;
            }

            $phone = $phoneResult['phone'];
            $name  = trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? ''));

            Capsule::table('mod_wabek_campaign_recipients')->insert([
                'campaign_id' => $campaignId,
                'client_id'   => $clientId,
                'phone'       => $phone,
                'name'        => $name ?: ('Client #' . $clientId),
                'status'      => 'pending',
            ]);
            $count++;
        }

        Capsule::table('mod_wabek_campaigns')
            ->where('id', $campaignId)
            ->update([
                'total_recipients' => $count,
                'updated_at'       => date('Y-m-d H:i:s'),
            ]);

        if ($skipped > 0) {
            logActivity("WABEK Campaign #{$campaignId}: built {$count} recipients, skipped {$skipped} (invalid phone or ID)");
        }

        return $count;
    }

    // ── Process Batch ──────────────────────────────────────────────────────
    public static function processBatch(int $campaignId, int $batchSize = 20): array
    {
        $campaign = Campaign::find($campaignId);
        if (!$campaign || $campaign->status !== Campaign::STATUS_RUNNING) {
            return ['processed' => 0, 'done' => true];
        }

        $recipients = Capsule::table('mod_wabek_campaign_recipients')
            ->where('campaign_id', $campaignId)
            ->where('status', 'pending')
            ->limit($batchSize)
            ->get();

        if ($recipients->isEmpty()) {
            Campaign::updateStatus($campaignId, Campaign::STATUS_COMPLETED);
            return ['processed' => 0, 'done' => true];
        }

        $wa          = new WhatsAppService();
        $delayMs     = (int)($campaign->delay_ms ?? 500);
        $templateKey = !empty($campaign->template_key) ? $campaign->template_key : null;
        $count       = 0;

        foreach ($recipients as $recipient) {
            // ── Validate phone from recipient record ───────────────────────
            $storedPhone = trim((string)($recipient->phone ?? ''));

            // Validate stored phone (should already be clean, but double-check)
            $phoneCheck = PhoneHelper::normalize($storedPhone);
            if (!$phoneCheck['valid']) {
                // Phone in DB is invalid - log and skip
                $errMsg = sprintf(
                    'Invalid phone in campaign_recipients #%d: "%s" - %s',
                    (int)$recipient->id, $storedPhone, $phoneCheck['error']
                );
                logActivity("WABEK Campaign #{$campaignId}: {$errMsg}");

                Capsule::table('mod_wabek_campaign_recipients')
                    ->where('id', (int)$recipient->id)
                    ->update([
                        'status'  => 'failed',
                        'error'   => $errMsg,
                        'sent_at' => date('Y-m-d H:i:s'),
                    ]);
                Campaign::incrementStat($campaignId, 'failed_count');
                $count++;
                continue;
            }

            $phone   = $phoneCheck['phone'];
            $message = self::buildMessage($campaign->message, [
                'name'    => $recipient->name ?? 'Customer',
                'phone'   => $phone,
                'company' => Settings::get('company_name', ''),
            ]);

            // ── Send ───────────────────────────────────────────────────────
// Use media send if campaign has media attached
            $result = (!empty($campaign->media_url) && !empty($campaign->media_type))
                ? $wa->sendMedia($phone, $campaign->media_url, $campaign->media_type, $message)
                : $wa->sendText($phone, $message);
            $status = $result['success'] ? 'sent' : 'failed';

            // Log to messages table with full phone + template info
            Message::create([
                'client_id'        => (int)($recipient->client_id ?? 0) ?: null,
                'phone'            => $phone,
                'event'            => 'campaign',
                'template_key'     => $templateKey,
                'content'          => $message,
                'status'           => $result['success'] ? Message::STATUS_SENT : Message::STATUS_FAILED,
                'message_id'       => $result['messageId'] ?? null,
                'error_msg'        => $result['error'] ?? null,
                'error_code'       => $result['error_code'] ?? null,
                'sent_at'          => $result['success'] ? date('Y-m-d H:i:s') : null,
                'provider_response'=> json_encode([
                    'campaign_id'      => $campaignId,
                    'recipient_id'     => (int)$recipient->id,
                    'phone_original'   => $storedPhone,
                    'phone_normalized' => $phone,
                    'phone_e164'       => $phoneCheck['e164'],
                    'template_used'    => $templateKey ?? '(none - plain text)',
                    'api_response'     => $result,
                ]),
            ]);

            Capsule::table('mod_wabek_campaign_recipients')
                ->where('id', (int)$recipient->id)
                ->update([
                    'status'     => $status,
                    'message_id' => $result['messageId'] ?? null,
                    'error'      => $result['error'] ?? null,
                    'sent_at'    => date('Y-m-d H:i:s'),
                ]);

            if ($result['success']) {
                Campaign::incrementStat($campaignId, 'sent_count');
                // Log campaign event
                Capsule::table('mod_wabek_campaign_events')->insert([
                    'campaign_id' => $campaignId,
                    'event_type'  => 'sent',
                    'client_id'   => (int)($recipient->client_id ?? 0) ?: null,
                    'phone'       => $phone,
                    'data'        => json_encode(['message_id' => $result['messageId'] ?? null]),
                    'created_at'  => date('Y-m-d H:i:s'),
                    'updated_at'  => date('Y-m-d H:i:s'),
                ]);
            } else {
                Campaign::incrementStat($campaignId, 'failed_count');
                Capsule::table('mod_wabek_campaign_events')->insert([
                    'campaign_id' => $campaignId,
                    'event_type'  => 'failed',
                    'client_id'   => (int)($recipient->client_id ?? 0) ?: null,
                    'phone'       => $phone,
                    'data'        => json_encode(['error' => $result['error'] ?? '']),
                    'created_at'  => date('Y-m-d H:i:s'),
                    'updated_at'  => date('Y-m-d H:i:s'),
                ]);
            }

            $count++;
            if ($delayMs > 0 && $count < $recipients->count()) {
                usleep($delayMs * 1000);
            }
        }

        // Check if completed
        $pending = Capsule::table('mod_wabek_campaign_recipients')
            ->where('campaign_id', $campaignId)
            ->where('status', 'pending')
            ->count();

        if ($pending === 0) {
            Campaign::updateStatus($campaignId, Campaign::STATUS_COMPLETED);
            return ['processed' => $count, 'done' => true];
        }

        return ['processed' => $count, 'done' => false];
    }

    // ── Build Message ──────────────────────────────────────────────────────
    private static function buildMessage(string $template, array $vars): string
    {
        foreach ($vars as $k => $v) {
            $template = str_replace(
                ['{{' . $k . '}}', '{' . $k . '}'],
                (string)$v,
                $template
            );
        }
        return $template;
    }

    // ── Get Clients By Segment ─────────────────────────────────────────────
    private static function getClientsBySegment(array $segment): object
    {
        // Default: Active clients only. Allow override via segment.
        $status = !empty($segment['status']) ? $segment['status'] : 'Active';
        $q      = Capsule::table('tblclients')->where('status', $status);

        if (!empty($segment['country'])) {
            $q->where('country', $segment['country']);
        }
        if (!empty($segment['currency'])) {
            $q->where('currency', (int)$segment['currency']);
        }
        if (!empty($segment['group_id'])) {
            $q->where('groupid', (int)$segment['group_id']);
        }
        if (!empty($segment['client_ids']) && is_array($segment['client_ids'])) {
            $ids = array_filter(array_map('intval', $segment['client_ids']));
            if ($ids) $q->whereIn('id', $ids);
        }

        return $q->select('id', 'firstname', 'lastname', 'email', 'phonenumber')->get();
    }
}

<?php
declare(strict_types=1);

namespace Wabek\Helpers;

use WHMCS\Database\Capsule;

class ClientHelper
{
    private static array $cache = [];

    public static function get(int $clientId): ?object
    {
        if (isset(self::$cache[$clientId])) {
            return self::$cache[$clientId];
        }

        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        self::$cache[$clientId] = $client;
        return $client;
    }

    public static function getName(int $clientId): string
    {
        $c = self::get($clientId);
        return $c ? trim(($c->firstname ?? '') . ' ' . ($c->lastname ?? '')) : 'Customer';
    }

    public static function getEmail(int $clientId): string
    {
        return (string) (self::get($clientId)?->email ?? '');
    }

    public static function getPortalUrl(): string
    {
        return rtrim((string) (\WHMCS\Config\Setting::getValue('SystemURL') ?? ''), '/');
    }

    public static function getCompanyName(): string
    {
        return (string) (\WHMCS\Config\Setting::getValue('CompanyName') ?? '');
    }

    public static function getInvoiceVars(int $invoiceId): array
    {
        $inv = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
        if (!$inv) return [];

        $currency = Capsule::table('tblcurrencies')->where('id', $inv->currency ?? 1)->value('code') ?? 'USD';

        return [
            'invoice_id' => (string) $invoiceId,
            'amount'     => number_format((float) $inv->total, 2),
            'currency'   => $currency,
            'due_date'   => $inv->duedate ? date('d M Y', strtotime($inv->duedate)) : '',
            'portal_url' => self::getPortalUrl() . '/viewinvoice.php?id=' . $invoiceId,
        ];
    }

    public static function getTicketVars(int $ticketId): array
    {
        $ticket = Capsule::table('tbltickets')->where('id', $ticketId)->first();
        if (!$ticket) return [];

        return [
            'ticket_id'  => (string) ($ticket->tid ?? $ticketId),
            'subject'    => (string) ($ticket->title ?? ''),
            'portal_url' => self::getPortalUrl() . '/viewticket.php?tid=' . ($ticket->tid ?? $ticketId),
        ];
    }

    public static function getServiceVars(array $params): array
    {
        return [
            'service'    => (string) ($params['productname'] ?? $params['servicename'] ?? 'Service'),
            'domain'     => (string) ($params['domain'] ?? ''),
            'portal_url' => self::getPortalUrl() . '/clientarea.php?action=services',
        ];
    }

    public static function getDomainVars(string $domain): array
    {
        $d = Capsule::table('tbldomains')->where('domain', $domain)->first();
        return [
            'domain'      => $domain,
            'expiry_date' => $d ? date('d M Y', strtotime($d->expirydate)) : '',
            'portal_url'  => self::getPortalUrl() . '/clientarea.php?action=domains',
        ];
    }
}

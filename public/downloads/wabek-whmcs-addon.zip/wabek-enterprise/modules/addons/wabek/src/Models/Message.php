<?php
declare(strict_types=1);

namespace Wabek\Models;

use WHMCS\Database\Capsule;

class Message
{
    public const STATUS_QUEUED    = 'queued';
    public const STATUS_SENT      = 'sent';
    public const STATUS_DELIVERED = 'delivered';
    public const STATUS_READ      = 'read';
    public const STATUS_FAILED    = 'failed';

    public static function create(array $data): int
    {
        // Normalize template_key - never store null when we have a value
        if (isset($data['template_key']) && $data['template_key'] === null) {
            unset($data['template_key']); // let DB default handle it
        }

        // Normalize error fields - never store 'undefined' string
        foreach (['error_msg', 'error_code'] as $field) {
            if (isset($data[$field]) && $data[$field] === 'undefined') {
                $data[$field] = null;
            }
        }

        return (int) Capsule::table('mod_wabek_messages')->insertGetId(array_merge([
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ], $data));
    }

    // Meta error code -> human readable
    public const META_ERRORS = [
        131026 => 'Message Undeliverable - recipient may have blocked or opted out',
        131047 => 'Re-engagement message - customer outside 24h window, use a template',
        131009 => 'Invalid phone number - check E.164 format',
        131000 => 'Message failed to send',
        131042 => 'Business account issue - check Meta Business Manager',
        130429 => 'Rate limit hit - reduce sending speed',
        132000 => 'Template parameter count mismatch',
        132001 => 'Template not found or not approved by Meta',
    ];

    public static function updateStatus(string $messageId, string $status, array $extra = []): void
    {
        if (empty($messageId)) return;

        // Classify Meta errors
        $errorCode = $extra['error_code'] ?? null;
        if ($errorCode && isset(self::META_ERRORS[(int)$errorCode])) {
            $extra['error_msg'] = ($extra['error_msg'] ?? '') ?:
                '#' . $errorCode . ' - ' . self::META_ERRORS[(int)$errorCode];
        }

        // 131026 = "accepted" by Meta but undeliverable - keep as failed with detail
        $resolvedStatus = $status;
        if ((int)$errorCode === 131026 || (int)$errorCode === 131047) {
            $resolvedStatus = self::STATUS_FAILED;
            $extra['error_category'] = $errorCode == 131047 ? 'OUTSIDE_WINDOW' : 'UNDELIVERABLE';
        }

        $data = array_merge(
            ['status' => $resolvedStatus, 'updated_at' => date('Y-m-d H:i:s')],
            $extra
        );

        if ($resolvedStatus === self::STATUS_DELIVERED) $data['delivered_at'] = date('Y-m-d H:i:s');
        if ($resolvedStatus === self::STATUS_READ)      $data['read_at']      = date('Y-m-d H:i:s');

        Capsule::table('mod_wabek_messages')
            ->where('message_id', $messageId)
            ->update($data);
    }

    public static function findByMessageId(string $messageId): ?object
    {
        return Capsule::table('mod_wabek_messages')
            ->where('message_id', $messageId)
            ->first();
    }

    public static function paginate(int $page = 1, int $perPage = 50, array $filters = []): array
    {
        $q = Capsule::table('mod_wabek_messages as m')
            ->leftJoin('tblclients as c', 'c.id', '=', 'm.client_id')
            ->select('m.*', 'c.firstname', 'c.lastname', 'c.email')
            ->orderBy('m.created_at', 'desc');

        if (!empty($filters['status']))     $q->where('m.status', $filters['status']);
        if (!empty($filters['event']))      $q->where('m.event', $filters['event']);
        if (!empty($filters['client_id']))  $q->where('m.client_id', $filters['client_id']);
        if (!empty($filters['phone']))      $q->where('m.phone', 'like', '%' . $filters['phone'] . '%');
        if (!empty($filters['date_from']))  $q->where('m.sent_at', '>=', $filters['date_from']);
        if (!empty($filters['date_to']))    $q->where('m.sent_at', '<=', $filters['date_to']);
        if (!empty($filters['search']))     {
            $s = $filters['search'];
            $q->where(function($q2) use ($s) {
                $q2->where('m.phone', 'like', "%$s%")
                   ->orWhere('c.firstname', 'like', "%$s%")
                   ->orWhere('c.email', 'like', "%$s%");
            });
        }

        $total  = $q->count();
        $items  = $q->offset(($page - 1) * $perPage)->limit($perPage)->get();

        return ['items' => $items, 'total' => $total, 'pages' => (int) ceil($total / $perPage), 'page' => $page];
    }

    public static function stats(string $period = 'today'): array
    {
        $q = Capsule::table('mod_wabek_messages');

        if ($period === 'today') {
            $q->whereDate('created_at', date('Y-m-d'));
        } elseif ($period === 'month') {
            $q->whereYear('created_at', date('Y'))->whereMonth('created_at', date('m'));
        }

        $rows = $q->select(
            Capsule::raw('COUNT(*) as total'),
            Capsule::raw('SUM(status = "sent") as sent'),
            Capsule::raw('SUM(status = "delivered") as delivered'),
            Capsule::raw('SUM(status = "read") as `read`'),
            Capsule::raw('SUM(status = "failed") as failed')
        )->first();

        return [
            'total'     => (int) ($rows->total ?? 0),
            'sent'      => (int) ($rows->sent ?? 0),
            'delivered' => (int) ($rows->delivered ?? 0),
            'read'      => (int) ($rows->read ?? 0),
            'failed'    => (int) ($rows->failed ?? 0),
        ];
    }

    public static function chartData(int $days = 30): array
    {
        $rows = Capsule::table('mod_wabek_messages')
            ->select(
                Capsule::raw('DATE(created_at) as date'),
                Capsule::raw('COUNT(*) as total'),
                Capsule::raw('SUM(status = "delivered") as delivered'),
                Capsule::raw('SUM(status = "failed") as failed')
            )
            ->where('created_at', '>=', date('Y-m-d', strtotime("-{$days} days")))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return $rows->toArray();
    }

    public static function exportCsv(array $filters = []): string
    {
        $result = self::paginate(1, 10000, $filters);
        $rows   = $result['items'];

        $csv  = "ID,Date,Event,Client,Phone,Status,Message ID,Error\n";
        foreach ($rows as $r) {
            $name = trim(($r->firstname ?? '') . ' ' . ($r->lastname ?? ''));
            $csv .= implode(',', [
                $r->id,
                '"' . ($r->sent_at ?? $r->created_at) . '"',
                '"' . $r->event . '"',
                '"' . addslashes($name) . '"',
                '"' . $r->phone . '"',
                $r->status,
                '"' . ($r->message_id ?? '') . '"',
                '"' . addslashes($r->error_msg ?? '') . '"',
            ]) . "\n";
        }
        return $csv;
    }
}

<?php
declare(strict_types=1);

namespace Wabek\Hooks;

use Wabek\Config\Settings;
use Wabek\Services\NotificationService;
use Wabek\Helpers\ClientHelper;

class EventHandler
{
    private static bool $booted = false;

    public static function register(): void
    {
        if (self::$booted) return;
        self::$booted = true;

        // ── Billing ──────────────────────────────────────────────────────
        add_hook('InvoiceCreation', 1, function(array $v): void {
            self::handle('invoice_created', (int)(string)($v['userid'] ?? 0), [
                ...ClientHelper::getInvoiceVars((int)($v['invoiceid'] ?? 0)),
            ]);
        });

        add_hook('InvoicePaid', 1, function(array $v): void {
            $inv = \WHMCS\Database\Capsule::table('tblinvoices')->where('id', $v['invoiceid'])->first();
            self::handle('invoice_paid', (int)($inv->userid ?? 0), [
                ...ClientHelper::getInvoiceVars((int)$v['invoiceid']),
            ]);
        });

        add_hook('InvoicePaymentReminder', 1, function(array $v): void {
            $inv = \WHMCS\Database\Capsule::table('tblinvoices')->where('id', $v['invoiceid'])->first();
            self::handle('payment_reminder', (int)($inv->userid ?? 0), [
                ...ClientHelper::getInvoiceVars((int)$v['invoiceid']),
            ]);
        });

        add_hook('OverdueInvoice', 1, function(array $v): void {
            $inv = \WHMCS\Database\Capsule::table('tblinvoices')->where('id', $v['invoiceid'])->first();
            self::handle('invoice_overdue', (int)($inv->userid ?? 0), [
                ...ClientHelper::getInvoiceVars((int)$v['invoiceid']),
            ]);
        });

        // ── Orders ───────────────────────────────────────────────────────
        add_hook('OrderPaid', 1, function(array $v): void {
            self::handle('order_placed', (int)(string)($v['userid'] ?? 0), [
                'order_id' => (string)($v['orderid'] ?? ''),
                'total'    => number_format((float)($v['amount'] ?? 0), 2),
                'currency' => \WHMCS\Config\Setting::getValue('DefaultCurrency') ?? 'USD',
                'portal_url' => ClientHelper::getPortalUrl() . '/clientarea.php?action=orders',
            ]);
        });

        // ── Services ─────────────────────────────────────────────────────
        add_hook('AfterModuleCreate', 1, function(array $v): void {
            self::handle('service_activated', (int)($v['params']['userid'] ?? 0), [
                ...ClientHelper::getServiceVars($v['params'] ?? []),
            ]);
        });

        add_hook('AfterModuleSuspend', 1, function(array $v): void {
            self::handle('service_suspended', (int)($v['params']['userid'] ?? 0), [
                ...ClientHelper::getServiceVars($v['params'] ?? []),
            ]);
        });

        add_hook('AfterModuleUnsuspend', 1, function(array $v): void {
            self::handle('service_unsuspended', (int)($v['params']['userid'] ?? 0), [
                ...ClientHelper::getServiceVars($v['params'] ?? []),
            ]);
        });

        add_hook('AfterModuleTerminate', 1, function(array $v): void {
            self::handle('service_terminated', (int)($v['params']['userid'] ?? 0), [
                ...ClientHelper::getServiceVars($v['params'] ?? []),
            ]);
        });

        // ── Support ──────────────────────────────────────────────────────
        add_hook('TicketOpen', 1, function(array $v): void {
            $ticket = \WHMCS\Database\Capsule::table('tbltickets')->where('id', $v['ticketid'])->first();
            if (!$ticket?->userid) return;
            self::handle('ticket_opened', (int)(string)$ticket->userid, [
                ...ClientHelper::getTicketVars((int)$v['ticketid']),
            ]);
        });

        add_hook('TicketReply', 1, function(array $v): void {
            $ticket = \WHMCS\Database\Capsule::table('tbltickets')->where('id', $v['ticketid'])->first();
            if (!$ticket?->userid) return;
            self::handle('ticket_reply', (int)(string)$ticket->userid, [
                ...ClientHelper::getTicketVars((int)$v['ticketid']),
            ]);
        });

        add_hook('TicketClose', 1, function(array $v): void {
            $ticket = \WHMCS\Database\Capsule::table('tbltickets')->where('id', $v['ticketid'])->first();
            if (!$ticket?->userid) return;
            self::handle('ticket_closed', (int)(string)$ticket->userid, [
                ...ClientHelper::getTicketVars((int)$v['ticketid']),
            ]);
        });

        // ── Domains ──────────────────────────────────────────────────────
        add_hook('DomainRegistration', 1, function(array $v): void {
            $domain = \WHMCS\Database\Capsule::table('tbldomains')->where('id', $v['domainid'] ?? 0)->first();
            if (!$domain) return;
            self::handle('domain_registered', (int)(string)$domain->userid, [
                ...ClientHelper::getDomainVars($domain->domain),
            ]);
        });

        add_hook('DomainRenewal', 1, function(array $v): void {
            $domain = \WHMCS\Database\Capsule::table('tbldomains')->where('id', $v['domainid'] ?? 0)->first();
            if (!$domain) return;
            self::handle('domain_renewed', (int)(string)$domain->userid, [
                ...ClientHelper::getDomainVars($domain->domain),
            ]);
        });

        add_hook('DomainExpiryNotice', 1, function(array $v): void {
            $clientId = (int)(string)($v['userid'] ?? 0);
            self::handle('domain_expiry', $clientId, [
                'domain'     => (string)($v['domain'] ?? ''),
                'days'       => (string)($v['daysuntil'] ?? '?'),
                'expiry_date'=> (string)($v['expirydate'] ?? ''),
                'portal_url' => ClientHelper::getPortalUrl() . '/clientarea.php?action=domains',
            ]);
        });

        // ── Clients ──────────────────────────────────────────────────────
        add_hook('ClientAdd', 1, function(array $v): void {
            self::handle('welcome', (int)(string)($v['userid'] ?? 0), [
                'email' => (string)($v['email'] ?? ''),
            ]);
        });

        // ── Webhooks (status updates from WhatsApp) ───────────────────────
        add_hook('ClientAreaFooterOutput', 1, function(): string { return ''; });

        // ── Admin Events ─────────────────────────────────────────────────
        add_hook('AdminLogin', 1, function(array $v): void {
            // Log admin login to activity log
            try {
                \WHMCS\Database\Capsule::table('mod_wabek_activity_log')->insert([
                    'admin_id'   => $v['adminid']   ?? null,
                    'action'     => 'admin_login',
                    'data'       => json_encode(['username' => $v['username'] ?? '']),
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            } catch (\Throwable $e) {}
        });

        add_hook('AdminLoginFailure', 1, function(array $v): void {
            try {
                \WHMCS\Database\Capsule::table('mod_wabek_activity_log')->insert([
                    'action'     => 'admin_login_failure',
                    'data'       => json_encode(['username' => $v['username'] ?? '']),
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            } catch (\Throwable $e) {}
        });

        // ── Client Events ─────────────────────────────────────────────────
        // OTP Login Integration - inject verification form on WHMCS login page
        add_hook('ClientAreaPageLogin', 1, function(array $v): string {
            try {
                if (!\Wabek\Config\Settings::bool('otp_enabled', false)) return '';
                // If already authenticated normally, skip
                if (!empty($_SESSION['uid'])) return '';

                $output = '';

                // Handle OTP login step
                if (!empty($_POST['wabek_otp_login']) && !empty($_POST['wabek_otp_code'])) {
                    $pendingClientId = (int)($_SESSION['wabek_otp_pending_client'] ?? 0);
                    $phone           = (string)($_SESSION['wabek_otp_pending_phone'] ?? '');
                    if ($pendingClientId && $phone) {
                        $r = \Wabek\Services\OtpService::verify($phone, $_POST['wabek_otp_code'], 'login');
                        if ($r['success']) {
                            // Authenticate the client
                            $_SESSION['uid']             = $pendingClientId;
                            $_SESSION['adminID']         = '';
                            $_SESSION['wabek_otp_login'] = true;
                            unset($_SESSION['wabek_otp_pending_client'], $_SESSION['wabek_otp_pending_phone']);
                            header('Location: clientarea.php');
                            exit;
                        }
                        $output = '<div class="alert alert-danger">' . htmlspecialchars($r['error']) . '</div>';
                    }
                }

                // After successful WHMCS login - if OTP enabled, require 2FA
                if (!empty($_SESSION['uid']) && empty($_SESSION['wabek_otp_login'])) {
                    $clientId    = (int)$_SESSION['uid'];
                    $phoneResult = \Wabek\Models\ClientSettings::getEffectivePhoneResult($clientId);
                    if ($phoneResult['valid']) {
                        $r = \Wabek\Services\OtpService::generate(
                            $phoneResult['phone'], $clientId, 'login'
                        );
                        if ($r['success']) {
                            $_SESSION['wabek_otp_pending_client'] = $clientId;
                            $_SESSION['wabek_otp_pending_phone']  = $phoneResult['phone'];
                            // Temporarily log out until OTP verified
                            $uid = $_SESSION['uid'];
                            unset($_SESSION['uid']);
                            $_SESSION['wabek_otp_pending_client'] = $uid;
                        }
                    }
                }

                return $output;
            } catch (\Throwable $e) { return ''; }
        });

        add_hook('AfterClientPasswordChange', 1, function(array $v): void {
            self::handle('password_changed', (int)(string)($v['userid'] ?? 0), [
                'portal_url' => ClientHelper::getPortalUrl(),
            ]);
        });

        add_hook('EmailVerification', 1, function(array $v): void {
            self::handle('email_verified', (int)(string)($v['userid'] ?? 0), []);
        });

        add_hook('AfterClientProfileUpdate', 1, function(array $v): void {
            try {
                \WHMCS\Database\Capsule::table('mod_wabek_activity_log')->insert([
                    'action'     => 'client_profile_update',
                    'entity_type'=> 'client',
                    'entity_id'  => $v['userid'] ?? null,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            } catch (\Throwable $e) {}
        });

        // ── Domains (extended) ───────────────────────────────────────────
        add_hook('AfterRegistrarRegistration', 1, function(array $v): void {
            $domainId = $v['params']['domainid'] ?? 0;
            $domain   = \WHMCS\Database\Capsule::table('tbldomains')->where('id', $domainId)->first();
            if (!$domain) return;
            self::handle('domain_registered', (int)(string)$domain->userid, [
                ...ClientHelper::getDomainVars($domain->domain),
            ]);
        });

        add_hook('DomainTransferCompleted', 1, function(array $v): void {
            $domain = \WHMCS\Database\Capsule::table('tbldomains')->where('id', $v['domainid'] ?? 0)->first();
            if (!$domain) return;
            self::handle('domain_transferred', (int)(string)$domain->userid, [
                'domain'      => $domain->domain,
                'portal_url'  => ClientHelper::getPortalUrl() . '/clientarea.php?action=domains',
            ]);
        });

        add_hook('AfterRegistrarTransfer', 1, function(array $v): void {
            $domain = \WHMCS\Database\Capsule::table('tbldomains')->where('id', $v['params']['domainid'] ?? 0)->first();
            if (!$domain) return;
            self::handle('domain_transferred', (int)(string)$domain->userid, [
                'domain'     => $domain->domain,
                'portal_url' => ClientHelper::getPortalUrl() . '/clientarea.php?action=domains',
            ]);
        });

        // ── Quotes ───────────────────────────────────────────────────────
        add_hook('QuoteCreated', 1, function(array $v): void {
            $quote = \WHMCS\Database\Capsule::table('tblquotes')->where('id', $v['quoteid'] ?? 0)->first();
            if (!$quote || !$quote->userid) return;
            self::handle('quote_created', (int)(string)$quote->userid, [
                'quote_id'   => (string)($v['quoteid'] ?? ''),
                'subject'    => (string)($quote->subject ?? ''),
                'total'      => number_format((float)($quote->total ?? 0), 2),
                'currency'   => 'USD',
                'portal_url' => ClientHelper::getPortalUrl() . '/viewquote.php?qid=' . ($v['quoteid'] ?? 0),
            ]);
        });

        add_hook('QuoteStatusChange', 1, function(array $v): void {
            if (($v['status'] ?? '') !== 'Accepted') return;
            $quote = \WHMCS\Database\Capsule::table('tblquotes')->where('id', $v['quoteid'] ?? 0)->first();
            if (!$quote || !$quote->userid) return;
            self::handle('quote_accepted', (int)(string)$quote->userid, [
                'quote_id'   => (string)($v['quoteid'] ?? ''),
                'subject'    => (string)($quote->subject ?? ''),
                'portal_url' => ClientHelper::getPortalUrl(),
            ]);
        });

        // ── Affiliate ────────────────────────────────────────────────────
        add_hook('AffiliateWithdrawalRequest', 1, function(array $v): void {
            $clientId = (int)(string)($v['userid'] ?? 0);
            if (!$clientId) return;
            self::handle('affiliate_withdrawal', $clientId, [
                'amount'     => number_format((float)($v['amount'] ?? 0), 2),
                'portal_url' => ClientHelper::getPortalUrl(),
            ]);
        });

        // ── Abandoned Cart ───────────────────────────────────────────────
        // Track cart abandonment via ClientAreaFooterOutput
        add_hook('ClientAreaPage', 1, function(array $v): void {
            try {
                if (!\Wabek\Config\Settings::bool('abandoned_cart_enabled', false)) return;
                $filename = $v['filename'] ?? '';
                if ($filename !== 'cart') return;
                $sessionId = session_id();
                if (!$sessionId) return;
                $clientId  = (int)($v['clientsdetails']['id'] ?? 0);
                $email     = (string)($v['clientsdetails']['email'] ?? '');
                // Cart items from session if available
                $items     = (array)($_SESSION['cart'] ?? []);
                $value     = (float)($_SESSION['cart_total'] ?? 0);
                if ($clientId || $email) {
                    \Wabek\Services\AbandonedCartService::track($clientId, $sessionId, $email, $items, $value);
                }
            } catch (\Throwable $e) {}
        });

        add_hook('ShoppingCartCheckoutCompletedOrder', 1, function(array $v): void {
            try {
                $sessionId = session_id();
                if ($sessionId) {
                    \Wabek\Services\AbandonedCartService::markRecovered($sessionId);
                }
            } catch (\Throwable $e) {}
        });
    }

    private static function handle(string $event, int|string $clientId, array $extraVars = []): void
    {
        // Accept string from WHMCS hooks - cast to int
        $clientId = (int)(string)$clientId;
        if ($clientId <= 0) return;

        try {
            // Validate phone early - log clearly if missing
            $phoneResult = \Wabek\Helpers\PhoneHelper::getClientPhoneResult($clientId);
            if (!$phoneResult['valid']) {
                logActivity(sprintf(
                    'WABEK [%s] client=%d SKIP - phone invalid: original="%s" source=%s error=%s',
                    $event, $clientId,
                    $phoneResult['original'] ?? '(empty)',
                    $phoneResult['source']   ?? 'unknown',
                    $phoneResult['error']    ?? 'unknown'
                ));
                return;
            }

            $vars = array_merge([
                'name'       => ClientHelper::getName($clientId),
                'email'      => ClientHelper::getEmail($clientId),
                'company'    => ClientHelper::getCompanyName(),
                'portal_url' => ClientHelper::getPortalUrl(),
            ], $extraVars);

            NotificationService::send($event, $clientId, $vars);

        } catch (\Throwable $e) {
            // Never let hooks crash WHMCS
            logActivity('WABEK Hook Error [' . $event . ']: ' . $e->getMessage());
        }
    }
}

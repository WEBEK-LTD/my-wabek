<?php
declare(strict_types=1);

namespace Wabek\Controllers;

use Wabek\Config\Settings;
use Wabek\Models\Message;
use Wabek\Models\QueueItem;
use Wabek\Models\Campaign;
use Wabek\Models\Template;
use Wabek\Services\WhatsAppService;
use Wabek\Services\QueueService;
use Wabek\Services\CampaignService;
use Wabek\Middleware\CsrfMiddleware;
use Wabek\Middleware\AuthMiddleware;
use Wabek\Helpers\TemplateParser;
use WHMCS\Database\Capsule;

class AdminController
{
    private array $vars;
    private string $tab;

    public function __construct(array $vars)
    {
        $this->vars = $vars;
        $this->tab  = AuthMiddleware::sanitize($_GET['tab'] ?? 'dashboard');
    }

    public function dispatch(): void
    {
        // Load shared CSS/JS
        $this->loadAssets();

        // Handle POST actions
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        // Route to tab
        switch ($this->tab) {
            case 'dashboard':   $this->tabDashboard();   break;
            case 'messages':    $this->tabMessages();    break;
            case 'inbox':       $this->tabInbox();       break;
            case 'analytics':   $this->tabAnalytics();   break;
            case 'templates':   $this->tabTemplates();   break;
            case 'campaigns':   $this->tabCampaigns();   break;
            case 'queue':       $this->tabQueue();       break;
            case 'otp':         $this->tabOtp();         break;
            case 'webhooks':    $this->tabWebhooks();    break;
            case 'settings':    $this->tabSettings();    break;
            case 'send':        $this->tabSend();        break;
            case 'diagnostics': $this->tabDiagnostics(); break;
            case 'media':        $this->tabMedia();       break;
            case 'permissions':  $this->tabPermissions();  break;
            case 'abandoned_cart': $this->tabAbandonedCart(); break;
            default:            $this->tabDashboard();   break;
        }
    }

    private function handlePost(): void
    {
        $action = $_POST['wabek_action'] ?? '';

        switch ($action) {
            case 'send_test':
                $this->handleSendTest();
                break;
            case 'save_template':
                $this->handleSaveTemplate();
                break;
            case 'delete_template':
                $this->handleDeleteTemplate();
                break;
            case 'restore_version':
                $vId = (int)($_POST['version_id'] ?? 0);
                $tId = (int)($_POST['template_id'] ?? 0);
                if ($vId && $tId) \Wabek\Models\Template::restoreVersion($vId, $tId);
                $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>'Template restored to previous version'];
                break;
            case 'create_campaign':
                $this->handleCreateCampaign();
                break;
            case 'campaign_action':
                $this->handleCampaignAction();
                break;
            case 'export_csv':
                $this->handleExportCsv();
                break;
            case 'export_templates':
                $this->handleExportTemplates();
                break;
            case 'import_templates':
                $this->handleImportTemplates();
                break;
            case 'export_settings':
                $this->handleExportSettings();
                break;
            case 'import_settings':
                $this->handleImportSettings();
                break;
            case 'requeue_item':
                $id = (int)($_POST['queue_id'] ?? 0);
                if ($id) \Wabek\Models\QueueItem::requeueDead([$id]);
                break;
            case 'test_notification':
                $this->handleTestNotification();
                break;
            case 'save_permissions':
                $roleId = (int)($_POST['role_id'] ?? 0);
                if ($roleId > 0) {
                    foreach (\Wabek\Services\PermissionService::PERMISSIONS as $key => $_) {
                        $allowed = isset($_POST['perm_' . $key]);
                        \Wabek\Services\PermissionService::setRolePermission($roleId, $key, $allowed);
                    }
                    $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>'Permissions saved'];
                }
                break;
            case 'upload_media':
                $this->handleMediaUpload();
                break;
            case 'delete_media':
                $id = (int)($_POST['media_id'] ?? 0);
                if ($id) \Wabek\Services\MediaService::delete($id);
                $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>'File deleted'];
                break;
            case 'requeue_dead_all':
                $dlq = \Wabek\Models\QueueItem::deadLetter(1, 500);
                $ids = array_column((array)$dlq['items'], 'id');
                if ($ids) \Wabek\Models\QueueItem::requeueDead($ids);
                break;
        }
    }

    private function loadAssets(): void
    {
        $rootUrl = \WHMCS\Config\Setting::getValue('SystemURL') ?? '';
        $base    = $rootUrl . '/modules/addons/wabek/assets';
        echo '<link rel="stylesheet" href="' . $base . '/css/admin.css?v=3.2.0">';
        echo '<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js" defer></script>';
        echo '<script src="' . $base . '/js/admin.js?v=3.2.0" defer></script>';
    }

    // ── Dashboard ──────────────────────────────────────────────────────────
    private function tabDashboard(): void
    {
        $todayStats = Message::stats('today');
        $monthStats = Message::stats('month');
        $queueStats = QueueItem::stats();
        $chartData  = Message::chartData(30);
        $recentMsgs = Capsule::table('mod_wabek_messages as m')
            ->leftJoin('tblclients as c', 'c.id', '=', 'm.client_id')
            ->select('m.id','m.event','m.phone','m.status','m.sent_at','m.created_at','c.firstname','c.lastname')
            ->orderBy('m.created_at', 'desc')
            ->limit(10)
            ->get();

        $wa               = new WhatsAppService();
        $connectionStatus = $wa->getConnectionStatus();
        $connected        = $connectionStatus['status'] === 'connected';
        $instances        = $connected ? $wa->getInstances() : [];
        $apiKey           = Settings::apiKey();

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/dashboard.php';
    }

    // ── Messages ───────────────────────────────────────────────────────────
    private function tabMessages(): void
    {
        $page    = max(1, (int)($_GET['p'] ?? 1));
        $filters = [
            'status'    => $_GET['status']    ?? '',
            'event'     => $_GET['event']     ?? '',
            'phone'     => $_GET['phone']     ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to'   => $_GET['date_to']   ?? '',
            'search'    => $_GET['search']    ?? '',
        ];

        $result = Message::paginate($page, 50, $filters);
        $events = Capsule::table('mod_wabek_messages')
            ->distinct()->orderBy('event')->pluck('event')->toArray();

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/messages.php';
    }

    // ── Templates ──────────────────────────────────────────────────────────
    private function tabTemplates(): void
    {
        $category  = $_GET['category'] ?? '';
        $templates = Template::all($category);
        $categories = Template::categories();
        $editing   = null;

        if (!empty($_GET['edit'])) {
            $editing = Capsule::table('mod_wabek_templates')->where('id', (int)$_GET['edit'])->first();
        }

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/templates.php';
    }

    // ── Campaigns ──────────────────────────────────────────────────────────
    private function tabCampaigns(): void
    {
        $page      = max(1, (int)($_GET['p'] ?? 1));
        $result    = Campaign::all($page, 20);
        $viewing   = null;

        if (!empty($_GET['view'])) {
            $viewing = Campaign::find((int)$_GET['view']);
        }

        $templates = Template::all();
        $csrf      = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/campaigns.php';
    }

    // ── Queue ──────────────────────────────────────────────────────────────
    private function tabQueue(): void
    {
        $page    = max(1, (int)($_GET['p'] ?? 1));
        $status  = $_GET['status'] ?? '';
        $q       = Capsule::table('mod_wabek_queue');
        if ($status) $q->where('status', $status);
        $total   = $q->count();
        $items   = $q->orderBy('created_at','desc')->offset(($page-1)*50)->limit(50)->get();
        $stats   = QueueItem::stats();

        include __DIR__ . '/../../templates/admin/queue.php';
    }

    // ── OTP ────────────────────────────────────────────────────────────────
    private function tabOtp(): void
    {
        $page  = max(1, (int)($_GET['p'] ?? 1));
        $total = Capsule::table('mod_wabek_otp')->count();
        $items = Capsule::table('mod_wabek_otp as o')
            ->leftJoin('tblclients as c', 'c.id', '=', 'o.client_id')
            ->select('o.*','c.firstname','c.lastname','c.email')
            ->orderBy('o.created_at','desc')
            ->offset(($page-1)*50)->limit(50)->get();

        include __DIR__ . '/../../templates/admin/otp.php';
    }

    // ── Settings ───────────────────────────────────────────────────────────
    private function tabSettings(): void
    {
        $saved      = false;
        $allEvents  = [
            'welcome','invoice_created','invoice_paid','invoice_overdue','payment_reminder',
            'service_activated','service_suspended','service_unsuspended','service_terminated',
            'ticket_opened','ticket_reply','ticket_closed',
            'domain_registered','domain_expiry','domain_renewed',
            'order_placed',
        ];

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_wabek_settings'])) {
            // Core keys
            $coreKeys = [
                'api_key','instance_id','api_url','default_country_code',
                'phone_field','phone_custom_field','wabek_phone_custom_field',
                'queue_enabled','queue_batch_size','queue_delay_ms',
                'otp_enabled','otp_expiry_minutes','otp_max_attempts','otp_rate_limit','otp_template_name',
                'log_retention_days','admin_notifications','webhook_secret',
                'white_label_company','white_label_logo','white_label_footer',
                'white_label_color','white_label_color_hex',
            ];

            foreach ($coreKeys as $k) {
                Settings::set($k, trim($_POST[$k] ?? ''));
            }

            // Checkboxes (yesno) - must explicitly set 'off' if not present
            $checkboxes = ['queue_enabled','otp_enabled','admin_notifications','white_label_enabled'];
            foreach ($checkboxes as $k) {
                Settings::set($k, isset($_POST[$k]) ? 'on' : 'off');
            }

            // Event toggles
            foreach ($allEvents as $event) {
                $enabledKey  = 'event_' . $event . '_enabled';
                $templateKey = 'event_' . $event . '_template';
                Settings::set($enabledKey,  isset($_POST[$enabledKey])  ? 'on' : 'off');
                Settings::set($templateKey, trim($_POST[$templateKey] ?? $event));
            }

            Settings::reload();
            $saved = true;
        }

        $settings  = Settings::all();
        $templates = Template::all();
        $cronPath  = dirname(__DIR__, 2) . '/cron/queue_processor.php';
        $events    = [
            'Billing'   => ['invoice_created','invoice_paid','invoice_overdue','payment_reminder','quote_created','quote_accepted'],
            'Services'  => ['service_activated','service_suspended','service_unsuspended','service_terminated'],
            'Support'   => ['ticket_opened','ticket_reply','ticket_closed'],
            'Domains'   => ['domain_registered','domain_expiry','domain_renewed','domain_transferred'],
            'Clients'   => ['welcome','order_placed','password_changed'],
            'Marketing' => ['abandoned_cart_1','abandoned_cart_2','abandoned_cart_3','affiliate_withdrawal'],
        ];

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/settings.php';
    }

    // ── Send Message ───────────────────────────────────────────────────────
    private function tabSend(): void
    {
        $result       = null;
        $clientPhones = [];

        // ── Handle POST send ──────────────────────────────────────────────
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['wb_send'])) {

            $rawPhone     = trim($_POST['phone']          ?? '');
            $message      = trim($_POST['message']        ?? '');
            $clientId     = (int)($_POST['selected_client_id'] ?? 0);
            $mediaUrl     = trim($_POST['media_url']       ?? '');
            $mediaType    = trim($_POST['media_type']      ?? '');
            $mediaCaption = trim($_POST['media_caption']   ?? '');
            $instanceId   = trim($_POST['instance_id']    ?? '');

            if (!$message) {
                $result = ['success' => false, 'error' => 'Message is required'];
            } else {
                // Resolve phone number
                $digits = '';

                if ($clientId > 0) {
                    // Client selected -- always use PhoneHelper (handles country code correctly)
                    $pr     = \Wabek\Helpers\PhoneHelper::getClientPhoneResult($clientId);
                    $digits = $pr['valid'] ? ($pr['phone'] ?? '') : '';
                }

                // If no client or PhoneHelper failed, use manually typed phone
                if (!$digits && $rawPhone) {
                    $digits = preg_replace('/[^\d]/', '', $rawPhone);
                    // Add default country code if short
                    if ($digits && strlen($digits) <= 10) {
                        $defCC = preg_replace('/[^\d]/', '', Settings::get('default_country_code', ''));
                        if ($defCC) $digits = $defCC . $digits;
                    }
                }

                if (!$digits && $clientId > 0) {
                    // Last attempt: try PhoneHelper directly even without a phone in POST
                    $pr2    = \Wabek\Helpers\PhoneHelper::getClientPhoneResult($clientId);
                    $digits = $pr2['valid'] ? ($pr2['phone'] ?? '') : '';
                }

                if (!$digits) {
                    $result = ['success' => false, 'error' => 'No phone number found. Check the client has a phone number in WHMCS, or enter it manually.'];
                } elseif (strlen($digits) < 7 || strlen($digits) > 15) {
                    $result = ['success' => false, 'error' => 'Invalid phone: ' . $rawPhone . ' (digits: ' . $digits . ')'];
                } else {
                    $wa     = new WhatsAppService();
                    $opts   = $instanceId ? ['instance_id' => $instanceId] : [];

                    if ($mediaUrl && $mediaType) {
                        $result = $wa->sendMedia($digits, $mediaUrl, $mediaType, $mediaCaption, $opts);
                        $result['_sent_phone'] = $digits;
                    } else {
                        $result = $wa->sendText($digits, $message, $opts);
                    $result['_sent_phone'] = $digits;
                    }

                    // Log
                    \Wabek\Models\Message::create([
                        'client_id'  => $clientId ?: null,
                        'phone'      => $digits,
                        'event'      => 'manual_send',
                        'content'    => $message,
                        'status'     => $result['success']
                            ? \Wabek\Models\Message::STATUS_SENT
                            : \Wabek\Models\Message::STATUS_FAILED,
                        'message_id' => $result['messageId'] ?? null,
                        'error_msg'  => $result['error']     ?? null,
                        'sent_at'    => $result['success'] ? date('Y-m-d H:i:s') : null,
                        'provider_response' => json_encode([
                            'raw_input' => $rawPhone,
                            'digits'    => $digits,
                            'defCC'     => $defCC,
                            'client_id' => $clientId,
                        ]),
                    ]);
                    // Pass sent phone to template for display
                    $_POST['_sent_phone'] = $digits;
                }
            }
        }

        // ── Load clients ─────────────────────────────────────────────────
        $rawClients = Capsule::table('tblclients')
            ->where('status', 'Active')
            ->select('id', 'firstname', 'lastname', 'email', 'phonenumber')
            ->orderBy('firstname')
            ->limit(500)
            ->get();

        // Store raw phonenumber for dropdown display only
        // Actual normalization happens in the send handler via PhoneHelper
        foreach ($rawClients as $cl) {
            $cid = (int)$cl->id;
            $clientPhones[$cid] = trim((string)($cl->phonenumber ?? ''));
        }

        $clients   = $rawClients;
        $instances = [];
        try { $instances = (new WhatsAppService())->getInstances(); } catch (\Throwable $e) {}

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/send.php';
    }

    // ── POST Handlers ──────────────────────────────────────────────────────
    private function handleSendTest(): void
    {
        // Handled inline in tabSend
    }

    private function handleSaveTemplate(): void
    {
        $data = [
            'id'       => (int)($_POST['template_id'] ?? 0),
            'slug'     => AuthMiddleware::sanitize($_POST['slug'] ?? ''),
            'name'     => AuthMiddleware::sanitize($_POST['name'] ?? ''),
            'category' => AuthMiddleware::sanitize($_POST['category'] ?? 'general'),
            'content'  => $_POST['content'] ?? '',
            'is_active'=> isset($_POST['is_active']) ? 1 : 0,
        ];

        if (empty($data['slug']) || empty($data['content'])) {
            $_SESSION['wabek_flash'] = ['type' => 'danger', 'msg' => 'Slug and content are required'];
            return;
        }

        $data['admin_id'] = $this->vars['adminid'] ?? 0;
        Template::save($data, (int)($this->vars['adminid'] ?? 0));
        $_SESSION['wabek_flash'] = ['type' => 'success', 'msg' => 'Template saved successfully'];
    }

    private function handleDeleteTemplate(): void
    {
        $id = (int)($_POST['template_id'] ?? 0);
        if ($id > 0) Template::delete($id);
        $_SESSION['wabek_flash'] = ['type' => 'success', 'msg' => 'Template deleted'];
    }

    private function handleCreateCampaign(): void
    {
        $name    = AuthMiddleware::sanitize($_POST['campaign_name'] ?? '');
        $message = $_POST['campaign_message'] ?? '';
        if (!$name || !$message) {
            $_SESSION['wabek_flash'] = ['type' => 'danger', 'msg' => 'Name and message are required'];
            return;
        }

        // Build segment from form fields
        $segment = array_filter([
            'status'   => AuthMiddleware::sanitize($_POST['seg_status']   ?? ''),
            'country'  => AuthMiddleware::sanitize($_POST['seg_country']  ?? ''),
            'group_id' => (int)($_POST['seg_group']    ?? 0) ?: null,
            'currency' => (int)($_POST['seg_currency'] ?? 0) ?: null,
        ]);

        $mediaType = $_POST['campaign_media_type'] ?? '';
        $mediaUrl  = trim($_POST['campaign_media_url'] ?? '');

        $id = CampaignService::create($name, $message, [
            'template_key' => $_POST['template_key'] ?? '',
            'delay_ms'     => (int)($_POST['delay_ms'] ?? 500),
            'scheduled_at' => !empty($_POST['scheduled_at']) ? $_POST['scheduled_at'] : null,
            'admin_id'     => $this->vars['adminid'] ?? 0,
            'segment'      => $segment,
            'media_type'   => $mediaType ?: null,
            'media_url'    => $mediaUrl  ?: null,
        ]);

        // Build recipients - CSV takes priority over segment
        if (!empty($_FILES['recipients_csv']['tmp_name'])) {
            $count = self::importCsvRecipients($id, $_FILES['recipients_csv']['tmp_name']);
            \WHMCS\Database\Capsule::table('mod_wabek_campaigns')
                ->where('id', $id)->update(['total_recipients' => $count]);
            $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>"Campaign created with {$count} CSV recipients"];
        } else {
            $count = CampaignService::buildRecipients($id, $segment);
            $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>"Campaign created with {$count} recipients"];
        }
    }

    private function handleCampaignAction(): void
    {
        $id     = (int)($_POST['campaign_id'] ?? 0);
        $action = $_POST['campaign_action'] ?? '';
        if (!$id) return;

        $statusMap = [
            'start'  => Campaign::STATUS_RUNNING,
            'pause'  => Campaign::STATUS_PAUSED,
            'resume' => Campaign::STATUS_RUNNING,
            'cancel' => Campaign::STATUS_CANCELLED,
        ];

        if (isset($statusMap[$action])) {
            Campaign::updateStatus($id, $statusMap[$action]);
        }
    }

    private function handleExportCsv(): void
    {
        $filters = [
            'status'    => $_POST['status']    ?? '',
            'date_from' => $_POST['date_from'] ?? '',
            'date_to'   => $_POST['date_to']   ?? '',
        ];

        $csv = Message::exportCsv($filters);
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="wabek_messages_' . date('Y-m-d') . '.csv"');
        echo $csv;
        exit;
    }

    // ── Inbox ─────────────────────────────────────────────────────────────────
    private function tabInbox(): void
    {
        $page   = max(1, (int)($_GET['p'] ?? 1));
        $status = $_GET['status'] ?? 'open';
        $search = trim($_GET['search'] ?? '');

        $q = Capsule::table('mod_wabek_conversations as conv')
            ->leftJoin('tblclients as c', 'c.id', '=', 'conv.client_id')
            ->leftJoin('tbladmins as a', 'a.id', '=', 'conv.assigned_to')
            ->select('conv.*', 'c.firstname', 'c.lastname', 'c.email', 'a.firstname as admin_name')
            ->orderBy('conv.last_message_at', 'desc');

        if ($status)  $q->where('conv.status', $status);
        if ($search)  $q->where(function($q2) use ($search) {
            $q2->where('conv.phone', 'like', "%$search%")
               ->orWhere('c.firstname', 'like', "%$search%")
               ->orWhere('c.email', 'like', "%$search%");
        });

        $total         = $q->count();
        $conversations = $q->offset(($page-1)*30)->limit(30)->get();
        $viewing       = null;

        if (!empty($_GET['conv'])) {
            $convId  = (int)$_GET['conv'];
            $viewing = Capsule::table('mod_wabek_conversations')->where('id', $convId)->first();
            if ($viewing) {
                Capsule::table('mod_wabek_incoming_messages')
                    ->where('conversation_id', $convId)
                    ->where('is_read', false)
                    ->update(['is_read' => true]);
                Capsule::table('mod_wabek_conversations')
                    ->where('id', $convId)->update(['unread_count' => 0]);
                $viewing->messages = Capsule::table('mod_wabek_incoming_messages')
                    ->where('conversation_id', $convId)
                    ->orderBy('received_at', 'asc')->limit(100)->get();
            }
        }

        // Conversation actions
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['wabek_action'])) {
            $convAction = $_POST['wabek_action'] ?? '';
            $convId     = (int)($_POST['conv_id'] ?? 0);

            if ($convAction === 'update_conversation' && $convId) {
                Capsule::table('mod_wabek_conversations')->where('id', $convId)
                    ->update(['status' => $_POST['conv_status'] ?? 'open', 'updated_at' => date('Y-m-d H:i:s')]);
            }

            if ($convAction === 'assign_conversation' && $convId) {
                $assignTo = (int)($_POST['assign_to'] ?? 0);
                Capsule::table('mod_wabek_conversations')->where('id', $convId)
                    ->update(['assigned_to' => $assignTo ?: null, 'updated_at' => date('Y-m-d H:i:s')]);
            }

            if ($convAction === 'add_note' && $convId) {
                $note = trim($_POST['note_text'] ?? '');
                if ($note) {
                    Capsule::table('mod_wabek_incoming_messages')->insert([
                        'conversation_id' => $convId,
                        'direction'       => 'outbound',
                        'message_type'    => 'text',
                        'content'         => '[NOTE] ' . $note,
                        'internal_note'   => $note,
                        'is_read'         => true,
                        'received_at'     => date('Y-m-d H:i:s'),
                        'created_at'      => date('Y-m-d H:i:s'),
                        'updated_at'      => date('Y-m-d H:i:s'),
                    ]);
                }
            }
        }

        // Handle reply
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['reply_message'])) {
            $convId  = (int)($_POST['conv_id'] ?? 0);
            $msg     = trim($_POST['reply_message'] ?? '');
            $conv    = $convId ? Capsule::table('mod_wabek_conversations')->where('id', $convId)->first() : null;
            if ($conv && $msg) {
                $wa = new WhatsAppService();
                $wa->sendText($conv->phone, $msg);
                Capsule::table('mod_wabek_conversations')->where('id', $convId)
                    ->update(['last_message' => $msg, 'last_message_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }
            header('Location: ' . $_SERVER['REQUEST_URI']); exit;
        }

        $unreadCount = Capsule::table('mod_wabek_conversations')
            ->where('status','open')->sum('unread_count');

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/inbox.php';
    }

    // ── Analytics ─────────────────────────────────────────────────────────────
    private function tabAnalytics(): void
    {
        $period     = max(7, min(365, (int)($_GET['period'] ?? 30)));
        $todayStats = Message::stats('today');
        $monthStats = Message::stats('month');

        $allRow = Capsule::table('mod_wabek_messages')
            ->select(
                Capsule::raw('COUNT(*) as total'),
                Capsule::raw('SUM(status="delivered") as delivered'),
                Capsule::raw('SUM(status="read") as `read`'),
                Capsule::raw('SUM(status="failed") as failed')
            )->first();

        $allTimeStats = [
            'total'     => (int)($allRow->total     ?? 0),
            'delivered' => (int)($allRow->delivered ?? 0),
            'read'      => (int)($allRow->read      ?? 0),
            'failed'    => (int)($allRow->failed    ?? 0),
        ];

        $topEvents = Capsule::table('mod_wabek_messages')
            ->select('event', Capsule::raw('COUNT(*) as total'),
                     Capsule::raw('SUM(status="delivered") as delivered'),
                     Capsule::raw('SUM(status="failed") as failed'))
            ->where('created_at', '>=', date('Y-m-d', strtotime("-{$period} days")))
            ->groupBy('event')->orderBy('total', 'desc')->limit(10)->get()->toArray();

        $dailyChart = Message::chartData($period);

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/analytics.php';
    }

    // ── Webhooks ───────────────────────────────────────────────────────────────
    private function tabWebhooks(): void
    {
        $page   = max(1, (int)($_GET['p'] ?? 1));
        $filter = $_GET['type'] ?? '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        $q = Capsule::schema()->hasTable('mod_wabek_webhooks')
            ? Capsule::table('mod_wabek_webhooks')->orderBy('created_at','desc')
            : null;

        if ($q && $filter) $q->where('event_type', $filter);

        $total    = $q ? $q->count() : 0;
        $webhooks = $q ? $q->offset(($page-1)*50)->limit(50)->get() : collect();
        $types    = Capsule::schema()->hasTable('mod_wabek_webhooks')
            ? Capsule::table('mod_wabek_webhooks')->distinct()->orderBy('event_type')->pluck('event_type')->toArray()
            : [];

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/webhooks.php';
    }

    // ── Diagnostics ───────────────────────────────────────────────────────────
    private function tabDiagnostics(): void
    {
        if (!empty($_GET['debug_client_id'])) {
            $clientId = (int)$_GET['debug_client_id'];
            $result   = \Wabek\Helpers\PhoneHelper::getClientPhoneResult($clientId);
            header('Content-Type: application/json');
            echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        }

        $wa               = new WhatsAppService();
        $connectionStatus = $wa->getConnectionStatus();
        $diagnostics      = $connectionStatus['diagnostics'] ?? [];

        $debugClients = Capsule::table('tblclients')
            ->where('status', 'Active')
            ->select('id', 'firstname', 'lastname', 'email', 'phonenumber')
            ->orderBy('id', 'desc')->limit(20)->get();

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/diagnostics.php';
    }


    // ── Media Library ──────────────────────────────────────────────────────────
    private function tabMedia(): void
    {
        // JSON API for media picker
        if (isset($_GET['picker'])) {
            $list = \Wabek\Services\MediaService::list('', 1, 100);
            header('Content-Type: application/json');
            echo json_encode(['items' => array_values((array)$list['items'])]);
            exit;
        }

        $uploadResult = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        $filterType = $_GET['type'] ?? '';
        $page       = max(1, (int)($_GET['p'] ?? 1));
        $result     = \Wabek\Services\MediaService::list($filterType, $page, 24);

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/media.php';
    }

    // ── Export Templates ───────────────────────────────────────────────────────
    private function handleExportTemplates(): void
    {
        $templates = Capsule::table('mod_wabek_templates')->get()->toArray();
        $export    = [
            'version'    => '3.0',
            'exported_at'=> date('Y-m-d H:i:s'),
            'templates'  => $templates,
        ];
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="wabek_templates_' . date('Y-m-d') . '.json"');
        echo json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ── Import Templates ───────────────────────────────────────────────────────
    private function handleImportTemplates(): void
    {
        if (empty($_FILES['import_file'])) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'No file uploaded'];
            return;
        }
        $content = file_get_contents($_FILES['import_file']['tmp_name']);
        $data    = json_decode($content, true);
        if (!$data || empty($data['templates'])) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'Invalid template export file'];
            return;
        }
        $imported = 0;
        $skipped  = 0;
        foreach ($data['templates'] as $tpl) {
            $slug = preg_replace('/[^a-z0-9_]/', '', strtolower($tpl['slug'] ?? ''));
            if (!$slug || !($tpl['content'] ?? '')) { $skipped++; continue; }

            $exists = Capsule::table('mod_wabek_templates')->where('slug', $slug)->exists();
            if ($exists) { $skipped++; continue; }

            Capsule::table('mod_wabek_templates')->insert([
                'slug'       => $slug,
                'name'       => $tpl['name'] ?? $slug,
                'category'   => $tpl['category'] ?? 'general',
                'content'    => $tpl['content'],
                'variables'  => $tpl['variables'] ?? null,
                'is_active'  => true,
                'is_system'  => false,
                'version'    => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            $imported++;
        }
        $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>"✓ Imported {$imported} templates, skipped {$skipped}"];
    }

    // ── Export Settings ────────────────────────────────────────────────────────
    private function handleExportSettings(): void
    {
        $settings = Settings::all();
        // Mask sensitive fields
        if (isset($settings['api_key'])) {
            $settings['api_key'] = substr($settings['api_key'], 0, 8) . '...(masked)';
        }
        $export = [
            'version'    => '3.0',
            'exported_at'=> date('Y-m-d H:i:s'),
            'settings'   => $settings,
        ];
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="wabek_settings_' . date('Y-m-d') . '.json"');
        echo json_encode($export, JSON_PRETTY_PRINT);
        exit;
    }

    // ── Import Settings ────────────────────────────────────────────────────────
    private function handleImportSettings(): void
    {
        if (empty($_FILES['import_settings_file'])) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'No file uploaded'];
            return;
        }
        $content = file_get_contents($_FILES['import_settings_file']['tmp_name']);
        $data    = json_decode($content, true);
        if (!$data || empty($data['settings'])) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'Invalid settings file'];
            return;
        }
        // Never import api_key from backup (security)
        $skip = ['api_key'];
        $imported = 0;
        foreach ($data['settings'] as $key => $val) {
            if (in_array($key, $skip, true)) continue;
            Settings::set($key, $val);
            $imported++;
        }
        Settings::reload();
        $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>"✓ Imported {$imported} settings (API key not imported for security)"];
    }

    private function handleMediaUpload(): void
    {
        if (empty($_FILES['media_file'])) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'No file uploaded'];
            return;
        }
        $adminId = (int)($this->vars['adminid'] ?? 0);
        $result  = \Wabek\Services\MediaService::upload($_FILES['media_file'], $adminId);
        if ($result['success']) {
            $_SESSION['wabek_flash'] = ['type'=>'success','msg'=>'✓ Uploaded: ' . basename($result['url'])];
        } else {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>$result['error']];
        }
    }


    // ── Permissions ────────────────────────────────────────────────────────────
    private function tabPermissions(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        $roles        = \Wabek\Services\PermissionService::getAllRoles();
        $selectedRole = (int)($_GET['role_id'] ?? 0);
        $rolePerms    = $selectedRole > 0
            ? \Wabek\Services\PermissionService::getRolePermissions($selectedRole)
            : [];
        $allPerms     = \Wabek\Services\PermissionService::PERMISSIONS;

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/permissions.php';
    }


    // ── Abandoned Cart ─────────────────────────────────────────────────────────
    private function tabAbandonedCart(): void
    {
        $page    = max(1, (int)($_GET['p'] ?? 1));
        $status  = $_GET['status'] ?? '';

        $q = Capsule::table('mod_wabek_abandoned_carts as ac')
            ->leftJoin('tblclients as c', 'c.id', '=', 'ac.client_id')
            ->select('ac.*', 'c.firstname', 'c.lastname', 'c.email')
            ->orderBy('ac.created_at', 'desc');

        if ($status) $q->where('ac.status', $status);

        $total  = $q->count();
        $carts  = $q->offset(($page-1)*50)->limit(50)->get();
        $analytics = \Wabek\Services\AbandonedCartService::analytics();

        $csrf = CsrfMiddleware::getToken();
        include __DIR__ . '/../../templates/admin/abandoned_cart.php';
    }


    // ── Test Notification ──────────────────────────────────────────────────────
    private function handleTestNotification(): void
    {
        $event    = preg_replace('/[^a-z0-9_]/', '', $_POST['test_event'] ?? '');
        $clientId = (int)($_POST['test_client_id'] ?? 0);

        if (!$event || !$clientId) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'Select an event and a client'];
            return;
        }

        // Get template
        $tplSlug = Settings::get('event_' . $event . '_template', $event);
        $tpl     = Capsule::table('mod_wabek_templates')->where('slug', $tplSlug)->first();
        if (!$tpl) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'No template found for event: ' . $event];
            return;
        }

        // Build vars
        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            $_SESSION['wabek_flash'] = ['type'=>'danger','msg'=>'Client not found'];
            return;
        }

        $systemUrl = \WHMCS\Config\Setting::getValue('SystemURL') ?? '';
        $vars = [
            'name'        => trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? '')),
            'email'       => $client->email ?? '',
            'company'     => \WHMCS\Config\Setting::getValue('CompanyName') ?? '',
            'portal_url'  => $systemUrl,
            'invoice_id'  => 'TEST-001',
            'amount'      => '99.00',
            'currency'    => 'USD',
            'due_date'    => date('d M Y', strtotime('+7 days')),
            'domain'      => 'example.com',
            'service'     => 'Web Hosting',
            'ticket_id'   => 'TKT-0001',
            'subject'     => 'Test Ticket',
            'otp'         => '123456',
            'expiry_minutes' => '10',
            'days'        => '7',
            'quote_id'    => 'QT-001',
            'order_id'    => 'ORD-001',
            'total'       => '99.00',
            'reset_link'  => $systemUrl . '/password/reset',
            'cart_items'  => '• Web Hosting ($99/yr)',
            'checkout_url'=> $systemUrl . '/cart.php',
            'cart_value'  => '99.00',
            'amount'      => '50.00',
            'message'     => 'This is a test broadcast message.',
        ];

        $message = \Wabek\Helpers\TemplateParser::parse($tpl->content, $vars);

        // Send
        $result = \Wabek\Services\NotificationService::send($event, $clientId, $vars);

        if ($result) {
            $_SESSION['wabek_flash'] = [
                'type' => 'success',
                'msg'  => "✓ Test notification sent for event '{$event}' to client #{$clientId} - " .
                          htmlspecialchars(trim(($client->firstname??'').' '.($client->lastname??'')))
            ];
        } else {
            // Try direct send
            $phoneResult = \Wabek\Models\ClientSettings::getEffectivePhoneResult($clientId);
            if (!$phoneResult['valid']) {
                $_SESSION['wabek_flash'] = [
                    'type'=>'danger',
                    'msg' =>"No valid phone for client #{$clientId}. Phone source: " . ($phoneResult['source']??'none')
                ];
            } else {
                $wa  = new WhatsAppService();
                $res = $wa->sendText($phoneResult['phone'], $message);
                $_SESSION['wabek_flash'] = [
                    'type' => $res['success'] ? 'success' : 'danger',
                    'msg'  => $res['success']
                        ? "✓ Test sent to " . htmlspecialchars($phoneResult['e164'])
                        : "✕ Failed: " . htmlspecialchars($res['error'] ?? 'Unknown'),
                ];
            }
        }
    }


    // ── CSV Recipients Import ──────────────────────────────────────────────────
    private static function importCsvRecipients(int $campaignId, string $tmpFile): int
    {
        $lines = file($tmpFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $count = 0;
        foreach ($lines as $line) {
            $parts = str_getcsv($line);
            $raw   = trim($parts[0] ?? '');
            $name  = trim($parts[1] ?? '');
            if (!$raw) continue;

            $ph = \Wabek\Helpers\PhoneHelper::normalize($raw);
            if (!$ph['valid']) continue;

            \WHMCS\Database\Capsule::table('mod_wabek_campaign_recipients')->insert([
                'campaign_id' => $campaignId,
                'client_id'   => null,
                'phone'       => $ph['phone'],
                'name'        => $name ?: $ph['e164'],
                'status'      => 'pending',
            ]);
            $count++;
        }
        return $count;
    }

}

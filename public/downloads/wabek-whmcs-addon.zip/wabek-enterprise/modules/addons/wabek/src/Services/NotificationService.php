<?php
declare(strict_types=1);

namespace Wabek\Services;

use Wabek\Config\Settings;
use Wabek\Helpers\PhoneHelper;
use Wabek\Models\ClientSettings;
use Wabek\Helpers\TemplateParser;
use Wabek\Helpers\ClientHelper;
use WHMCS\Database\Capsule;

class NotificationService
{
    public static function send(string $event, int|string $clientId, array $vars = []): bool
    {
        $clientId = (int)(string)$clientId; // Capsule returns strings - cast to int
        if ($clientId <= 0 || !Settings::apiKey()) return false;

        // Check if event is enabled
        $enabledKey = 'event_' . $event . '_enabled';
        if (!Settings::bool($enabledKey, true)) return false;



        // Check opt-out first
        if (ClientSettings::isOptedOut($clientId)) return false;

        // Get phone - uses ClientSettings as first priority
        $phoneResult = ClientSettings::getEffectivePhoneResult($clientId);
        if (!$phoneResult['valid']) {
            // Log the failure
            try {
                \WHMCS\Database\Capsule::table('mod_wabek_messages')->insert([
                    'client_id'    => $clientId,
                    'phone'        => $phoneResult['original'] ?? '',
                    'event'        => $event,
                    'status'       => 'failed',
                    'error_msg'    => 'Phone validation failed: ' . $phoneResult['error'],
                    'error_code'   => $phoneResult['error'],
                    'provider_response' => json_encode([
                        'phone_original'  => $phoneResult['original'] ?? '',
                        'phone_source'    => $phoneResult['source'] ?? '',
                        'country_code'    => $phoneResult['country_code'] ?? '',
                        'validation_error'=> $phoneResult['error'],
                    ]),
                    'created_at'   => date('Y-m-d H:i:s'),
                    'updated_at'   => date('Y-m-d H:i:s'),
                ]);
            } catch (\Throwable $e) {}
            return false;
        }
        $phone = $phoneResult['phone'];

        // Get template
        $tplSlug    = Settings::get('event_' . $event . '_template', $event);
        $tpl        = Capsule::table('mod_wabek_templates')->where('slug', $tplSlug)->first();
        $tplContent = $tpl->content ?? null;

        if (!$tplContent) {
            // Use custom message from config if no template
            $tplContent = Settings::get('msg_' . $event, '');
        }
        if (!$tplContent) return false;

        // Build full vars
        $client   = ClientHelper::get($clientId);
        // Generate unsubscribe token
        $token   = \Wabek\Models\ClientSettings::getUnsubscribeToken($clientId);
        $sysUrl  = rtrim(\WHMCS\Config\Setting::getValue('SystemURL') ?? '', '/');
        $unsubUrl= $sysUrl . '/includes/hooks/wabek_notifications.php?wabek_unsub=' . $token;

        $allVars  = array_merge([
            'name'        => $client ? trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? '')) : 'Customer',
            'email'       => $client->email ?? '',
            'company'     => \WHMCS\Config\Setting::getValue('CompanyName') ?? '',
            'portal_url'  => \WHMCS\Config\Setting::getValue('SystemURL') ?? '',
        ], $vars);

        $message = TemplateParser::parse($tplContent, $allVars);

        $result = QueueService::pushOrSend($event, $clientId, $phone, $message, $allVars, $tplSlug ?? '');

        // Track consecutive failures for admin alerts
        if (!$result && Settings::bool('admin_notifications', true)) {
            self::trackFailure($event, $clientId, $phone);
        }

        return $result;
    }

    private static function trackFailure(string $event, int $clientId, string $phone): void
    {
        try {
            $key     = 'wabek_fail_count_' . date('Y-m-d-H');
            $current = (int) Capsule::table('mod_wabek_activity_log')
                ->where('action', 'failure_count')
                ->where('data', $key)
                ->count();

            Capsule::table('mod_wabek_activity_log')->insert([
                'action'     => 'failure_count',
                'data'       => $key,
                'entity_type'=> 'client',
                'entity_id'  => $clientId,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            // Alert admin every 10 consecutive failures per hour
            if (($current + 1) % 10 === 0) {
                self::alertAdmin($current + 1, $event, $clientId, $phone);
            }
        } catch (\Throwable $e) {}
    }

    private static function alertAdmin(int $count, string $event, int $clientId, string $phone): void
    {
        try {
            $adminEmail = \WHMCS\Config\Setting::getValue('Email');
            if (!$adminEmail) return;

            $systemUrl  = \WHMCS\Config\Setting::getValue('SystemURL') ?? '';
            $company    = \WHMCS\Config\Setting::getValue('CompanyName') ?? 'WHMCS';
            $logsUrl    = $systemUrl . '/admin/addonmodules.php?module=wabek&tab=messages';

            $subject = "[WABEK] {$count} WhatsApp send failures in the last hour";
            $body    = "Hello,

" .
                "WABEK has detected {$count} WhatsApp message failures in the last hour.

" .
                "Last failed event: {$event}
" .
                "Last failed client ID: #{$clientId}
" .
                "Last failed phone: {$phone}

" .
                "View message logs: {$logsUrl}

" .
                "To disable these alerts, go to WABEK -> Settings -> Admin Failure Alerts.

" .
                "– {$company} WABEK Addon";

            // Use WHMCS sendmail
            if (function_exists('sendMessage')) {
                sendMessage('General Email', $clientId, ['subject' => $subject, 'message' => $body]);
            } else {
                mail($adminEmail, $subject, $body, "From: noreply@{$_SERVER['HTTP_HOST']}
Content-Type: text/plain");
            }
        } catch (\Throwable $e) {}
    }
}

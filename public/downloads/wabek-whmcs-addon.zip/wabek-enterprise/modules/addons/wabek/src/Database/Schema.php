<?php
declare(strict_types=1);

namespace Wabek\Database;

use WHMCS\Database\Capsule;
use Illuminate\Database\Schema\Blueprint;

class Schema
{
    public static function createAll(): void
    {
        self::createQueue();
        self::createMessages();
        self::createTemplates();
        self::createTemplateVersions();
        self::createCampaigns();
        self::createCampaignRecipients();
        self::createCampaignEvents();
        self::createOtp();
        self::createWebhooks();
        self::createAbandonedCarts();
        self::createStatistics();
        self::createActivityLog();
        self::createAuditLog();
        self::createOptOut();
        self::createConversations();
        self::createIncomingMessages();
        self::createMedia();
        self::createPermissionMap();
        self::createClientSettings();
        self::createMigrations();
    }

    public static function createQueue(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_queue')) return;
        Capsule::schema()->create('mod_wabek_queue', function (Blueprint $t) {
            $t->increments('id');
            $t->string('event', 100)->index();
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('phone', 30)->nullable();
            $t->string('template_key', 100)->nullable();
            $t->text('message')->nullable();
            $t->json('data')->nullable();
            $t->tinyInteger('priority')->default(5);
            $t->tinyInteger('attempts')->default(0);
            $t->tinyInteger('max_attempts')->default(3);
            $t->enum('status', ['pending','processing','sent','failed','cancelled'])->default('pending')->index();
            $t->dateTime('scheduled_at')->nullable()->index();
            $t->dateTime('processed_at')->nullable();
            $t->text('error')->nullable();
            $t->timestamps();
            $t->index(['status', 'priority', 'scheduled_at'], 'idx_queue_process');
        });
    }

    public static function createMessages(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_messages')) return;
        Capsule::schema()->create('mod_wabek_messages', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('queue_id')->nullable()->index();
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('phone', 30)->nullable()->index();
            $t->string('template_key', 100)->nullable();
            $t->string('event', 100)->nullable()->index();
            $t->text('content')->nullable();
            $t->string('provider', 30)->nullable();
            $t->string('instance_id', 100)->nullable();
            $t->string('message_id', 250)->nullable()->index();
            $t->enum('status', ['queued','sent','delivered','read','failed'])->default('queued')->index();
            $t->unsignedInteger('error_code')->nullable();
            $t->string('error_category', 50)->nullable()->index();  // INVALID_PHONE, AUTH_ERROR, etc.
            $t->text('error_msg')->nullable();
            $t->json('provider_response')->nullable();
            $t->dateTime('sent_at')->nullable()->index();
            $t->dateTime('delivered_at')->nullable();
            $t->dateTime('read_at')->nullable();
            $t->timestamps();
            $t->index(['client_id', 'status']);
            $t->index(['sent_at', 'status']);
        });
    }

    public static function createTemplates(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_templates')) return;
        Capsule::schema()->create('mod_wabek_templates', function (Blueprint $t) {
            $t->increments('id');
            $t->string('slug', 100)->unique();
            $t->string('name', 150);
            $t->string('category', 50)->default('general')->index();
            $t->text('content');
            $t->json('variables')->nullable();
            $t->boolean('is_active')->default(true)->index();
            $t->boolean('is_system')->default(false);
            $t->unsignedInteger('version')->default(1);
            $t->text('notes')->nullable();
            $t->timestamps();
        });
    }

    public static function createCampaigns(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_campaigns')) return;
        Capsule::schema()->create('mod_wabek_campaigns', function (Blueprint $t) {
            $t->increments('id');
            $t->string('name', 150);
            $t->text('message');
            $t->string('template_key', 100)->nullable();
            $t->string('instance_id', 100)->nullable();
            $t->json('segment')->nullable();
            $t->enum('status', ['draft','scheduled','running','paused','completed','cancelled'])->default('draft')->index();
            $t->unsignedInteger('total_recipients')->default(0);
            $t->unsignedInteger('sent_count')->default(0);
            $t->unsignedInteger('delivered_count')->default(0);
            $t->unsignedInteger('read_count')->default(0);
            $t->unsignedInteger('failed_count')->default(0);
            $t->unsignedInteger('delay_ms')->default(500);
            $t->dateTime('scheduled_at')->nullable();
            $t->dateTime('started_at')->nullable();
            $t->dateTime('completed_at')->nullable();
            $t->unsignedInteger('created_by')->nullable();
            $t->timestamps();
        });
    }

    public static function createCampaignRecipients(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_campaign_recipients')) return;
        Capsule::schema()->create('mod_wabek_campaign_recipients', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('campaign_id')->index();
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('phone', 30);
            $t->string('name', 150)->nullable();
            $t->enum('status', ['pending','sent','delivered','read','failed','skipped'])->default('pending')->index();
            $t->string('message_id', 250)->nullable();
            $t->text('error')->nullable();
            $t->dateTime('sent_at')->nullable();
            $t->index(['campaign_id', 'status']);
        });
    }

    public static function createOtp(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_otp')) return;
        Capsule::schema()->create('mod_wabek_otp', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('phone', 30)->index();
            $t->string('code', 10);
            $t->string('purpose', 50)->default('login');
            $t->tinyInteger('attempts')->default(0);
            $t->tinyInteger('max_attempts')->default(3);
            $t->boolean('is_verified')->default(false);
            $t->boolean('is_expired')->default(false);
            $t->string('ip_address', 45)->nullable();
            $t->dateTime('expires_at')->index();
            $t->dateTime('verified_at')->nullable();
            $t->timestamps();
            $t->index(['phone', 'purpose', 'is_verified']);
        });
    }

    public static function createWebhooks(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_webhooks')) return;
        Capsule::schema()->create('mod_wabek_webhooks', function (Blueprint $t) {
            $t->increments('id');
            $t->string('event_type', 100)->index();
            $t->string('message_id', 250)->nullable()->index();
            $t->string('phone', 30)->nullable()->index();
            $t->string('status', 50)->nullable();
            $t->unsignedInteger('error_code')->nullable();
            $t->string('error_msg', 500)->nullable();
            $t->json('payload')->nullable();
            $t->timestamps();
            $t->index('created_at');
        });
    }

    public static function createMigrations(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_migrations')) return;
        Capsule::schema()->create('mod_wabek_migrations', function (Blueprint $t) {
            $t->increments('id');
            $t->string('version', 20)->unique();
            $t->string('description', 200)->nullable();
            $t->dateTime('applied_at');
        });
    }

    public static function createTemplateVersions(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_template_versions')) return;
        Capsule::schema()->create('mod_wabek_template_versions', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('template_id')->index();
            $t->text('content');
            $t->unsignedInteger('version');
            $t->unsignedInteger('changed_by')->nullable();
            $t->text('notes')->nullable();
            $t->timestamps();
        });
    }

    public static function createCampaignEvents(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_campaign_events')) return;
        Capsule::schema()->create('mod_wabek_campaign_events', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('campaign_id')->index();
            $t->string('event_type', 50)->index();
            $t->unsignedInteger('client_id')->nullable();
            $t->string('phone', 30)->nullable();
            $t->json('data')->nullable();
            $t->timestamps();
        });
    }

    public static function createAbandonedCarts(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_abandoned_carts')) return;
        Capsule::schema()->create('mod_wabek_abandoned_carts', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('session_id', 100)->nullable()->index();
            $t->string('email', 150)->nullable()->index();
            $t->string('phone', 30)->nullable();
            $t->json('cart_items')->nullable();
            $t->decimal('cart_value', 10, 2)->default(0);
            $t->string('currency', 10)->default('USD');
            $t->enum('status', ['open','reminded_1','reminded_2','reminded_3','recovered','expired'])->default('open')->index();
            $t->tinyInteger('reminders_sent')->default(0);
            $t->dateTime('last_reminder_at')->nullable();
            $t->dateTime('recovered_at')->nullable();
            $t->decimal('recovered_value', 10, 2)->nullable();
            $t->timestamps();
            $t->index('created_at');
        });
    }

    public static function createStatistics(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_statistics')) return;
        Capsule::schema()->create('mod_wabek_statistics', function (Blueprint $t) {
            $t->increments('id');
            $t->date('date')->index();
            $t->string('event', 100)->nullable()->index();
            $t->string('country', 10)->nullable()->index();
            $t->unsignedInteger('sent')->default(0);
            $t->unsignedInteger('delivered')->default(0);
            $t->unsignedInteger('read')->default(0);
            $t->unsignedInteger('failed')->default(0);
            $t->unique(['date', 'event', 'country'], 'stats_unique');
        });
    }

    public static function createActivityLog(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_activity_log')) return;
        Capsule::schema()->create('mod_wabek_activity_log', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('admin_id')->nullable()->index();
            $t->string('action', 100)->index();
            $t->string('entity_type', 50)->nullable();
            $t->unsignedInteger('entity_id')->nullable();
            $t->json('data')->nullable();
            $t->string('ip_address', 45)->nullable();
            $t->timestamps();
            $t->index('created_at');
        });
    }

    public static function createAuditLog(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_audit_log')) return;
        Capsule::schema()->create('mod_wabek_audit_log', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('admin_id')->nullable()->index();
            $t->string('action', 100);
            $t->string('entity', 50)->nullable();
            $t->unsignedInteger('entity_id')->nullable();
            $t->json('before')->nullable();
            $t->json('after')->nullable();
            $t->string('ip_address', 45)->nullable();
            $t->timestamps();
        });
    }

    public static function createOptOut(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_optout')) return;
        Capsule::schema()->create('mod_wabek_optout', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('client_id')->unique()->index();
            $t->string('reason', 200)->nullable();
            $t->timestamps();
        });
    }


    public static function createConversations(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_conversations')) return;
        Capsule::schema()->create('mod_wabek_conversations', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('phone', 30)->index();
            $t->string('client_name', 150)->nullable();
            $t->string('instance_id', 100)->nullable()->index();
            $t->enum('status', ['open','pending','resolved','spam'])->default('open')->index();
            $t->unsignedInteger('assigned_to')->nullable()->index();
            $t->unsignedInteger('unread_count')->default(0);
            $t->text('last_message')->nullable();
            $t->dateTime('last_message_at')->nullable()->index();
            $t->timestamps();
            $t->unique(['phone', 'instance_id'], 'conv_phone_instance');
        });
    }

    public static function createIncomingMessages(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_incoming_messages')) return;
        Capsule::schema()->create('mod_wabek_incoming_messages', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('conversation_id')->nullable()->index();
            $t->unsignedInteger('client_id')->nullable()->index();
            $t->string('phone', 30)->index();
            $t->string('instance_id', 100)->nullable()->index();
            $t->string('wa_message_id', 250)->nullable()->unique();
            $t->enum('direction', ['inbound','outbound'])->default('inbound')->index();
            $t->enum('message_type', ['text','image','document','audio','video','sticker','location','contacts','reaction','unknown'])->default('text');
            $t->text('content')->nullable();
            $t->string('media_url', 500)->nullable();
            $t->string('media_mime', 100)->nullable();
            $t->string('media_filename', 250)->nullable();
            $t->json('location_data')->nullable();
            $t->json('reaction_data')->nullable();
            $t->boolean('is_read')->default(false)->index();
            $t->unsignedInteger('replied_by')->nullable();
            $t->dateTime('replied_at')->nullable();
            $t->text('internal_note')->nullable();
            $t->dateTime('received_at')->nullable()->index();
            $t->timestamps();
        });
    }

    public static function createMedia(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_media')) return;
        Capsule::schema()->create('mod_wabek_media', function (Blueprint $t) {
            $t->increments('id');
            $t->string('filename', 250);
            $t->string('original_name', 250);
            $t->string('mime_type', 100);
            $t->unsignedBigInteger('file_size')->default(0);
            $t->string('storage_path', 500);
            $t->string('url', 500)->nullable();
            $t->enum('media_type', ['image','document','audio','video','vcard','location'])->default('image')->index();
            $t->unsignedInteger('uploaded_by')->nullable();
            $t->unsignedInteger('used_count')->default(0);
            $t->timestamps();
        });
    }

    public static function createPermissionMap(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_permission_map')) return;
        Capsule::schema()->create('mod_wabek_permission_map', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('role_id')->index();
            $t->string('permission', 100)->index();
            $t->boolean('allowed')->default(true);
            $t->timestamps();
            $t->unique(['role_id', 'permission'], 'perm_role_unique');
        });
    }


    public static function createClientSettings(): void
    {
        if (Capsule::schema()->hasTable('mod_wabek_client_settings')) return;
        Capsule::schema()->create('mod_wabek_client_settings', function (Blueprint $t) {
            $t->increments('id');
            $t->unsignedInteger('client_id')->unique()->index();
            $t->string('whatsapp_number', 30)->nullable();  // E.164 digits, no +
            $t->string('whatsapp_raw', 50)->nullable();     // original as entered by admin
            $t->enum('verification_status', ['unverified','pending','verified','blocked'])->default('unverified');
            $t->boolean('opt_out')->default(false)->index();
            $t->string('unsubscribe_token', 64)->nullable()->unique();
            $t->string('preferred_language', 10)->nullable();
            $t->text('notes')->nullable();
            $t->dateTime('last_message_at')->nullable();
            $t->timestamps();
        });
    }

}

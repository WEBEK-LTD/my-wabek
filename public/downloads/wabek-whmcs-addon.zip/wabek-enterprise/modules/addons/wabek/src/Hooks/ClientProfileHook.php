<?php
declare(strict_types=1);

namespace Wabek\Hooks;

use Wabek\Config\Settings;
use Wabek\Models\ClientSettings;
use Wabek\Models\Message;
use Wabek\Services\WhatsAppService;
use Wabek\Helpers\PhoneHelper;
use WHMCS\Database\Capsule;

class ClientProfileHook
{
    public static function render(int $clientId, array $vars): string
    {
        if (!Settings::apiKey()) {
            return self::wrapPanel(
                $clientId,
                '<p class="text-muted" style="font-size:13px;margin:0">
                    WABEK not configured.
                    <a href="addonmodules.php?module=wabek&tab=settings">Configure -></a>
                </p>'
            );
        }

        // Handle form submissions
        $notice = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $notice = self::handlePost($clientId);
        }

        $settings  = ClientSettings::getOrCreate($clientId);
        $stats     = ClientSettings::getStats($clientId);
        $phoneResult = ClientSettings::getEffectivePhoneResult($clientId);
        $hasPhone  = $phoneResult['valid'];
        $phone     = $hasPhone ? ($phoneResult['phone'] ?? '') : '';
        $e164      = $hasPhone ? ($phoneResult['e164'] ?? '') : '';
        $source    = $phoneResult['source_label'] ?? $phoneResult['source'] ?? '-';

        // Recent messages
        $recentMsgs = Capsule::table('mod_wabek_messages')
            ->where('client_id', $clientId)
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        ob_start();
        ?>
        <?= $notice ?>

        <!-- Phone Status Bar -->
        <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:<?= $hasPhone ? '#f0fdf4' : '#fef2f2' ?>;border-radius:8px;margin-bottom:12px;border:1px solid <?= $hasPhone ? '#bbf7d0' : '#fecaca' ?>">
          <span style="font-size:18px"><?= $hasPhone ? '📱' : '⚠️' ?></span>
          <div style="flex:1">
            <?php if ($hasPhone): ?>
              <span style="font-weight:600;color:#15803d"><?= htmlspecialchars($e164) ?></span>
              <span style="font-size:11px;color:#64748b;margin-left:8px">via <?= htmlspecialchars($source) ?></span>
              <a href="https://wa.me/<?= htmlspecialchars($phone) ?>" target="_blank"
                 style="margin-left:8px;font-size:11px;color:#25D366;border:1px solid #25D366;padding:1px 8px;border-radius:4px;text-decoration:none">
                Open in WhatsApp ↗
              </a>
            <?php else: ?>
              <span style="color:#b91c1c;font-size:13px">No WhatsApp number - set one below</span>
            <?php endif; ?>
          </div>
          <div style="text-align:right;font-size:11px;color:#64748b">
            <?= (bool)$settings->opt_out ? '<span style="background:#fee2e2;color:#b91c1c;padding:2px 8px;border-radius:4px">Opted Out</span>' : '<span style="background:#dcfce7;color:#15803d;padding:2px 8px;border-radius:4px">Opted In</span>' ?>
          </div>
        </div>

        <!-- Stats Row -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px">
          <?php foreach ([
            ['Sent',      $stats['sent'],     '#2563eb'],
            ['Received',  $stats['received'], '#16a34a'],
            ['Status',    ucfirst($settings->verification_status ?? 'unverified'), '#7c3aed'],
            ['Last Msg',  $stats['last_msg_at'] ? date('d M', strtotime($stats['last_msg_at'])) : 'Never', '#64748b'],
          ] as [$lbl,$val,$clr]): ?>
          <div style="text-align:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px">
            <div style="font-size:16px;font-weight:700;color:<?= $clr ?>"><?= htmlspecialchars((string)$val) ?></div>
            <div style="font-size:11px;color:#94a3b8"><?= $lbl ?></div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Quick Send -->
        <?php if ($hasPhone): ?>
        <form method="post" style="margin-bottom:12px">
          <input type="hidden" name="_wabek_action" value="quick_send">
          <div style="display:flex;gap:8px;align-items:flex-end">
            <div style="flex:1">
              <label style="font-size:11px;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:.4px;display:block;margin-bottom:4px">
                Quick Send to <?= htmlspecialchars($e164) ?>
              </label>
              <textarea name="_wabek_msg" rows="2" placeholder="Type WhatsApp message..."
                style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;resize:none;font-family:inherit"
                required><?= htmlspecialchars($_POST['_wabek_msg'] ?? '') ?></textarea>
            </div>
            <button type="submit"
              style="background:#25D366;color:#fff;border:none;padding:9px 18px;border-radius:8px;cursor:pointer;font-weight:600;font-size:13px;white-space:nowrap;height:fit-content">
              📤 Send
            </button>
          </div>
        </form>
        <?php endif; ?>

        <!-- Set WABEK Number -->
        <form method="post" style="margin-bottom:12px">
          <input type="hidden" name="_wabek_action" value="save_number">
          <label style="font-size:11px;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:.4px;display:block;margin-bottom:4px">
            WABEK WhatsApp Number Override
          </label>
          <div style="display:flex;gap:8px">
            <input type="text" name="_wabek_number"
              value="<?= htmlspecialchars($settings->whatsapp_raw ?? '') ?>"
              placeholder="e.g. +905446731942 or 905446731942"
              style="flex:1;padding:7px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;font-family:monospace">
            <button type="submit"
              style="background:#2563eb;color:#fff;border:none;padding:7px 16px;border-radius:8px;cursor:pointer;font-size:13px;white-space:nowrap">
              Save
            </button>
            <?php if ($settings->whatsapp_number): ?>
            <button type="submit" name="_wabek_number" value=""
              style="background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;padding:7px 14px;border-radius:8px;cursor:pointer;font-size:13px">
              Clear
            </button>
            <?php endif; ?>
          </div>
          <small style="color:#94a3b8;font-size:11px">
            This overrides the WHMCS phone number for WhatsApp sending.
            Leave empty to use WHMCS phone (<?= htmlspecialchars($phoneResult['source_label'] ?? 'WHMCS phone') ?>).
          </small>
        </form>

        <!-- Opt out toggle -->
        <form method="post" style="margin-bottom:12px">
          <input type="hidden" name="_wabek_action" value="toggle_optout">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
            <input type="checkbox" name="_wabek_optout" value="1"
                   <?= $settings->opt_out ? 'checked' : '' ?>
                   onchange="this.form.submit()"
                   style="width:16px;height:16px;accent-color:#dc2626">
            <span style="font-size:13px;color:#475569">Opted out from WhatsApp messages</span>
          </label>
        </form>

        <!-- Recent Messages -->
        <?php if ($recentMsgs->isNotEmpty()): ?>
        <div>
          <div style="font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.4px;margin-bottom:6px">
            Recent Messages
            <a href="addonmodules.php?module=wabek&tab=messages&client_id=<?= $clientId ?>"
               style="font-weight:400;margin-left:8px;color:#2563eb">View all -></a>
          </div>
          <?php foreach ($recentMsgs as $msg): ?>
          <div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #f1f5f9;font-size:12px">
            <span style="width:60px;color:#94a3b8;white-space:nowrap"><?= date('d M', strtotime($msg->created_at)) ?></span>
            <code style="background:#f1f5f9;padding:1px 6px;border-radius:4px;font-size:10px;flex-shrink:0"><?= htmlspecialchars($msg->event) ?></code>
            <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#475569"><?= htmlspecialchars(substr($msg->content ?? '', 0, 50)) ?></span>
            <span style="background:<?= $msg->status==='delivered'?'#dcfce7':($msg->status==='failed'?'#fee2e2':'#f1f5f9') ?>;
                         color:<?= $msg->status==='delivered'?'#15803d':($msg->status==='failed'?'#b91c1c':'#64748b') ?>;
                         padding:1px 7px;border-radius:99px;font-size:10px;font-weight:600;white-space:nowrap">
              <?= ucfirst($msg->status) ?>
            </span>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php
        return self::wrapPanel($clientId, ob_get_clean());
    }

    // ── Handle POST actions ────────────────────────────────────────────────
    private static function handlePost(int $clientId): string
    {
        $action = $_POST['_wabek_action'] ?? '';

        if ($action === 'quick_send') {
            $msg = trim($_POST['_wabek_msg'] ?? '');
            $phoneResult = ClientSettings::getEffectivePhoneResult($clientId);

            if (!$msg) return self::alert('danger', 'Message cannot be empty.');
            if (!$phoneResult['valid']) return self::alert('danger', 'No valid WhatsApp number for this client.');

            $wa = new WhatsAppService();
            $result = $wa->sendText($phoneResult['phone'], $msg);

            if ($result['success']) {
                // Log it
                Message::create([
                    'client_id'   => $clientId,
                    'phone'       => $phoneResult['phone'],
                    'event'       => 'admin_quick_send',
                    'content'     => $msg,
                    'status'      => Message::STATUS_SENT,
                    'message_id'  => $result['messageId'] ?? null,
                    'sent_at'     => date('Y-m-d H:i:s'),
                    'provider_response' => json_encode(['source' => 'admin_client_profile']),
                ]);
                // Update last_message_at
                ClientSettings::update($clientId, ['last_message_at' => date('Y-m-d H:i:s')]);
                return self::alert('success', '✓ Message sent to ' . htmlspecialchars($phoneResult['e164']));
            }

            return self::alert('danger', '✕ Send failed: ' . htmlspecialchars($result['error'] ?? 'Unknown'));
        }

        if ($action === 'save_number') {
            $raw = trim($_POST['_wabek_number'] ?? '');
            $result = ClientSettings::saveNumber($clientId, $raw);
            if (!$result['success']) {
                return self::alert('danger', 'Invalid number: ' . htmlspecialchars($result['error'] ?? ''));
            }
            $msg = empty($raw) ? 'WABEK number cleared - will use WHMCS phone.' : '✓ Saved: ' . htmlspecialchars($result['e164'] ?? '');
            return self::alert('success', $msg);
        }

        if ($action === 'toggle_optout') {
            $optOut = isset($_POST['_wabek_optout']);
            ClientSettings::setOptOut($clientId, $optOut);
            return self::alert('success', $optOut ? 'Client opted out from WhatsApp messages.' : 'Client opted back in.');
        }

        return '';
    }

    private static function wrapPanel(int $clientId, string $content): string
    {
        return '
<div class="panel panel-default" style="border-color:#22c55e20">
  <div class="panel-heading" style="background:linear-gradient(135deg,#f0fdf4,#dcfce7);border-color:#86efac">
    <h3 class="panel-title" style="color:#15803d;font-weight:700;font-size:13px;display:flex;align-items:center;gap:6px">
      <span style="font-size:16px">📱</span> WABEK WhatsApp
      <a href="addonmodules.php?module=wabek" style="margin-left:auto;font-size:11px;color:#16a34a;font-weight:400">Open WABEK -></a>
    </h3>
  </div>
  <div class="panel-body" style="padding:14px">
    ' . $content . '
  </div>
</div>';
    }

    private static function alert(string $type, string $msg): string
    {
        $colors = [
            'success' => ['#f0fdf4','#15803d','#86efac'],
            'danger'  => ['#fef2f2','#b91c1c','#fca5a5'],
            'warning' => ['#fffbeb','#92400e','#fcd34d'],
        ];
        [$bg, $text, $border] = $colors[$type] ?? $colors['warning'];
        return "<div style='background:{$bg};color:{$text};border:1px solid {$border};border-radius:8px;padding:8px 12px;margin-bottom:10px;font-size:13px'>{$msg}</div>";
    }
}

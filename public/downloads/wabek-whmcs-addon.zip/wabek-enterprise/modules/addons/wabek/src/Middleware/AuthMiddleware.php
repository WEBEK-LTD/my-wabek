<?php
declare(strict_types=1);

namespace Wabek\Middleware;

class AuthMiddleware
{
    public static function requireAdmin(array $vars): bool
    {
        return !empty($vars['adminid']) && (int)$vars['adminid'] > 0;
    }

    public static function sanitize(mixed $input): string
    {
        return htmlspecialchars(strip_tags((string) $input), ENT_QUOTES, 'UTF-8');
    }

    public static function sanitizeArray(array $data): array
    {
        return array_map([self::class, 'sanitize'], $data);
    }

    public static function validatePhone(string $phone): bool
    {
        $clean = preg_replace('/[^0-9]/', '', $phone);
        return strlen($clean) >= 7 && strlen($clean) <= 15;
    }

    public static function validatePositiveInt(mixed $value): bool
    {
        return is_numeric($value) && (int)$value > 0;
    }
}

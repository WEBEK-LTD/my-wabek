<?php
declare(strict_types=1);

namespace Wabek\Bootstrap;

use Wabek\Config\Settings;

class App
{
    private static bool   $booted  = false;
    private static string $rootDir = '';

    public static function boot(string $rootDir): void
    {
        if (self::$booted) return;
        self::$rootDir = $rootDir;
        self::$booted  = true;

        // PHP version check
        if (PHP_VERSION_ID < 80100) {
            throw new \RuntimeException('WABEK requires PHP 8.1+. Current: ' . PHP_VERSION);
        }

        // Load settings once
        Settings::init();
    }

    public static function rootDir(): string
    {
        return self::$rootDir;
    }

    public static function version(): string
    {
        return '3.0.0';
    }

    public static function reset(): void
    {
        self::$booted = false;
    }
}

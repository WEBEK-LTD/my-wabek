<?php
declare(strict_types=1);

namespace Wabek\Bootstrap;

class Autoloader
{
    private static string $srcDir;
    private static bool   $registered = false;

    public static function register(string $srcDir): void
    {
        if (self::$registered) return;
        self::$srcDir    = rtrim($srcDir, '/');
        self::$registered = true;
        spl_autoload_register([self::class, 'load']);
    }

    public static function load(string $class): void
    {
        if (strpos($class, 'Wabek\\') !== 0) return;

        $relative = str_replace('Wabek\\', '', $class);
        $file     = self::$srcDir . '/' . str_replace('\\', '/', $relative) . '.php';

        if (file_exists($file)) {
            require_once $file;
        }
    }
}

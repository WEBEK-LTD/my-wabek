<?php
declare(strict_types=1);

namespace Wabek\Services;

use Wabek\Config\Settings;
use Wabek\Helpers\PhoneHelper;
use Wabek\Helpers\ClientHelper;
use Wabek\Helpers\TemplateParser;
use WHMCS\Database\Capsule;

class AbandonedCartService
{
    private const REMINDER_DELAYS = [
        1 => 30,     // Reminder 1: 30 minutes after abandonment
        2 => 240,    // Reminder 2: 4 hours after abandonment
        3 => 1440,   // Reminder 3: 24 hours after abandonment
    ];

    /**
     * Track a cart - called when client adds items but doesn't complete.
     */
    private static function tableExists(): bool
    {
        static $checked = null;
        if ($checked === null) {
            $checked = Capsule::schema()->hasTable('mod_wabek_abandoned_carts');
        }
        return $checked;
    }

    public static function track(
        int    $clientId,
        string $sessionId,
        string $email,
        array  $items,
        float  $value,
        string $currency = 'USD'
    ): void {
        if (!Settings::bool('abandoned_cart_enabled', false)) return;

        $phone = PhoneHelper::getClientPhone($clientId);

        // Update if exists, create if new
        $existing = Capsule::table('mod_wabek_abandoned_carts')
            ->where('session_id', $sessionId)
            ->where('status', 'open')
            ->first();

        $data = [
            'client_id'   => $clientId ?: null,
            'session_id'  => $sessionId,
            'email'       => $email,
            'phone'       => $phone ?: null,
            'cart_items'  => json_encode($items),
            'cart_value'  => $value,
            'currency'    => $currency,
            'status'      => 'open',
            'updated_at'  => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            Capsule::table('mod_wabek_abandoned_carts')
                ->where('id', $existing->id)
                ->update($data);
        } else {
            Capsule::table('mod_wabek_abandoned_carts')->insert(array_merge($data, [
                'reminders_sent' => 0,
                'created_at'     => date('Y-m-d H:i:s'),
            ]));
        }
    }

    /**
     * Mark cart as recovered (called on order completion).
     */
    public static function markRecovered(string $sessionId, float $value = 0): void
    {
        if (!self::tableExists()) return ;
        Capsule::table('mod_wabek_abandoned_carts')
            ->where('session_id', $sessionId)
            ->whereIn('status', ['open','reminded_1','reminded_2','reminded_3'])
            ->update([
                'status'          => 'recovered',
                'recovered_at'    => date('Y-m-d H:i:s'),
                'recovered_value' => $value ?: null,
                'updated_at'      => date('Y-m-d H:i:s'),
            ]);
    }

    /**
     * Process all pending reminders - called from cron.
     */
    public static function processReminders(): array
    {
        if (!self::tableExists()) return [];
        if (!Settings::bool('abandoned_cart_enabled', false)) {
            return ['processed' => 0, 'sent' => 0];
        }

        $stats = ['processed' => 0, 'sent' => 0, 'skipped' => 0];
        $now   = time();

        foreach (self::REMINDER_DELAYS as $reminderNum => $delayMinutes) {
            $statusBefore = $reminderNum === 1 ? 'open' : 'reminded_' . ($reminderNum - 1);
            $statusAfter  = 'reminded_' . $reminderNum;
            $templateSlug = 'abandoned_cart_' . $reminderNum;

            $cutoff = date('Y-m-d H:i:s', $now - ($delayMinutes * 60));

            $carts = Capsule::table('mod_wabek_abandoned_carts')
                ->where('status', $statusBefore)
                ->where('updated_at', '<=', $cutoff)
                ->whereNotNull('phone')
                ->limit(50)
                ->get();

            foreach ($carts as $cart) {
                $stats['processed']++;
                $phone = PhoneHelper::format((string)($cart->phone ?? ''));
                if (!$phone) { $stats['skipped']++; continue; }

                $items   = json_decode($cart->cart_items ?? '[]', true);
                $itemStr = self::formatItems($items);
                $name    = $cart->client_id
                    ? ClientHelper::getName((int)$cart->client_id)
                    : (explode('@', (string)$cart->email)[0] ?? 'Customer');

                $tpl = Capsule::table('mod_wabek_templates')
                    ->where('slug', $templateSlug)
                    ->where('is_active', true)
                    ->value('content');

                if (!$tpl) { $stats['skipped']++; continue; }

                $message = TemplateParser::parse($tpl, [
                    'name'         => $name,
                    'cart_items'   => $itemStr,
                    'cart_value'   => number_format((float)$cart->cart_value, 2),
                    'currency'     => (string)$cart->currency,
                    'checkout_url' => ClientHelper::getPortalUrl() . '/cart.php',
                ]);

                $wa     = new WhatsAppService();
                $result = $wa->sendText($phone, $message);

                if ($result['success']) {
                    Capsule::table('mod_wabek_abandoned_carts')
                        ->where('id', $cart->id)
                        ->update([
                            'status'           => $statusAfter,
                            'reminders_sent'   => (int)$cart->reminders_sent + 1,
                            'last_reminder_at' => date('Y-m-d H:i:s'),
                            'updated_at'       => date('Y-m-d H:i:s'),
                        ]);
                    $stats['sent']++;
                }
            }
        }

        return $stats;
    }

    /**
     * Get analytics summary.
     */
    public static function analytics(): array
    {
        if (!self::tableExists()) return [];
        $rows = Capsule::table('mod_wabek_abandoned_carts')
            ->select(
                Capsule::raw('COUNT(*) as total'),
                Capsule::raw('SUM(status="recovered") as recovered'),
                Capsule::raw('SUM(CASE WHEN status="recovered" THEN recovered_value ELSE 0 END) as revenue'),
                Capsule::raw('SUM(reminders_sent) as reminders_sent')
            )->first();

        $total     = (int)($rows->total     ?? 0);
        $recovered = (int)($rows->recovered ?? 0);
        $revenue   = (float)($rows->revenue ?? 0);

        return [
            'total'           => $total,
            'recovered'       => $recovered,
            'recovery_rate'   => $total > 0 ? round($recovered / $total * 100, 1) : 0,
            'revenue'         => round($revenue, 2),
            'reminders_sent'  => (int)($rows->reminders_sent ?? 0),
        ];
    }

    private static function formatItems(array $items): string
    {
        if (empty($items)) return '(empty cart)';
        $lines = [];
        foreach (array_slice($items, 0, 5) as $item) {
            $name  = $item['name']  ?? $item['product'] ?? 'Item';
            $price = isset($item['price']) ? ' - $' . number_format((float)$item['price'], 2) : '';
            $lines[] = '• ' . $name . $price;
        }
        if (count($items) > 5) $lines[] = '... and ' . (count($items) - 5) . ' more';
        return implode("\n", $lines);
    }
}

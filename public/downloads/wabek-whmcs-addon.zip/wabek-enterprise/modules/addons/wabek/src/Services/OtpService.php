<?php
declare(strict_types=1);

namespace Wabek\Services;

use Wabek\Config\Settings;
use Wabek\Helpers\PhoneHelper;
use WHMCS\Database\Capsule;

class OtpService
{
    public const PURPOSE_LOGIN    = 'login';
    public const PURPOSE_REGISTER = 'register';
    public const PURPOSE_RESET    = 'password_reset';

    public static function generate(string $phone, int $clientId, string $purpose = self::PURPOSE_LOGIN, string $ip = ''): array
    {
        if (!Settings::bool('otp_enabled', false)) {
            return ['success' => false, 'error' => 'OTP is disabled'];
        }

        $phone = PhoneHelper::format($phone);
        if (!$phone) {
            return ['success' => false, 'error' => 'Invalid phone number'];
        }

        // Rate limiting
        $rateLimit = Settings::int('otp_rate_limit', 5);
        $recentCount = Capsule::table('mod_wabek_otp')
            ->where('phone', $phone)
            ->where('purpose', $purpose)
            ->where('created_at', '>=', date('Y-m-d H:i:s', time() - 3600))
            ->count();

        if ($recentCount >= $rateLimit) {
            return ['success' => false, 'error' => 'Too many OTP requests. Please try again in an hour.'];
        }

        // Expire old OTPs
        Capsule::table('mod_wabek_otp')
            ->where('phone', $phone)
            ->where('purpose', $purpose)
            ->where('is_verified', false)
            ->update(['is_expired' => true]);

        $code       = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiryMins = Settings::int('otp_expiry_minutes', 10);
        $expiresAt  = date('Y-m-d H:i:s', time() + ($expiryMins * 60));

        Capsule::table('mod_wabek_otp')->insert([
            'client_id'    => $clientId,
            'phone'        => $phone,
            'code'         => password_hash($code, PASSWORD_BCRYPT),
            'purpose'      => $purpose,
            'attempts'     => 0,
            'max_attempts' => Settings::int('otp_max_attempts', 3),
            'is_verified'  => false,
            'is_expired'   => false,
            'ip_address'   => $ip ?: ($_SERVER['REMOTE_ADDR'] ?? ''),
            'expires_at'   => $expiresAt,
            'created_at'   => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ]);

        // Send via WhatsApp
        // Use Meta approved OTP template if configured (like WABEK source does)
        // Settings: otp_template_name = e.g. 'digits' or your approved template name
        $wa           = new WhatsAppService();
        $otpTemplate  = Settings::get('otp_template_name', '');
        $clientName   = self::getClientName($clientId);
        $companyName  = \WHMCS\Config\Setting::getValue('CompanyName') ?? 'Our Company';

        if ($otpTemplate) {
            // Send as Meta approved template — same as WABEK source
            // Template body parameter = the OTP code
            $result = $wa->sendTemplate($phone, $otpTemplate, 'en', [
                ['type' => 'body', 'parameters' => [
                    ['type' => 'text', 'text' => $code]
                ]]
            ]);
        } else {
            // Fallback: plain text (works within 24h window only)
            $tpl = Capsule::table('mod_wabek_templates')
                ->where('slug', 'otp_verification')->value('content')
                ?? "Your verification code is: *{$code}*\n\nValid for {$expiryMins} minutes.";

            $message = \Wabek\Helpers\TemplateParser::parse($tpl, [
                'otp'            => $code,
                'name'           => $clientName,
                'company'        => $companyName,
                'expiry_minutes' => (string) $expiryMins,
            ]);

            $result = $wa->sendText($phone, $message);
        }

        if (!$result['success']) {
            return ['success' => false, 'error' => 'Failed to send OTP: ' . ($result['error'] ?? 'Unknown')];
        }

        return ['success' => true, 'expires_in' => $expiryMins * 60];
    }

    public static function verify(string $phone, string $code, string $purpose = self::PURPOSE_LOGIN): array
    {
        $phone = PhoneHelper::format($phone);

        $otp = Capsule::table('mod_wabek_otp')
            ->where('phone', $phone)
            ->where('purpose', $purpose)
            ->where('is_verified', false)
            ->where('is_expired', false)
            ->where('expires_at', '>', date('Y-m-d H:i:s'))
            ->orderBy('created_at', 'desc')
            ->first();

        if (!$otp) {
            return ['success' => false, 'error' => 'OTP not found or expired. Please request a new code.'];
        }

        if ($otp->attempts >= $otp->max_attempts) {
            Capsule::table('mod_wabek_otp')->where('id', $otp->id)->update(['is_expired' => true]);
            return ['success' => false, 'error' => 'Too many incorrect attempts. Please request a new code.'];
        }

        if (!password_verify($code, $otp->code)) {
            Capsule::table('mod_wabek_otp')->where('id', $otp->id)->increment('attempts');
            $remaining = $otp->max_attempts - $otp->attempts - 1;
            return ['success' => false, 'error' => "Incorrect code. $remaining attempts remaining."];
        }

        Capsule::table('mod_wabek_otp')->where('id', $otp->id)->update([
            'is_verified' => true,
            'verified_at' => date('Y-m-d H:i:s'),
            'updated_at'  => date('Y-m-d H:i:s'),
        ]);

        return ['success' => true, 'client_id' => $otp->client_id];
    }

    private static function getClientName(int $clientId): string
    {
        if (!$clientId) return 'Customer';
        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        return $client ? trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? '')) : 'Customer';
    }
}

// Import TemplateParser in the class

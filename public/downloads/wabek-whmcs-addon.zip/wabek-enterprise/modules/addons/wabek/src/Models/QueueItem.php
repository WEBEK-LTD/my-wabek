<?php
declare(strict_types=1);

namespace Wabek\Models;

use WHMCS\Database\Capsule;

class QueueItem
{
    public static function push(array $data): int
    {
        return (int) Capsule::table('mod_wabek_queue')->insertGetId(array_merge([
            'status'       => 'pending',
            'attempts'     => 0,
            'max_attempts' => 3,
            'priority'     => 5,
            'scheduled_at' => date('Y-m-d H:i:s'),
            'created_at'   => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ], $data));
    }

    public static function pendingBatch(int $limit = 50): array
    {
        return Capsule::table('mod_wabek_queue')
            ->where('status', 'pending')
            ->where('scheduled_at', '<=', date('Y-m-d H:i:s'))
            ->where('attempts', '<', Capsule::raw('max_attempts'))
            ->orderBy('priority', 'asc')
            ->orderBy('scheduled_at', 'asc')
            ->limit($limit)
            ->get()
            ->toArray();
    }

    public static function markProcessing(int $id): void
    {
        Capsule::table('mod_wabek_queue')->where('id', $id)->update([
            'status'     => 'processing',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function markSent(int $id): void
    {
        Capsule::table('mod_wabek_queue')->where('id', $id)->update([
            'status'       => 'sent',
            'processed_at' => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ]);
    }

    public static function markFailed(int $id, string $error): void
    {
        Capsule::table('mod_wabek_queue')
            ->where('id', $id)
            ->increment('attempts', 1, [
                'error'      => $error,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

        // Check if max attempts reached
        $item = Capsule::table('mod_wabek_queue')->where('id', $id)->first();
        if ($item && $item->attempts >= $item->max_attempts) {
            Capsule::table('mod_wabek_queue')->where('id', $id)->update(['status' => 'failed']);
        } else {
            // Reschedule with exponential backoff strategy
            // Retry after: 1min, 5min, 15min, 30min
            $delays   = \Wabek\Config\Settings::retryDelays();
            $attempt  = (int)($item->attempts ?? 0);
            $delay    = $delays[$attempt - 1] ?? $delays[count($delays) - 1];
            Capsule::table('mod_wabek_queue')->where('id', $id)->update([
                'status'       => 'pending',
                'scheduled_at' => date('Y-m-d H:i:s', time() + $delay),
            ]);
        }
    }

    public static function stats(): array
    {
        $rows = Capsule::table('mod_wabek_queue')
            ->select('status', Capsule::raw('COUNT(*) as count'))
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        return [
            'pending'    => (int) ($rows['pending']    ?? 0),
            'processing' => (int) ($rows['processing'] ?? 0),
            'sent'       => (int) ($rows['sent']       ?? 0),
            'failed'     => (int) ($rows['failed']     ?? 0),
            'cancelled'  => (int) ($rows['cancelled']  ?? 0),
        ];
    }

    /**
     * Dead Letter Queue - items that exhausted all retries
     */
    public static function deadLetter(int $page = 1, int $perPage = 50): array
    {
        if (!Capsule::schema()->hasTable('mod_wabek_queue')) {
            return ['items' => collect(), 'total' => 0];
        }
        $total = Capsule::table('mod_wabek_queue')
            ->where('status', 'failed')
            ->where('attempts', '>=', Capsule::raw('max_attempts'))
            ->count();

        $items = Capsule::table('mod_wabek_queue')
            ->where('status', 'failed')
            ->where('attempts', '>=', Capsule::raw('max_attempts'))
            ->orderBy('updated_at', 'desc')
            ->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get();

        return ['items' => $items, 'total' => $total];
    }

    /**
     * Requeue dead letter items for retry
     */
    public static function requeueDead(array $ids): int
    {
        return Capsule::table('mod_wabek_queue')
            ->whereIn('id', $ids)
            ->where('status', 'failed')
            ->update([
                'status'       => 'pending',
                'attempts'     => 0,
                'scheduled_at' => date('Y-m-d H:i:s'),
                'updated_at'   => date('Y-m-d H:i:s'),
            ]);
    }
}

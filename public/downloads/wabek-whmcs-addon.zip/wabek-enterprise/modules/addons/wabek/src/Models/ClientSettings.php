<?php
declare(strict_types=1);

namespace Wabek\Models;

use WHMCS\Database\Capsule;
use Wabek\Helpers\PhoneHelper;

class ClientSettings
{
    // ── Get settings for a client ──────────────────────────────────────────
    public static function get(int $clientId): ?object
    {
        if (!Capsule::schema()->hasTable('mod_wabek_client_settings')) return null;
        return Capsule::table('mod_wabek_client_settings')
            ->where('client_id', $clientId)
            ->first();
    }

    // ── Get or create row ─────────────────────────────────────────────────
    public static function getOrCreate(int $clientId): object
    {
        $row = self::get($clientId);
        if ($row) return $row;

        // Create table if missing (upgrade scenario)
        if (!Capsule::schema()->hasTable('mod_wabek_client_settings')) {
            \Wabek\Database\Schema::createClientSettings();
        }

        Capsule::table('mod_wabek_client_settings')->insert([
            'client_id'           => $clientId,
            'whatsapp_number'     => null,
            'whatsapp_raw'        => null,
            'verification_status' => 'unverified',
            'opt_out'             => false,
            'created_at'          => date('Y-m-d H:i:s'),
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);

        return self::get($clientId);
    }

    // ── Save WhatsApp number ──────────────────────────────────────────────
    public static function saveNumber(int $clientId, string $rawNumber): array
    {
        if (empty(trim($rawNumber))) {
            // Clear the number
            self::update($clientId, [
                'whatsapp_number' => null,
                'whatsapp_raw'    => null,
            ]);
            return ['success' => true, 'phone' => null, 'cleared' => true];
        }

        // Normalize
        $result = PhoneHelper::normalize($rawNumber);
        if (!$result['valid']) {
            return ['success' => false, 'error' => $result['error'], 'original' => $rawNumber];
        }

        self::update($clientId, [
            'whatsapp_number' => $result['phone'],
            'whatsapp_raw'    => $rawNumber,
        ]);

        return ['success' => true, 'phone' => $result['phone'], 'e164' => $result['e164']];
    }

    // ── Get the WhatsApp number to use for sending ────────────────────────
    // Returns normalized E.164 digits or empty string
    public static function getEffectivePhone(int $clientId): string
    {
        $row = self::get($clientId);

        // Priority 1: WABEK-specific number
        if ($row && !empty($row->whatsapp_number)) {
            return (string)$row->whatsapp_number;
        }

        // Priority 2: WHMCS phone via PhoneHelper
        return PhoneHelper::getClientPhone($clientId);
    }

    // ── Get effective phone with full debug result ────────────────────────
    public static function getEffectivePhoneResult(int $clientId): array
    {
        $row = self::get($clientId);

        // Priority 1: WABEK number
        if ($row && !empty($row->whatsapp_number)) {
            return [
                'valid'          => true,
                'phone'          => (string)$row->whatsapp_number,
                'e164'           => '+' . $row->whatsapp_number,
                'original'       => (string)($row->whatsapp_raw ?? $row->whatsapp_number),
                'source'         => 'mod_wabek_client_settings',
                'source_label'   => 'WABEK WhatsApp Number',
                'error'          => null,
            ];
        }

        // Priority 2: WHMCS phone
        $r = PhoneHelper::getClientPhoneResult($clientId);
        if ($r['valid']) {
            $r['source_label'] = 'WHMCS Phone Number';
        }
        return $r;
    }

    // ── Update ────────────────────────────────────────────────────────────
    public static function update(int $clientId, array $data): void
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        Capsule::table('mod_wabek_client_settings')->updateOrInsert(
            ['client_id' => $clientId],
            array_merge($data, ['client_id' => $clientId, 'created_at' => date('Y-m-d H:i:s')])
        );
    }

    // ── Opt out / in ─────────────────────────────────────────────────────
    public static function getUnsubscribeToken(int $clientId): string
    {
        $row = self::getOrCreate($clientId);
        if (!empty($row->unsubscribe_token)) {
            return (string)$row->unsubscribe_token;
        }
        // Generate new token
        $token = bin2hex(random_bytes(24));
        self::update($clientId, ['unsubscribe_token' => $token]);
        return $token;
    }

    public static function findByToken(string $token): ?object
    {
        return Capsule::table('mod_wabek_client_settings')
            ->where('unsubscribe_token', $token)
            ->first();
    }

    public static function setOptOut(int $clientId, bool $optOut): void
    {
        self::update($clientId, ['opt_out' => $optOut ? 1 : 0]);
    }

    public static function isOptedOut(int $clientId): bool
    {
        $row = self::get($clientId);
        return (bool)($row->opt_out ?? false);
    }

    // ── Stats for widget ──────────────────────────────────────────────────
    public static function getStats(int $clientId): array
    {
        $sent = (int) Capsule::table('mod_wabek_messages')
            ->where('client_id', $clientId)
            ->where('direction', 'outbound')
            ->orWhere(function($q) use ($clientId) {
                $q->where('client_id', $clientId)->whereNull('direction');
            })
            ->count();

        $received = (int) Capsule::table('mod_wabek_incoming_messages')
            ->where('client_id', $clientId)
            ->count();

        $lastMsg = Capsule::table('mod_wabek_messages')
            ->where('client_id', $clientId)
            ->orderBy('created_at', 'desc')
            ->value('created_at');

        $lastStatus = Capsule::table('mod_wabek_messages')
            ->where('client_id', $clientId)
            ->orderBy('created_at', 'desc')
            ->value('status');

        return [
            'sent'        => $sent,
            'received'    => $received,
            'last_msg_at' => $lastMsg,
            'last_status' => $lastStatus,
        ];
    }
}

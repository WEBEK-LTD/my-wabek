<?php
declare(strict_types=1);

namespace Wabek\Controllers;

use Wabek\Config\Settings;
use Wabek\Models\ClientSettings;
use Wabek\Models\Message;
use Wabek\Helpers\PhoneHelper;
use Wabek\Services\OtpService;
use WHMCS\Database\Capsule;

class ClientController
{
    private array  $vars;
    private int    $clientId;
    private string $action;
    private string $moduleLink;

    public function __construct(array $vars)
    {
        $this->vars       = $vars;
        $this->clientId   = (int)($vars['clientsdetails']['id'] ?? 0);
        $this->action     = preg_replace('/[^a-z0-9_]/', '', strtolower($_GET['action'] ?? 'dashboard'));
        $this->moduleLink = $vars['modulelink'] ?? 'index.php?m=wabek';
    }

    public function dispatch(): array
    {
        if (!$this->clientId) {
            return ['templatefile' => '../../../modules/addons/wabek/templates/client/error.tpl',
                    'vars' => ['error' => 'Not logged in']];
        }

        // POST actions (opt in/out, save number, reply)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        switch ($this->action) {
            case 'messages':
                return $this->pageMessages();
            case 'conversations':
                return $this->pageConversations();
            case 'conversation':
                return $this->pageConversation();
            case 'otp':
            case 'otp_send':
            case 'otp_verify':
                return $this->pageOtp();
            case 'settings':
            case 'preferences':
                return $this->pageSettings();
            case 'optout':
                ClientSettings::setOptOut($this->clientId, true);
                return $this->pageSettings();
            case 'optin':
                ClientSettings::setOptOut($this->clientId, false);
                return $this->pageSettings();
            default:
                return $this->pageDashboard();
        }
    }

    // ── Dashboard ──────────────────────────────────────────────────────────
    private function pageDashboard(): array
    {
        $settings     = ClientSettings::getOrCreate($this->clientId);
        $phoneResult  = ClientSettings::getEffectivePhoneResult($this->clientId);
        $stats        = ClientSettings::getStats($this->clientId);

        $recentMsgs   = Capsule::table('mod_wabek_messages')
            ->where('client_id', $this->clientId)
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        $unread = Capsule::table('mod_wabek_incoming_messages')
            ->where('client_id', $this->clientId)
            ->where('is_read', false)
            ->count();

        $conversations = Capsule::table('mod_wabek_conversations')
            ->where('client_id', $this->clientId)
            ->orderBy('last_message_at', 'desc')
            ->limit(3)
            ->get();

        return $this->render('dashboard', [
            'settings'      => $settings,
            'phone_result'  => $phoneResult,
            'stats'         => $stats,
            'recent_msgs'   => $recentMsgs,
            'unread'        => (int)$unread,
            'conversations' => $conversations,
        ]);
    }

    // ── Message History ────────────────────────────────────────────────────
    private function pageMessages(): array
    {
        $page   = max(1, (int)($_GET['p'] ?? 1));
        $total  = Capsule::table('mod_wabek_messages')->where('client_id', $this->clientId)->count();
        $msgs   = Capsule::table('mod_wabek_messages')
            ->where('client_id', $this->clientId)
            ->orderBy('created_at', 'desc')
            ->offset(($page - 1) * 20)
            ->limit(20)
            ->get();

        return $this->render('messages', [
            'messages' => $msgs,
            'total'    => (int)$total,
            'page'     => $page,
            'pages'    => (int)ceil($total / 20),
        ]);
    }

    // ── Conversations List ─────────────────────────────────────────────────
    private function pageConversations(): array
    {
        $conversations = Capsule::table('mod_wabek_conversations')
            ->where('client_id', $this->clientId)
            ->orderBy('last_message_at', 'desc')
            ->limit(50)
            ->get();

        $totalUnread = Capsule::table('mod_wabek_conversations')
            ->where('client_id', $this->clientId)
            ->sum('unread_count');

        return $this->render('conversations', [
            'conversations' => $conversations,
            'total_unread'  => (int)$totalUnread,
        ]);
    }

    // ── Single Conversation ────────────────────────────────────────────────
    private function pageConversation(): array
    {
        $convId = (int)($_GET['id'] ?? 0);
        $conv   = Capsule::table('mod_wabek_conversations')
            ->where('id', $convId)
            ->where('client_id', $this->clientId)
            ->first();

        if (!$conv) return $this->pageConversations();

        // Mark as read
        Capsule::table('mod_wabek_incoming_messages')
            ->where('conversation_id', $convId)
            ->where('direction', 'inbound')
            ->update(['is_read' => true]);
        Capsule::table('mod_wabek_conversations')
            ->where('id', $convId)
            ->update(['unread_count' => 0]);

        $messages = Capsule::table('mod_wabek_incoming_messages')
            ->where('conversation_id', $convId)
            ->orderBy('received_at', 'asc')
            ->limit(100)
            ->get();

        return $this->render('conversation', [
            'conversation' => $conv,
            'messages'     => $messages,
        ]);
    }

    // ── OTP ────────────────────────────────────────────────────────────────
    private function pageOtp(): array
    {
        if (!Settings::bool('otp_enabled', false)) {
            return $this->render('otp', ['disabled' => true]);
        }

        $phoneResult = ClientSettings::getEffectivePhoneResult($this->clientId);
        $sent        = $_SESSION['wabek_otp_sent'] ?? false;
        $error       = $_SESSION['wabek_otp_error'] ?? null;
        unset($_SESSION['wabek_otp_error']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_otp'])) {
            $purpose = 'verification';
            if ($phoneResult['valid']) {
                $r = OtpService::generate($phoneResult['phone'], $this->clientId, $purpose);
                if ($r['success']) {
                    $_SESSION['wabek_otp_sent'] = true;
                    $_SESSION['wabek_otp_purpose'] = $purpose;
                    $sent = true;
                } else {
                    $error = $r['error'];
                }
            } else {
                $error = 'No valid WhatsApp number on file.';
            }
        }

        return $this->render('otp', [
            'phone_result' => $phoneResult,
            'otp_sent'     => $sent,
            'otp_error'    => $error,
            'disabled'     => false,
        ]);
    }

    // ── OTP Verify ────────────────────────────────────────────────────────
    private function pageOtpVerify(): array
    {
        $code    = trim($_POST['otp_code'] ?? '');
        $purpose = $_SESSION['wabek_otp_purpose'] ?? 'verification';
        $phone   = ClientSettings::getEffectivePhoneResult($this->clientId);

        if ($code && $phone['valid']) {
            $r = OtpService::verify($phone['phone'], $code, $purpose);
            if ($r['success']) {
                unset($_SESSION['wabek_otp_sent'], $_SESSION['wabek_otp_purpose']);
                ClientSettings::update($this->clientId, ['verification_status' => 'verified']);
                $_SESSION['wabek_otp_verified'] = true;
                return $this->pageDashboard();
            }
            $_SESSION['wabek_otp_error'] = $r['error'];
        }
        return $this->pageOtp();
    }

    // ── Settings ───────────────────────────────────────────────────────────
    private function pageSettings(): array
    {
        $settings    = ClientSettings::getOrCreate($this->clientId);
        $phoneResult = ClientSettings::getEffectivePhoneResult($this->clientId);
        $saved       = $_SESSION['wabek_settings_saved'] ?? false;
        unset($_SESSION['wabek_settings_saved']);

        return $this->render('settings', [
            'settings'     => $settings,
            'phone_result' => $phoneResult,
            'saved'        => $saved,
        ]);
    }

    // ── POST Handler ───────────────────────────────────────────────────────
    private function handlePost(): void
    {
        $action = $_POST['wabek_post_action'] ?? '';

        if ($action === 'save_settings') {
            $raw = trim($_POST['whatsapp_number'] ?? '');
            ClientSettings::saveNumber($this->clientId, $raw);

            $language = preg_replace('/[^a-z]/', '', strtolower($_POST['preferred_language'] ?? ''));
            ClientSettings::update($this->clientId, [
                'preferred_language' => $language ?: null,
            ]);
            $_SESSION['wabek_settings_saved'] = true;
        }

        if ($action === 'reply') {
            $convId  = (int)($_POST['conversation_id'] ?? 0);
            $message = trim($_POST['message'] ?? '');
            if ($convId && $message) {
                $conv = Capsule::table('mod_wabek_conversations')
                    ->where('id', $convId)
                    ->where('client_id', $this->clientId)
                    ->first();

                if ($conv) {
                    $phoneResult = ClientSettings::getEffectivePhoneResult($this->clientId);
                    if ($phoneResult['valid']) {
                        $wa     = new \Wabek\Services\WhatsAppService();
                        $result = $wa->sendText($phoneResult['phone'], $message);

                        if ($result['success']) {
                            Capsule::table('mod_wabek_incoming_messages')->insert([
                                'conversation_id' => $convId,
                                'client_id'       => $this->clientId,
                                'phone'           => $phoneResult['phone'],
                                'direction'       => 'outbound',
                                'message_type'    => 'text',
                                'content'         => $message,
                                'is_read'         => true,
                                'received_at'     => date('Y-m-d H:i:s'),
                                'created_at'      => date('Y-m-d H:i:s'),
                                'updated_at'      => date('Y-m-d H:i:s'),
                            ]);
                            Capsule::table('mod_wabek_conversations')
                                ->where('id', $convId)
                                ->update(['last_message' => $message, 'last_message_at' => date('Y-m-d H:i:s')]);
                        }
                    }
                }
            }
        }
    }

    // ── Opt out / in ──────────────────────────────────────────────────────
    // ── Render helper ──────────────────────────────────────────────────────
    private function render(string $template, array $data = []): array
    {
        $settings    = ClientSettings::getOrCreate($this->clientId);
        $phoneResult = ClientSettings::getEffectivePhoneResult($this->clientId);

        return [
            'templatefile' => '../../../modules/addons/wabek/templates/client/' . $template . '.tpl',
            'vars'         => array_merge([
                'modulelink'    => $this->moduleLink,
                'action'        => $this->action,
                'client_id'     => $this->clientId,
                'client_settings' => $settings,
                'has_phone'     => $phoneResult['valid'],
                'phone_e164'    => $phoneResult['e164']    ?? '',
                'phone_number'  => $phoneResult['phone']   ?? '',
                'phone_source'  => $phoneResult['source_label'] ?? $phoneResult['source'] ?? '',
                'opt_out'       => (bool)($settings->opt_out ?? false),
                'is_verified'   => ($settings->verification_status ?? 'unverified') === 'verified',
                'otp_enabled'   => Settings::bool('otp_enabled', false),
            ], $data),
        ];
    }
}

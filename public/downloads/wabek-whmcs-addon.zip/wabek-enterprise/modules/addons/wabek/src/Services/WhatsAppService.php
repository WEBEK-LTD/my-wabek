<?php
declare(strict_types=1);

namespace Wabek\Services;

use Wabek\Config\Settings;
use WHMCS\Database\Capsule;

/**
 * WABEK WhatsApp API Service
 *
 * Real WABEK API endpoints (from source):
 *   POST /api/v1/send          - Send message (auth: X-API-Key header)
 *   GET  /api/whatsapp/instances - List instances
 *   POST /api/v1/otp           - Send OTP
 *   POST /api/v1/otp-verify    - Verify OTP
 *   POST /api/v1/whmcs-webhook - WHMCS webhook receiver
 *
 * Auth: X-API-Key header OR api_key query param
 * 401 response: { "error": "Invalid API key" }
 */
class WhatsAppService
{
    private string $apiKey;
    private string $apiUrl;
    private string $instanceId;

    // Last raw diagnostic data - populated by every call
    private array $lastDiag = [];

    public function __construct()
    {
        $this->apiKey     = Settings::apiKey();
        $this->apiUrl     = Settings::apiUrl();
        $this->instanceId = Settings::instanceId();
    }

    // ── Send ───────────────────────────────────────────────────────────────
    public function sendText(string $phone, string $message, array $options = []): array
    {
        if (empty($this->apiKey)) {
            return ['success' => false, 'error' => 'API key not configured', 'error_code' => 'AUTH_ERROR'];
        }

        if (empty(trim($message))) {
            return ['success' => false, 'error' => 'Message cannot be empty', 'error_code' => 'INVALID_MESSAGE'];
        }

        // ── Phone validation ──────────────────────────────────────────────
        // Strip non-digits — same as WABEK source
        $normalizedPhone = preg_replace('/[^\d]/', '', $phone);

        if (!$normalizedPhone || strlen($normalizedPhone) < 7 || strlen($normalizedPhone) > 15) {
            return [
                'success'          => false,
                'error'            => 'Invalid phone number: ' . $phone,
                'error_code'       => 'INVALID_PHONE',
                'phone_original'   => $phone,
                'phone_normalized' => null,
            ];
        }

        $phoneResult = ['phone' => $normalizedPhone, 'e164' => '+' . $normalizedPhone, 'valid' => true];

        $payload = array_filter([
            'to'          => $normalizedPhone,
            'message'     => $message,
            'instance_id' => $options['instance_id'] ?? ($this->instanceId ?: null),
        ]);

        $result = $this->call('POST', '/api/v1/send', $payload);

        // Classify error
        $errorCode = null;
        if (!empty($result['error'])) {
            $errLower = strtolower($result['error']);
            $errorCode = match(true) {
                str_contains($errLower, 'invalid api')   => 'AUTH_ERROR',
                str_contains($errLower, 'unauthorized')  => 'AUTH_ERROR',
                str_contains($errLower, 'phone')         => 'INVALID_PHONE',
                str_contains($errLower, 'template')      => 'INVALID_TEMPLATE',
                str_contains($errLower, 'instance')      => 'INVALID_INSTANCE',
                str_contains($errLower, 'rate')          => 'RATE_LIMIT',
                str_contains($errLower, '131009')        => 'INVALID_PHONE',
                str_contains($errLower, '130429')        => 'RATE_LIMIT',
                str_contains($errLower, 'network')       => 'NETWORK_ERROR',
                default                                  => 'META_REJECTED',
            };
        }

        $ok = !empty($result['success']) || !empty($result['message_id']);

        // Track quota usage
        if ($ok) {
            self::trackQuota();
        }

        return array_merge($result, [
            'success'          => $ok,
            'messageId'        => $result['message_id'] ?? $result['messageId'] ?? null,
            'error_code'       => $errorCode,
            'phone_original'   => $phone,
            'phone_normalized' => $normalizedPhone,
            'phone_e164'       => $phoneResult['e164'],
        ]);
    }

    private static function trackQuota(): void
    {
        try {
            $key = 'quota_' . date('Y-m-d');
            \WHMCS\Database\Capsule::table('mod_wabek_statistics')->updateOrInsert(
                ['date' => date('Y-m-d'), 'event' => '__quota__', 'country' => null],
                [
                    'sent'      => \WHMCS\Database\Capsule::raw('sent + 1'),
                    'delivered' => \WHMCS\Database\Capsule::raw('COALESCE(delivered,0)'),
                    'read'      => \WHMCS\Database\Capsule::raw('COALESCE(`read`,0)'),
                    'failed'    => \WHMCS\Database\Capsule::raw('COALESCE(failed,0)'),
                ]
            );
        } catch (\Throwable $e) {}
    }

    public static function getTodayQuota(): int
    {
        try {
            return (int) \WHMCS\Database\Capsule::table('mod_wabek_statistics')
                ->where('date', date('Y-m-d'))
                ->where('event', '__quota__')
                ->value('sent');
        } catch (\Throwable $e) { return 0; }
    }

    // ── Send Template ─────────────────────────────────────────────────────
    public function sendTemplate(string $phone, string $templateName, string $language = 'en', array $components = [], array $options = []): array
    {
        if (empty($this->apiKey)) {
            return ['success' => false, 'error' => 'API key not configured'];
        }

        $digits = preg_replace('/[^\d]/', '', $phone);
        if (!$digits || strlen($digits) < 7) {
            return ['success' => false, 'error' => 'Invalid phone number'];
        }

        $payload = array_filter([
            'to'           => $digits,
            'template'     => $templateName,
            'language'     => $language,
            'components'   => $components ?: null,
            'instance_id'  => $options['instance_id'] ?? ($this->instanceId ?: null),
        ]);

        $result = $this->call('POST', '/api/v1/send', $payload);
        $ok     = !empty($result['success']) || !empty($result['message_id']);

        if ($ok) self::trackQuota();

        return array_merge($result, [
            'success'   => $ok,
            'messageId' => $result['message_id'] ?? $result['messageId'] ?? null,
        ]);
    }

    // ── Send Media ────────────────────────────────────────────────────────
    public function sendMedia(string $phone, string $mediaUrl, string $mediaType = 'image', string $caption = '', array $options = []): array
    {
        if (empty($this->apiKey)) {
            return ['success' => false, 'error' => 'API key not configured'];
        }
        // Strip non-digits only — don't re-normalize (caller already resolved correctly)
        $normalizedPhoneRaw = preg_replace('/[^\d]/', '', $phone);
        if (!$normalizedPhoneRaw || strlen($normalizedPhoneRaw) < 7) {
            return ['success' => false, 'error' => 'Invalid phone: ' . $phone, 'error_code' => 'INVALID_PHONE'];
        }
        $phoneResult = ['phone' => $normalizedPhoneRaw, 'e164' => '+' . $normalizedPhoneRaw, 'valid' => true];
        $payload = array_filter([
            'to'          => $normalizedPhoneRaw,
            'media_url'   => $mediaUrl,
            'media_type'  => $mediaType,
            'caption'     => $caption ?: null,
            'instance_id' => $options['instance_id'] ?? ($this->instanceId ?: null),
        ]);
        $result = $this->call('POST', '/api/v1/send', $payload);
        return array_merge($result, [
            'success'   => !empty($result['success']) || !empty($result['message_id']),
            'messageId' => $result['message_id'] ?? $result['messageId'] ?? null,
        ]);
    }

    // ── Instances ──────────────────────────────────────────────────────────
    public function getInstances(): array
    {
        $result = $this->call('GET', '/api/whatsapp/instances');
        return $result['instances'] ?? [];
    }

    // ── Connection Status ──────────────────────────────────────────────────
    /**
     * Returns detailed connection status with full diagnostics.
     * Never throws - always returns a status array.
     */
    /**
     * ═══════════════════════════════════════════════════════════════
     * Connection Status - ACCURATE implementation
     *
     * WABEK API Auth matrix (from source code):
     *   /api/v1/send              -> X-API-Key header ✅
     *   /api/v1/contacts          -> X-API-Key header ✅
     *   /api/v1/otp               -> X-API-Key header ✅
     *   /api/whatsapp/instances   -> JWT Bearer token ❌ (NOT API Key)
     *
     * Strategy:
     *   Step 1: Server reachable?  -> GET /api/v1/contacts (no auth)
     *   Step 2: API Key valid?     -> POST /api/v1/send with empty body
     *                                  401 = invalid key
     *                                  400 "to and message required" = key valid ✅
     *   Step 3: Can send?          -> POST /api/v1/send with test payload
     *                                  404 "No connected WhatsApp instance" = key valid, no instance
     *                                  200 = connected ✅
     * ═══════════════════════════════════════════════════════════════
     */
    public function getConnectionStatus(): array
    {
        $diag = [
            'api_url'        => $this->apiUrl,
            'api_key_prefix' => $this->apiKey ? substr($this->apiKey, 0, 10) . '...' : '(empty)',
            'instance_id'    => $this->instanceId ?: '(not set)',
            'steps'          => [],
        ];

        // ── Step 0: API Key present? ──────────────────────────────────────
        if (empty($this->apiKey)) {
            return $this->buildStatus('no_key', '🔴', 'API Key Not Configured',
                'Go to Settings -> API and enter your WABEK API Key.', $diag);
        }

        // ── Step 1: Is the server reachable? ─────────────────────────────
        // Use /api/v1/contacts without auth - 401 proves server is alive
        $reach = $this->rawCall('GET', '/api/v1/contacts', [], false);
        $diag['steps'][] = [
            'name'       => 'Server Reachability',
            'url'        => $this->apiUrl . '/api/v1/contacts',
            'http_code'  => $reach['http_code'],
            'curl_error' => $reach['curl_error'],
            'time'       => $reach['total_time'],
        ];

        if ($reach['curl_error']) {
            if ($reach['timed_out']) {
                return $this->buildStatus('timeout', '🔴', 'Connection Timeout',
                    'Server at ' . $this->apiUrl . ' did not respond within 15s.', $diag);
            }
            if ($reach['ssl_error']) {
                return $this->buildStatus('ssl_error', '🔴', 'SSL Error',
                    'SSL: ' . $reach['curl_error'], $diag);
            }
            return $this->buildStatus('unreachable', '🔴', 'API Unreachable',
                'cURL error: ' . $reach['curl_error'], $diag);
        }

        if ($reach['http_code'] === 0) {
            return $this->buildStatus('unreachable', '🔴', 'No Response',
                'Server returned no HTTP response.', $diag);
        }

        // http_code 401 here = server alive, auth needed (expected)
        // http_code 404 = wrong URL
        if ($reach['http_code'] === 404) {
            return $this->buildStatus('invalid_url', '🔴', 'Invalid API URL',
                'Got HTTP 404 from ' . $this->apiUrl . '/api/v1/contacts' .
                "
Check the API Base URL in Settings. It should be: https://waabek.com", $diag);
        }

        // ── Step 2: Validate API Key ──────────────────────────────────────
        // POST /api/v1/send with empty body
        // -> 401 = invalid key
        // -> 400 with "to and message required" = KEY IS VALID ✅
        // -> 404 "No connected WhatsApp instance" = key valid, no instance
        $keyTest = $this->rawCall('POST', '/api/v1/send', [], true);
        $keyBody = $keyTest['parsed'] ?? [];
        $keyErr  = $keyBody['error'] ?? '';

        $diag['steps'][] = [
            'name'         => 'API Key Validation',
            'url'          => $this->apiUrl . '/api/v1/send',
            'method'       => 'POST',
            'headers_sent' => ['X-API-Key: ' . substr($this->apiKey,0,10).'...', 'Content-Type: application/json'],
            'http_code'    => $keyTest['http_code'],
            'response_body'=> $keyTest['raw_body'],
            'parsed_error' => $keyErr,
            'time'         => $keyTest['total_time'],
        ];

        if ($keyTest['http_code'] === 401) {
            // Show EXACT server message
            $serverMsg = $keyErr ?: $keyTest['raw_body'];
            return $this->buildStatus('invalid_key', '🔴', 'Authentication Failed (HTTP 401)',
                "Server response: " . $serverMsg .
                "

Your API Key was rejected. Please:
" .
                "1. Go to waabek.com -> Dashboard -> API Keys
" .
                "2. Copy the key exactly (no spaces)
" .
                "3. Paste in Settings -> API -> WABEK API Key",
                $diag, ['server_message' => $serverMsg]);
        }

        if ($keyTest['http_code'] === 429) {
            return $this->buildStatus('rate_limited', '🟠', 'Rate Limited (HTTP 429)',
                'Too many requests. Wait a few minutes.', $diag);
        }

        if ($keyTest['http_code'] === 400 && str_contains(strtolower($keyErr), 'required')) {
            // ✅ KEY IS VALID - server said "to and message required"
            $diag['steps'][count($diag['steps'])-1]['result'] = 'KEY VALID';

            // ── Step 3: Check for WhatsApp instance ──────────────────────
            // ── Step 3: Instance check - safe GET, NO dummy phones ────────
            $contactsTest = $this->rawCall('GET', '/api/v1/contacts', [], true);
            $diag['steps'][] = [
                'name'      => 'Instance Check (safe - no phone sent)',
                'url'       => $this->apiUrl . '/api/v1/contacts',
                'method'    => 'GET',
                'http_code' => $contactsTest['http_code'],
                'time'      => $contactsTest['total_time'],
            ];

            if ($contactsTest['http_code'] === 200) {
                return $this->buildStatus('connected', '🟢', 'Connected',
                    "API Key valid ✓  WhatsApp instance connected ✓  Ready to send.",
                    $diag, ['valid_key' => true]);
            }

            return $this->buildStatus('not_connected', '🟡', 'API Key Valid - Instance Not Connected',
                "API Key valid ✓\nHTTP {$contactsTest['http_code']} - check WABEK Dashboard -> WhatsApp.",
                $diag, ['valid_key' => true]);

            // Message sent (or tried to send) = connected!
            if ($sendTest['http_code'] === 200 || !empty($sendBody['message_id'])) {
                return $this->buildStatus('connected', '🟢', 'Connected',
                    "API Key valid ✓ WhatsApp instance connected ✓ Ready to send.",
                    $diag, ['valid_key' => true]);
            }

            // Key valid but unclear instance status
            return $this->buildStatus('key_valid_unknown', '🟡', 'API Key Valid - Instance Status Unknown',
                "API Key is valid ✓
Server response: " . $sendTest['raw_body'],
                $diag, ['valid_key' => true, 'server_response' => $sendTest['raw_body']]);
        }

        // ── Unexpected response ───────────────────────────────────────────
        $serverMsg = $keyErr ?: $keyTest['raw_body'];
        return $this->buildStatus('unknown', '🟡', 'Unexpected Response (HTTP ' . $keyTest['http_code'] . ')',
            "Server: " . substr($serverMsg, 0, 300), $diag,
            ['http_code' => $keyTest['http_code'], 'server_response' => $keyTest['raw_body']]);
    }

        public function testConnection(): bool
    {
        $status = $this->getConnectionStatus();
        return $status['status'] === 'connected';
    }

    public function getLastDiagnostics(): array
    {
        return $this->lastDiag;
    }

    // ── Internal: Build status ─────────────────────────────────────────────
    private function buildStatus(
        string $status,
        string $icon,
        string $label,
        string $detail,
        array  $diag   = [],
        array  $extra  = []
    ): array {
        $colorMap = [
            'connected'        => 'green',
            'no_key'           => 'red',
            'invalid_key'      => 'red',
            'authentication_failed' => 'red',
            'unreachable'      => 'red',
            'timeout'          => 'red',
            'ssl_error'        => 'red',
            'invalid_instance' => 'red',
            'server_error'     => 'orange',
            'session_expired'  => 'orange',
            'rate_limited'     => 'orange',
            'qr_required'      => 'yellow',
            'not_connected'    => 'yellow',
            'no_instance'      => 'yellow',
            'initializing'     => 'yellow',
            'unknown'          => 'yellow',
            'unknown_status'   => 'yellow',
        ];

        $result = array_merge([
            'status'      => $status,
            'icon'        => $icon,
            'label'       => $label,
            'detail'      => $detail,
            'color'       => $colorMap[$status] ?? 'yellow',
            'diagnostics' => $diag,
            'checked_at'  => date('Y-m-d H:i:s'),
        ], $extra);

        $this->lastDiag = $result;

        // Log to activity log
        try {
            Capsule::table('mod_wabek_activity_log')->insert([
                'action'     => 'connection_check',
                'data'       => json_encode(['status' => $status, 'label' => $label]),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {}

        return $result;
    }

    // ── Internal: Raw HTTP call with full diagnostics ──────────────────────
    private function rawCall(string $method, string $endpoint, array $data = [], bool $withAuth = true): array
    {
        $url  = rtrim($this->apiUrl, '/') . $endpoint;
        $ch   = curl_init();

        $headers = ['Content-Type: application/json', 'Accept: application/json'];
        if ($withAuth && $this->apiKey) {
            $headers[] = 'X-API-Key: ' . $this->apiKey;
        }

        curl_setopt_array($ch, [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_TIMEOUT         => 15,
            CURLOPT_CONNECTTIMEOUT  => 8,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_MAXREDIRS       => 3,
            CURLOPT_USERAGENT       => 'WABEK-WHMCS-Addon/3.0 PHP/' . PHP_VERSION,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $rawBody  = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        $curlNo   = curl_errno($ch);
        $info     = curl_getinfo($ch);
        curl_close($ch);

        $sslError  = in_array($curlNo, [CURLE_SSL_CERTPROBLEM, CURLE_SSL_CIPHER, CURLE_SSL_CONNECT_ERROR ?? 35, 60, 51, 58], true);
        $timedOut  = in_array($curlNo, [CURLE_OPERATION_TIMEDOUT, CURLE_COULDNT_CONNECT], true) || $curlNo === 28;
        $parsed    = null;
        if ($rawBody) {
            $parsed = json_decode($rawBody, true);
        }

        return [
            'http_code'   => $httpCode,
            'raw_body'    => (string)($rawBody ?: ''),
            'parsed'      => $parsed,
            'curl_error'  => $curlErr ?: null,
            'curl_errno'  => $curlNo,
            'ssl_error'   => $sslError,
            'timed_out'   => $timedOut,
            'total_time'  => round(($info['total_time'] ?? 0) * 1000) . 'ms',
            'url'         => $url,
        ];
    }

    // ── Internal: Simple call for sending ─────────────────────────────────
    private function call(string $method, string $endpoint, array $data = []): array
    {
        $raw = $this->rawCall($method, $endpoint, $data, true);

        if ($raw['curl_error']) {
            return ['success' => false, 'error' => 'Connection error: ' . $raw['curl_error']];
        }
        if (!$raw['raw_body']) {
            return ['success' => false, 'error' => 'Empty response (HTTP ' . $raw['http_code'] . ')'];
        }
        if ($raw['parsed'] === null) {
            return ['success' => false, 'error' => 'Invalid JSON response'];
        }
        if ($raw['http_code'] >= 400) {
            return array_merge($raw['parsed'], [
                'success'   => false,
                'http_code' => $raw['http_code'],
            ]);
        }

        return $raw['parsed'];
    }

    // ── OTP ────────────────────────────────────────────────────────────────
    public function sendOtp(string $phone, string $purpose = 'verification'): array
    {
        return $this->call('POST', '/api/v1/otp', ['phone' => $phone, 'purpose' => $purpose]);
    }

    public function verifyOtp(string $otpId, string $code): array
    {
        return $this->call('POST', '/api/v1/otp-verify', ['otp_id' => $otpId, 'otp' => $code]);
    }
}

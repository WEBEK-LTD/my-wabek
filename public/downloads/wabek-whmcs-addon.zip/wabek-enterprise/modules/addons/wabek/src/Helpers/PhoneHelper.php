<?php
declare(strict_types=1);

namespace Wabek\Helpers;

use Wabek\Config\Settings;
use WHMCS\Database\Capsule;

/**
 * PhoneHelper
 *
 * Logic (from old working plugin):
 *   1. Get raw phonenumber via localAPI
 *   2. Strip non-digits
 *   3. If result <= 10 digits -> prepend country code
 *
 * Country code priority:
 *   a) Client's own countrycode (tblclients.countrycode -> tblcountries -> dial code)
 *   b) Settings::default_country_code
 */
class PhoneHelper
{
    public const ERR_EMPTY       = 'INVALID_PHONE_EMPTY';
    public const ERR_TOO_SHORT   = 'INVALID_PHONE_TOO_SHORT';
    public const ERR_TOO_LONG    = 'INVALID_PHONE_TOO_LONG';
    public const ERR_PLACEHOLDER = 'INVALID_PHONE_PLACEHOLDER';

    private const BLOCKED = [
        '000000000000','0000000000','00000000000',
        '111111111111','1111111111','12345678901','1234567890',
    ];

    // ── Get client phone ───────────────────────────────────────────────────
    public static function getClientPhoneResult(int|string $clientId): array
    {
        $clientId = (int)(string)$clientId;
        if ($clientId <= 0) {
            return self::fail(self::ERR_EMPTY, '', 'invalid_client_id');
        }

        $debug = ['client_id' => $clientId, 'attempts' => []];

        // Priority 0: WABEK per-client override
        try {
            if (Capsule::schema()->hasTable('mod_wabek_client_settings')) {
                $wabek = Capsule::table('mod_wabek_client_settings')
                    ->where('client_id', $clientId)->value('whatsapp_number');
                if ($wabek) {
                    $debug['attempts'][] = ['source' => 'wabek_override', 'value' => $wabek];
                    $digits = preg_replace('/[^\d]/', '', (string)$wabek);
                    if ($digits && strlen($digits) >= 7 && strlen($digits) <= 15) {
                        return self::ok($digits, (string)$wabek, 'wabek_override', 'WABEK Override', $debug);
                    }
                }
            }
        } catch (\Throwable $e) {}

        // Priority 1: WABEK custom field
        $s = Settings::all();
        if (!empty($s['wabek_phone_custom_field'])) {
            $r = self::fromCustomField($clientId, $s['wabek_phone_custom_field'], '', $debug);
            if ($r['valid']) return $r;
        }

        // Priority 2: WHMCS custom field
        if (($s['phone_field'] ?? '') === 'customfield' && !empty($s['phone_custom_field'])) {
            $r = self::fromCustomField($clientId, $s['phone_custom_field'], '', $debug);
            if ($r['valid']) return $r;
        }

        // Priority 3+4: Use localAPI as primary source (most reliable, always has countrycode)
        $rawPhone   = '';
        $isoCode    = '';
        $clientName = '';

        if (function_exists('localAPI')) {
            try {
                $res = localAPI('GetClientsDetails', ['clientid' => $clientId, 'stats' => false]);
                if (($res['result'] ?? '') === 'success') {
                    $rawPhone   = trim((string)($res['phonenumber'] ?? ''));
                    $isoCode    = strtoupper(trim((string)($res['countrycode'] ?? $res['country'] ?? '')));
                    $clientName = trim(($res['firstname'] ?? '') . ' ' . ($res['lastname'] ?? ''));

                    $debug['attempts'][] = [
                        'source'               => 'localAPI:GetClientsDetails',
                        'phonenumber'          => $rawPhone,
                        'phonenumberformatted' => trim((string)($res['phonenumberformatted'] ?? '')),
                        'countrycode'          => $isoCode,
                        'all_phone_keys'       => array_filter(
                            array_intersect_key($res, array_flip(['phonenumber','phonenumberformatted','phone','mobile','countrycode','country'])),
                            fn($v) => $v !== ''
                        ),
                    ];

                    // Log to WHMCS activity log for debugging
                    if (function_exists('logActivity')) {
                        logActivity(sprintf(
                            'WABEK PhoneHelper client=%d phonenumber="%s" formatted="%s" countrycode="%s"',
                            $clientId,
                            $rawPhone,
                            trim((string)($res['phonenumberformatted'] ?? '')),
                            $isoCode
                        ));
                    }

                    // phonenumberformatted already has +CountryCode format
                    $formatted = trim((string)($res['phonenumberformatted'] ?? ''));
                    if ($formatted) {
                        $digits = preg_replace('/[^\d]/', '', $formatted);
                        if ($digits && strlen($digits) >= 7 && strlen($digits) <= 15
                            && !in_array($digits, self::BLOCKED, true)) {
                            $debug['attempts'][] = ['source' => 'localAPI:phonenumberformatted', 'value' => $formatted, 'digits' => $digits];
                            return self::ok($digits, $formatted, 'localAPI:phonenumberformatted', 'WHMCS Formatted Phone', $debug, $clientName);
                        }
                    }
                }
            } catch (\Throwable $e) {
                $debug['attempts'][] = ['source' => 'localAPI', 'error' => $e->getMessage()];
            }
        }

        // Fallback: direct DB (if localAPI unavailable)
        if (!$rawPhone) {
            try {
                $client = Capsule::table('tblclients')->where('id', $clientId)->first();
                if ($client) {
                    $rawPhone   = trim((string)($client->phonenumber ?? ''));
                    $isoCode    = $isoCode ?: strtoupper(trim((string)self::extractIso($client)));
                    $clientName = $clientName ?: trim(($client->firstname ?? '') . ' ' . ($client->lastname ?? ''));
                    $debug['attempts'][] = ['source' => 'db:tblclients', 'phonenumber' => $rawPhone, 'iso' => $isoCode];
                }
            } catch (\Throwable $e) {
                $debug['attempts'][] = ['source' => 'db:tblclients', 'error' => $e->getMessage()];
            }
        }

        if (!$rawPhone) {
            $r          = self::fail(self::ERR_EMPTY, '', 'no_phone_in_whmcs');
            $r['debug'] = $debug;
            return $r;
        }

        // Step B: Determine the correct country code for THIS client
        $clientCC = $isoCode ? self::getDialCodeForISO($isoCode) : '';
        $defCC    = ltrim(Settings::countryCode(), '+');
        $useCC    = $clientCC ?: $defCC;

        $debug['attempts'][] = [
            'source'       => 'tblclients.phonenumber',
            'raw_value'    => $rawPhone,
            'iso_code'     => $isoCode,
            'client_cc'    => $clientCC,
            'default_cc'   => $defCC,
            'use_cc'       => $useCC,
        ];

        // Step C: formatPhone - strip non-digits, add cc if <= 10
        $digits = preg_replace('/[^\d]/', '', $rawPhone);
        if ($useCC && strlen($digits) <= 10) {
            $digits = $useCC . $digits;
        }

        $debug['attempts'][count($debug['attempts'])-1]['digits_after'] = $digits;

        if (!$digits || strlen($digits) < 7 || strlen($digits) > 15
            || in_array($digits, self::BLOCKED, true)) {
            $r          = self::fail(self::ERR_EMPTY, $rawPhone, 'normalize_failed');
            $r['debug'] = $debug;
            return $r;
        }

        return self::ok($digits, $rawPhone, 'tblclients.phonenumber', 'WHMCS Phone', $debug, $clientName);
    }

    public static function getClientPhone(int|string $clientId): string
    {
        $r = self::getClientPhoneResult($clientId);
        return $r['valid'] ? ($r['phone'] ?? '') : '';
    }

    // ── formatPhone (old plugin logic) ────────────────────────────────────
    public static function formatPhone(string $phone, string $cc = ''): string
    {
        $digits  = preg_replace('/[^\d]/', '', $phone);
        if (!$digits) return '';
        $cleanCC = ltrim(trim($cc), '+');
        if ($cleanCC && strlen($digits) <= 10) {
            $digits = $cleanCC . $digits;
        }
        if (in_array($digits, self::BLOCKED, true)) return '';
        if (strlen($digits) < 7 || strlen($digits) > 15) return '';
        return $digits;
    }

    // ── normalize ─────────────────────────────────────────────────────────
    public static function normalize(string $raw, string $countryCode = ''): array
    {
        $cc     = ltrim($countryCode ?: Settings::countryCode(), '+');
        $result = self::formatPhone($raw, $cc);
        if (!$result) {
            $d = preg_replace('/[^\d]/', '', $raw);
            if (!$d)           return self::fail(self::ERR_EMPTY,       $raw);
            if (strlen($d)<7)  return self::fail(self::ERR_TOO_SHORT,   $raw);
            if (strlen($d)>15) return self::fail(self::ERR_TOO_LONG,    $raw);
            if (in_array($d, self::BLOCKED, true)) return self::fail(self::ERR_PLACEHOLDER, $raw);
            return self::fail(self::ERR_EMPTY, $raw);
        }
        return ['valid'=>true,'phone'=>$result,'e164'=>'+'.$result,'original'=>$raw,'country_code'=>$cc,'error'=>null,'source'=>''];
    }

    public static function format(string $raw, string $countryCode = ''): string
    {
        return self::formatPhone($raw, ltrim($countryCode ?: Settings::countryCode(), '+'));
    }

    public static function isValid(string $raw): bool { return self::normalize($raw)['valid']; }

    public static function mask(string $phone): string
    {
        if (strlen($phone) < 6) return $phone;
        return substr($phone, 0, 3) . str_repeat('*', max(0, strlen($phone)-6)) . substr($phone, -3);
    }

    // ── Extract ISO country code from tblclients row ────────────────────
    // Handles column name differences between WHMCS versions
    private static function extractIso(?object $row): string
    {
        if (!$row) return '';
        // Try known column names
        foreach (['countrycode', 'country', 'iso_code', 'country_code'] as $col) {
            $val = $row->$col ?? null;
            if ($val !== null && $val !== '') return strtoupper(trim((string)$val));
        }
        return '';
    }

    // ── getDialCodeForISO ─────────────────────────────────────────────────
    public static function getDialCodeForISO(string $iso): string
    {
        static $cache = [];
        $iso = strtoupper(trim($iso));
        if (!$iso) return '';
        if (isset($cache[$iso])) return $cache[$iso];

        // Hardcoded map first (instant, reliable)
        $map = [
            'TR'=>'90',  'EG'=>'20',  'SA'=>'966','AE'=>'971','GB'=>'44',
            'US'=>'1',   'CA'=>'1',   'AU'=>'61', 'DE'=>'49', 'FR'=>'33',
            'IN'=>'91',  'PK'=>'92',  'NG'=>'234','KE'=>'254','ZA'=>'27',
            'BR'=>'55',  'MX'=>'52',  'RU'=>'7',  'IT'=>'39', 'ES'=>'34',
            'NL'=>'31',  'SE'=>'46',  'NO'=>'47', 'DK'=>'45', 'PL'=>'48',
            'IQ'=>'964','JO'=>'962', 'KW'=>'965','QA'=>'974','OM'=>'968',
            'BH'=>'973','LB'=>'961', 'MA'=>'212','DZ'=>'213','TN'=>'216',
            'YE'=>'967','SY'=>'963', 'LY'=>'218','SD'=>'249','PS'=>'970',
            'IL'=>'972','SG'=>'65',  'MY'=>'60', 'ID'=>'62', 'TH'=>'66',
            'PH'=>'63', 'VN'=>'84',  'KR'=>'82', 'JP'=>'81', 'CN'=>'86',
            'HK'=>'852','NZ'=>'64',  'UA'=>'380','GR'=>'30', 'PT'=>'351',
            'BE'=>'32', 'CH'=>'41',  'AT'=>'43', 'FI'=>'358','IE'=>'353',
            'CZ'=>'420','HU'=>'36',  'RO'=>'40', 'BG'=>'359','HR'=>'385',
            'SK'=>'421','SI'=>'386', 'RS'=>'381','LT'=>'370','LV'=>'371',
            'EE'=>'372','BY'=>'375', 'MD'=>'373','AL'=>'355','MK'=>'389',
            'GH'=>'233','ET'=>'251', 'TZ'=>'255','UG'=>'256','CM'=>'237',
            'CI'=>'225','SN'=>'221', 'ZM'=>'260','ZW'=>'263','MZ'=>'258',
            'LU'=>'352','CY'=>'357', 'MT'=>'356','IS'=>'354','LI'=>'423',
        ];

        if (isset($map[$iso])) {
            $cache[$iso] = $map[$iso];
            return $map[$iso];
        }

        // Fallback: tblcountries
        try {
            $cols     = Capsule::schema()->getColumnListing('tblcountries');
            $phoneCol = '';
            foreach (['phonecode','calling_code','phone_code','dialcode'] as $candidate) {
                if (in_array($candidate, $cols, true)) { $phoneCol = $candidate; break; }
            }
            if ($phoneCol) {
                $val = Capsule::table('tblcountries')->where('iso', $iso)->value($phoneCol);
                if ($val) {
                    $code = preg_replace('/[^0-9]/', '', (string)$val);
                    if ($code) { $cache[$iso] = $code; return $code; }
                }
            }
        } catch (\Throwable $e) {}

        $cache[$iso] = '';
        return '';
    }

    // ── Private helpers ───────────────────────────────────────────────────
    private static function fromCustomField(int $clientId, string $fieldName, string $cc, array &$debug): array
    {
        try {
            $field = Capsule::table('tblcustomfields')
                ->where('type','client')->where('fieldname',$fieldName)->first();
            if ($field) {
                $val = Capsule::table('tblcustomfieldsvalues')
                    ->where('fieldid',$field->id)->where('relid',$clientId)->value('value');
                $debug['attempts'][] = ['source' => "custom_field:{$fieldName}", 'value' => $val];
                if ($val) {
                    $digits = preg_replace('/[^\d]/', '', (string)$val);
                    $cleanCC = ltrim($cc ?: Settings::countryCode(), '+');
                    if ($cleanCC && strlen($digits) <= 10) $digits = $cleanCC . $digits;
                    if ($digits && strlen($digits) >= 7 && strlen($digits) <= 15) {
                        return self::ok($digits, (string)$val, "custom_field:{$fieldName}", "Custom: {$fieldName}", $debug);
                    }
                }
            }
        } catch (\Throwable $e) {}
        return ['valid' => false];
    }

    private static function ok(string $phone, string $raw, string $source, string $label, array $debug, string $name = ''): array
    {
        return ['valid'=>true,'phone'=>$phone,'e164'=>'+'.$phone,'original'=>$raw,
                'country_code'=>'','error'=>null,'source'=>$source,
                'source_label'=>$label,'client_name'=>$name,'debug'=>$debug];
    }

    private static function fail(string $error, string $raw = '', string $source = ''): array
    {
        return ['valid'=>false,'phone'=>null,'e164'=>null,'original'=>$raw,
                'country_code'=>'','error'=>$error,'source'=>$source];
    }
}

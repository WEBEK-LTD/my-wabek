<?php
declare(strict_types=1);

namespace Wabek\Middleware;

class CsrfMiddleware
{
    private const TOKEN_KEY    = 'wabek_csrf_token';
    private const TOKEN_EXPIRY = 3600;

    public static function generateToken(): string
    {
        $token = bin2hex(random_bytes(32));
        $_SESSION[self::TOKEN_KEY]         = $token;
        $_SESSION[self::TOKEN_KEY . '_exp'] = time() + self::TOKEN_EXPIRY;
        return $token;
    }

    public static function getToken(): string
    {
        if (empty($_SESSION[self::TOKEN_KEY]) || self::isExpired()) {
            return self::generateToken();
        }
        return $_SESSION[self::TOKEN_KEY];
    }

    public static function verify(): bool
    {
        $token = $_POST['_wabek_csrf'] ?? $_SERVER['HTTP_X_WABEK_CSRF'] ?? '';
        if (!$token) return false;
        if (self::isExpired()) return false;

        $stored = $_SESSION[self::TOKEN_KEY] ?? '';
        return hash_equals($stored, $token);
    }

    private static function isExpired(): bool
    {
        $exp = $_SESSION[self::TOKEN_KEY . '_exp'] ?? 0;
        return time() > $exp;
    }

    public static function field(): string
    {
        return '<input type="hidden" name="_wabek_csrf" value="' . htmlspecialchars(self::getToken()) . '">';
    }
}

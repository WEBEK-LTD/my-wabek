<?php
declare(strict_types=1);

namespace Wabek\Database;

use WHMCS\Database\Capsule;

class Migrator
{
    private const CURRENT_VERSION = '3.2.0';

    /**
     * Called on fresh install (wabek_activate).
     * Creates ALL tables. Safe to re-run - every table method checks hasTable().
     */
    public static function run(): void
    {
        Schema::createAll();
        self::recordMigration('3.0.0', 'Initial enterprise install');
        self::recordMigration('3.1.0', 'Added: template_versions, campaign_events, abandoned_carts, statistics, activity_log, audit_log, optout');
        self::recordMigration('3.2.0', 'Added: conversations, incoming_messages, media, permission_map, client_settings');
    }

    /**
     * Called on upgrade - creates any tables that are missing.
     * Safe to call on existing installs.
     */
    public static function upgrade(): void
    {
        Schema::createAll();
        self::recordMigration(self::CURRENT_VERSION, 'Upgrade to ' . self::CURRENT_VERSION);
    }

    private static function recordMigration(string $version, string $desc): void
    {
        try {
            Capsule::table('mod_wabek_migrations')->updateOrInsert(
                ['version' => $version],
                ['description' => $desc, 'applied_at' => date('Y-m-d H:i:s')]
            );
        } catch (\Throwable $e) {}
    }
}

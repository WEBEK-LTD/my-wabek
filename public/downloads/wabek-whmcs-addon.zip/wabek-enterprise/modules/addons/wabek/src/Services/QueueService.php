<?php
declare(strict_types=1);

namespace Wabek\Services;

use WHMCS\Database\Capsule;

use Wabek\Config\Settings;
use Wabek\Models\QueueItem;
use Wabek\Models\Message;
use Wabek\Helpers\PhoneHelper;
use Wabek\Helpers\TemplateParser;

class QueueService
{
    public static function push(
        string $event,
        int    $clientId,
        string $phone,
        string $message,
        array  $data        = [],
        string $templateKey = '',
        int    $priority    = 5,
        ?string $scheduledAt = null
    ): int {
        return QueueItem::push([
            'event'        => $event,
            'client_id'    => $clientId,
            'phone'        => $phone,
            'message'      => $message,
            'template_key' => $templateKey,
            'data'         => json_encode($data),
            'priority'     => $priority,
            'max_attempts' => 3,
            'scheduled_at' => $scheduledAt ?? date('Y-m-d H:i:s'),
        ]);
    }

    public static function process(int $batchSize = 50): array
    {
        $items   = QueueItem::pendingBatch($batchSize);
        $wa      = new WhatsAppService();
        $delayMs = Settings::int('queue_delay_ms', 500);

        $stats = ['processed' => 0, 'sent' => 0, 'failed' => 0];

        foreach ($items as $item) {
            QueueItem::markProcessing($item->id);
            $stats['processed']++;

            // Validate phone before sending
            $phoneResult = \Wabek\Helpers\PhoneHelper::normalize($item->phone ?? '');
            if (!$phoneResult['valid']) {
                $errMsg = 'Phone validation failed: ' . $item->phone . ' -> ' . $phoneResult['error'];
                Message::create([
                    'queue_id'         => $item->id,
                    'client_id'        => $item->client_id,
                    'phone'            => $item->phone,
                    'event'            => $item->event,
                    'template_key'     => $item->template_key ?: null,
                    'content'          => $item->message,
                    'status'           => Message::STATUS_FAILED,
                    'error_msg'        => $errMsg,
                    'error_code'       => $phoneResult['error'],
                    'provider_response'=> json_encode([
                        'phone_original'  => $item->phone,
                        'phone_result'    => $phoneResult,
                        'validation_error'=> $phoneResult['error'],
                    ]),
                ]);
                QueueItem::markFailed($item->id, $errMsg);
                $stats['failed']++;
                continue;
            }

            $result = $wa->sendText($phoneResult['phone'], $item->message);

            // Determine template name - use actual slug, never 'none'
            $templateKey = !empty($item->template_key) ? $item->template_key : null;

            // Log to messages table with full phone + template info
            Message::create([
                'queue_id'         => $item->id,
                'client_id'        => $item->client_id,
                'phone'            => $phoneResult['phone'],    // normalised
                'event'            => $item->event,
                'template_key'     => $templateKey,
                'content'          => $item->message,
                'status'           => $result['success'] ? Message::STATUS_SENT : Message::STATUS_FAILED,
                'message_id'       => $result['messageId'] ?? null,
                'error_msg'        => $result['error'] ?? null,
                'error_code'       => $result['error_code'] ?? null,
                'sent_at'          => $result['success'] ? date('Y-m-d H:i:s') : null,
                'provider_response'=> json_encode(array_merge($result, [
                    'phone_original'   => $item->phone,
                    'phone_normalized' => $phoneResult['phone'],
                    'phone_e164'       => $phoneResult['e164'],
                    'country_code'     => $phoneResult['country_code'],
                    'template_used'    => $templateKey ?? '(none - plain text)',
                ])),
            ]);

            if ($result['success']) {
                QueueItem::markSent($item->id);
                $stats['sent']++;
            } else {
                QueueItem::markFailed($item->id, $result['error'] ?? 'Unknown error');
                $stats['failed']++;
            }

            // Rate limiting delay
            if ($delayMs > 0 && $stats['processed'] < count($items)) {
                usleep($delayMs * 1000);
            }
        }

        return $stats;
    }

    public static function pushOrSend(
        string $event,
        int    $clientId,
        string $phone,
        string $message,
        array  $data        = [],
        string $templateKey = ''
    ): bool {
        if (Settings::queueEnabled()) {
            self::push($event, $clientId, $phone, $message, $data, $templateKey);
            return true;
        }

        // Synchronous fallback
        $wa     = new WhatsAppService();
        $result = $wa->sendText($phone, $message);

        Message::create([
            'client_id'    => $clientId,
            'phone'        => $phone,
            'event'        => $event,
            'template_key' => $templateKey,
            'content'      => $message,
            'status'       => $result['success'] ? Message::STATUS_SENT : Message::STATUS_FAILED,
            'message_id'   => $result['messageId'] ?? null,
            'error_msg'    => $result['error'] ?? null,
            'sent_at'      => $result['success'] ? date('Y-m-d H:i:s') : null,
        ]);

        return $result['success'];
    }

    public static function cancel(int $queueId): void
    {
        \WHMCS\Database\Capsule::table('mod_wabek_queue')
            ->where('id', $queueId)
            ->where('status', 'pending')
            ->update(['status' => 'cancelled', 'updated_at' => date('Y-m-d H:i:s')]);
    }
}

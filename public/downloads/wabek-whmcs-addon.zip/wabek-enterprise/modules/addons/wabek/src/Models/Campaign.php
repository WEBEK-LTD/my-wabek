<?php
declare(strict_types=1);

namespace Wabek\Models;

use WHMCS\Database\Capsule;

class Campaign
{
    public const STATUS_DRAFT      = 'draft';
    public const STATUS_SCHEDULED  = 'scheduled';
    public const STATUS_RUNNING    = 'running';
    public const STATUS_PAUSED     = 'paused';
    public const STATUS_COMPLETED  = 'completed';
    public const STATUS_CANCELLED  = 'cancelled';

    public static function find(int $id): ?object
    {
        return Capsule::table('mod_wabek_campaigns')->where('id', $id)->first();
    }

    public static function all(int $page = 1, int $perPage = 20): array
    {
        $total = Capsule::table('mod_wabek_campaigns')->count();
        $items = Capsule::table('mod_wabek_campaigns')
            ->orderBy('created_at', 'desc')
            ->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get();

        return ['items' => $items, 'total' => $total, 'pages' => (int) ceil($total / $perPage)];
    }

    public static function create(array $data): int
    {
        return (int) Capsule::table('mod_wabek_campaigns')->insertGetId(array_merge([
            'status'     => self::STATUS_DRAFT,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ], $data));
    }

    public static function updateStatus(int $id, string $status): void
    {
        $extra = [];
        if ($status === self::STATUS_RUNNING)   $extra['started_at']   = date('Y-m-d H:i:s');
        if ($status === self::STATUS_COMPLETED) $extra['completed_at'] = date('Y-m-d H:i:s');

        Capsule::table('mod_wabek_campaigns')->where('id', $id)->update(
            array_merge(['status' => $status, 'updated_at' => date('Y-m-d H:i:s')], $extra)
        );
    }

    public static function incrementStat(int $id, string $field): void
    {
        Capsule::table('mod_wabek_campaigns')->where('id', $id)->increment($field);
    }

    public static function getRecipients(int $campaignId, string $status = ''): array
    {
        $q = Capsule::table('mod_wabek_campaign_recipients')->where('campaign_id', $campaignId);
        if ($status) $q->where('status', $status);
        return $q->get()->toArray();
    }

    public static function stats(int $id): object
    {
        return Capsule::table('mod_wabek_campaigns')->where('id', $id)->first() ?? (object)[];
    }
}

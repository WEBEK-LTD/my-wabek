<?php
declare(strict_types=1);

namespace Wabek\Services;

use WHMCS\Database\Capsule;

/**
 * WABEK Permission System
 * Controls which admin roles can access which features.
 * Defaults to allowing all permissions if no explicit mapping exists.
 */
class PermissionService
{
    public const PERMISSIONS = [
        'view_dashboard'    => 'View Dashboard',
        'view_logs'         => 'View Message Logs',
        'view_analytics'    => 'View Analytics',
        'manage_templates'  => 'Manage Templates',
        'manage_campaigns'  => 'Manage Campaigns',
        'manage_otp'        => 'Manage OTP',
        'manage_settings'   => 'Manage Settings',
        'manage_webhooks'   => 'Manage Webhooks',
        'manage_media'      => 'Manage Media Library',
        'send_messages'     => 'Send Messages',
        'view_inbox'        => 'View Inbox',
        'manage_clients'    => 'Edit Client WhatsApp Numbers',
    ];

    // Tab -> required permission
    public const TAB_PERMISSIONS = [
        'dashboard'   => 'view_dashboard',
        'messages'    => 'view_logs',
        'analytics'   => 'view_analytics',
        'templates'   => 'manage_templates',
        'campaigns'   => 'manage_campaigns',
        'otp'         => 'manage_otp',
        'settings'    => 'manage_settings',
        'webhooks'    => 'manage_webhooks',
        'media'       => 'manage_media',
        'send'        => 'send_messages',
        'inbox'       => 'view_inbox',
        'queue'       => 'view_logs',
        'diagnostics' => 'manage_settings',
    ];

    public static function adminCan(int $adminId, string $permission): bool
    {
        // Get admin role
        $roleId = (int)(Capsule::table('tbladmins')
            ->where('id', $adminId)->value('roleid') ?? 0);
        if (!$roleId) return true; // No role = super admin

        // Check if it\'s Full Administrator
        $roleName = Capsule::table('tbladminroles')
            ->where('id', $roleId)->value('rolename');
        if (strtolower((string)$roleName) === 'full administrator') return true;

        // Check explicit permission mapping
        $row = Capsule::table('mod_wabek_permission_map')
            ->where('role_id', $roleId)
            ->where('permission', $permission)
            ->first();

        // If no mapping = default allow
        if (!$row) return true;
        return (bool)$row->allowed;
    }

    public static function setRolePermission(int $roleId, string $permission, bool $allowed): void
    {
        Capsule::table('mod_wabek_permission_map')->updateOrInsert(
            ['role_id' => $roleId, 'permission' => $permission],
            ['allowed' => $allowed ? 1 : 0,
             'created_at' => date('Y-m-d H:i:s'),
             'updated_at' => date('Y-m-d H:i:s')]
        );
    }

    public static function getRolePermissions(int $roleId): array
    {
        $rows = Capsule::table('mod_wabek_permission_map')
            ->where('role_id', $roleId)
            ->pluck('allowed', 'permission')
            ->toArray();

        $result = [];
        foreach (self::PERMISSIONS as $key => $_) {
            $result[$key] = isset($rows[$key]) ? (bool)$rows[$key] : true;
        }
        return $result;
    }

    public static function getAllRoles(): object
    {
        return Capsule::table('tbladminroles')->orderBy('rolename')->get();
    }
}

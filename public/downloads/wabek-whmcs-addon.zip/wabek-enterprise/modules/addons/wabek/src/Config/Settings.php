<?php
declare(strict_types=1);

namespace Wabek\Config;

use WHMCS\Database\Capsule;

class Settings
{
    private static array $cache  = [];
    private static bool  $loaded = false;

    public static function init(): void
    {
        if (self::$loaded) return;
        self::load();
    }

    private static function load(): void
    {
        try {
            self::$cache = Capsule::table('tbladdonmodules')
                ->where('module', 'wabek')
                ->pluck('value', 'setting')
                ->toArray();
            self::$loaded = true;
        } catch (\Throwable $e) {
            self::$cache  = [];
            self::$loaded = true;
        }
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return self::$cache[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        Capsule::table('tbladdonmodules')->updateOrInsert(
            ['module' => 'wabek', 'setting' => $key],
            ['value'  => (string) $value]
        );
        self::$cache[$key] = (string) $value;
    }

    public static function bool(string $key, bool $default = false): bool
    {
        $val = self::get($key);
        if ($val === null) return $default;
        return in_array(strtolower((string) $val), ['on', 'yes', '1', 'true'], true);
    }

    public static function int(string $key, int $default = 0): int
    {
        return (int) (self::get($key, $default));
    }

    public static function apiKey(): string
    {
        return (string) self::get('api_key', '');
    }

    public static function instanceId(): string
    {
        return (string) self::get('instance_id', '');
    }

    public static function apiUrl(): string
    {
        return rtrim((string) self::get('api_url', 'https://waabek.com'), '/');
    }

    public static function countryCode(): string
    {
        return ltrim((string) self::get('default_country_code', '20'), '+');
    }

    public static function queueEnabled(): bool
    {
        return self::bool('queue_enabled', true);
    }

    public static function all(): array
    {
        return self::$cache;
    }

    public static function reload(): void
    {
        self::$loaded = false;
        self::$cache  = [];
        self::load();
    }

    // ── White Label ────────────────────────────────────────────────────────
    public static function whiteLabelEnabled(): bool
    {
        return self::bool('white_label_enabled', false);
    }

    public static function brandName(): string
    {
        if (self::whiteLabelEnabled()) {
            $name = self::get('white_label_company');
            if ($name) return (string) $name;
        }
        return 'WABEK WhatsApp';
    }

    public static function brandLogo(): string
    {
        if (self::whiteLabelEnabled()) {
            $logo = self::get('white_label_logo');
            if ($logo) return (string) $logo;
        }
        return '';
    }

    public static function brandFooter(): string
    {
        if (self::whiteLabelEnabled()) {
            return (string) self::get('white_label_footer', '');
        }
        return 'Powered by <a href="https://waabek.com" target="_blank">WABEK</a>';
    }

    // ── Queue Backoff ──────────────────────────────────────────────────────
    public static function retryDelays(): array
    {
        return [60, 300, 900, 1800]; // 1m, 5m, 15m, 30m
    }
}

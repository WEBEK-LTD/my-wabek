<?php
/**
 * WABEK WhatsApp - Enterprise WHMCS Addon
 * Version: 3.0.0
 * Author: WEBEK LTD
 * Website: https://waabek.com
 * License: Commercial
 *
 * PHP 8.1+ | WHMCS 8.10+
 */

declare(strict_types=1);

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

// ── Autoloader ─────────────────────────────────────────────────────────────
require_once __DIR__ . '/src/Bootstrap/Autoloader.php';
\Wabek\Bootstrap\Autoloader::register(__DIR__ . '/src');

use Wabek\Bootstrap\App;
use Wabek\Controllers\AdminController;
use Wabek\Controllers\SidebarController;
use WHMCS\Database\Capsule;

// ── Module Config ──────────────────────────────────────────────────────────
function wabek_config(): array
{
    return [
        'name'        => 'WABEK WhatsApp',
        'description' => 'Enterprise WhatsApp automation for WHMCS - Notifications, OTP, Campaigns & more.',
        'version'     => '3.0.0',
        'author'      => '<a href="https://waabek.com" target="_blank">WEBEK LTD</a>',
        'language'    => 'english',
        'fields'      => [
            'api_key' => [
                'FriendlyName' => 'WABEK API Key',
                'Type'         => 'password',
                'Size'         => 60,
                'Default'      => '',
                'Description'  => 'Get from <a href="https://waabek.com/dashboard/api-keys" target="_blank">Dashboard -> API Keys</a>',
            ],
            'instance_id' => [
                'FriendlyName' => 'WhatsApp Instance ID',
                'Type'         => 'text',
                'Size'         => 60,
                'Default'      => '',
                'Description'  => 'From Dashboard -> WhatsApp. Leave empty for default instance.',
            ],
            'api_url' => [
                'FriendlyName' => 'API Base URL',
                'Type'         => 'text',
                'Size'         => 60,
                'Default'      => 'https://waabek.com',
                'Description'  => 'WABEK API base URL (do not change unless using self-hosted)',
            ],
            'default_country_code' => [
                'FriendlyName' => 'Default Country Code',
                'Type'         => 'text',
                'Size'         => 10,
                'Default'      => '20',
                'Description'  => 'Without + sign. e.g. 20 Egypt, 44 UK, 90 Turkey, 966 Saudi',
            ],
            'phone_field' => [
                'FriendlyName' => 'Client Phone Field',
                'Type'         => 'dropdown',
                'Options'      => 'phonenumber,customfield',
                'Default'      => 'phonenumber',
                'Description'  => 'Which field holds the WhatsApp number',
            ],
            'phone_custom_field' => [
                'FriendlyName' => 'Custom Field Name',
                'Type'         => 'text',
                'Size'         => 40,
                'Default'      => 'WhatsApp',
                'Description'  => 'Only used if Phone Field above is set to customfield',
            ],
            'queue_enabled' => [
                'FriendlyName' => 'Enable Message Queue',
                'Type'         => 'yesno',
                'Default'      => 'yes',
                'Description'  => 'Recommended: queue messages and send via cron (prevents WHMCS slowdown)',
            ],
            'queue_batch_size' => [
                'FriendlyName' => 'Queue Batch Size',
                'Type'         => 'text',
                'Size'         => 5,
                'Default'      => '50',
                'Description'  => 'Messages to process per cron run',
            ],
            'queue_delay_ms' => [
                'FriendlyName' => 'Delay Between Messages (ms)',
                'Type'         => 'text',
                'Size'         => 8,
                'Default'      => '500',
                'Description'  => 'Milliseconds between each message send (rate limiting)',
            ],
            'otp_enabled' => [
                'FriendlyName' => 'Enable WhatsApp OTP',
                'Type'         => 'yesno',
                'Default'      => 'no',
                'Description'  => 'Allow clients to verify login/registration via WhatsApp OTP',
            ],
            'otp_expiry_minutes' => [
                'FriendlyName' => 'OTP Expiry (minutes)',
                'Type'         => 'text',
                'Size'         => 5,
                'Default'      => '10',
            ],
            'otp_max_attempts' => [
                'FriendlyName' => 'OTP Max Attempts',
                'Type'         => 'text',
                'Size'         => 5,
                'Default'      => '3',
            ],
            'otp_rate_limit' => [
                'FriendlyName' => 'OTP Rate Limit (per hour)',
                'Type'         => 'text',
                'Size'         => 5,
                'Default'      => '5',
                'Description'  => 'Max OTP requests per phone per hour',
            ],
            'log_retention_days' => [
                'FriendlyName' => 'Log Retention (days)',
                'Type'         => 'text',
                'Size'         => 5,
                'Default'      => '90',
                'Description'  => 'Auto-delete logs older than this many days (0 = keep forever)',
            ],
            'admin_notifications' => [
                'FriendlyName' => 'Admin Failure Notifications',
                'Type'         => 'yesno',
                'Default'      => 'yes',
                'Description'  => 'Notify admin on repeated send failures',
            ],
        ],
    ];
}

// ── Activate ───────────────────────────────────────────────────────────────
function wabek_activate(): array
{
    try {
        App::boot(__DIR__);

        // Run migrations (creates missing tables, safe on existing installs)
        \Wabek\Database\Migrator::run();

        // Seed default templates (skips existing slugs)
        \Wabek\Database\Seeder::seedDefaultTemplates();

        // Grant access to all existing admin roles
        _wabek_grant_all_roles_access();

        return ['status' => 'success', 'description' => 'WABEK WhatsApp activated/upgraded successfully. Go to Addons -> WABEK WhatsApp to get started.'];
    } catch (\Throwable $e) {
        return ['status' => 'error', 'description' => 'Activation failed: ' . $e->getMessage()];
    }
}

/**
 * Grant WABEK access to all admin roles on activate.
 * This prevents the "Access Denied" error on fresh installs.
 */
function _wabek_grant_all_roles_access(): void
{
    try {
        $roles = \WHMCS\Database\Capsule::table('tbladminroles')->get();

        foreach ($roles as $role) {
            $current = (string) ($role->addonmodules ?? '');

            // Already has access
            if (str_contains($current, 'wabek')) continue;

            $modules = array_filter(array_map('trim', explode(',', $current)));
            $modules[] = 'wabek';

            \WHMCS\Database\Capsule::table('tbladminroles')
                ->where('id', $role->id)
                ->update(['addonmodules' => implode(',', array_unique(array_filter($modules)))]);
        }

        // Also update tbladmins directly for WHMCS versions that store per-admin
        if (\WHMCS\Database\Capsule::schema()->hasColumn('tbladmins', 'permissions')) {
            $admins = \WHMCS\Database\Capsule::table('tbladmins')->get();
            foreach ($admins as $admin) {
                $perms = (string)($admin->permissions ?? '');
                if (!str_contains($perms, 'wabek')) {
                    $permArr = array_filter(array_map('trim', explode(',', $perms)));
                    $permArr[] = 'wabek';
                    \WHMCS\Database\Capsule::table('tbladmins')
                        ->where('id', $admin->id)
                        ->update(['permissions' => implode(',', array_unique(array_filter($permArr)))]);
                }
            }
        }

    } catch (\Throwable $e) {
        if (function_exists('logActivity')) {
            logActivity('WABEK: Could not auto-grant role access: ' . $e->getMessage());
        }
    }
}

// ── Deactivate ─────────────────────────────────────────────────────────────
function wabek_deactivate(): array
{
    return ['status' => 'success', 'description' => 'WABEK deactivated. Your data and logs have been preserved.'];
}

// ── Admin Output ───────────────────────────────────────────────────────────
function wabek_output(array $vars): void
{
    try {
        App::boot(__DIR__);
        (new AdminController($vars))->dispatch();
    } catch (\Throwable $e) {
        echo '<div class="alert alert-danger"><strong>WABEK Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}

// ── Sidebar ────────────────────────────────────────────────────────────────
function wabek_sidebar(array $vars): string
{
    try {
        App::boot(__DIR__);
        return (new SidebarController($vars))->render();
    } catch (\Throwable $e) {
        return '';
    }
}

// ── Client Area ────────────────────────────────────────────────────────────
function wabek_clientarea(array $vars): array
{
    try {
        App::boot(__DIR__);
        $result = (new \Wabek\Controllers\ClientController($vars))->dispatch();

        // WHMCS requires a valid templatefile in the return
        if (empty($result['templatefile'])) {
            $result['templatefile'] = '../../../modules/addons/wabek/templates/client/dashboard.tpl';
        }

        // Always provide pagetitle
        $result['pagetitle'] = 'WhatsApp';

        return $result;
    } catch (\Throwable $e) {
        return [
            'pagetitle'    => 'WhatsApp',
            'templatefile' => '../../../modules/addons/wabek/templates/client/dashboard.tpl',
            'vars'         => ['error' => $e->getMessage()],
        ];
    }
}

// ── Config Validate ────────────────────────────────────────────────────────
function wabek_config_validate(array $vars): ?string
{
    if (empty(trim($vars['api_key'] ?? ''))) {
        return 'API Key is required.';
    }
    return null;
}

// ── Access Control ─────────────────────────────────────────────────────────
// WHMCS 8.x / 9.x compatible - always allow any logged-in admin.
// Granular permissions are handled by wabek_config() 'access' field in WHMCS.
function wabek_access(array $vars): bool
{
    return !empty($vars['adminid']) && (int)$vars['adminid'] > 0;
}

// ── Client Area Navigation ──────────────────────────────────────────────────
// Adds "WhatsApp" to the primary nav in WHMCS client area
add_hook('ClientAreaPrimaryNavbar', 1, function ($primaryNavbar) {
    try {
        if (empty($_SESSION['uid'])) return;
        if (!function_exists('App\\Models\\Configuration') && !defined('WHMCS')) return;

        if (!\Wabek\Config\Settings::apiKey()) return;

        $menu = $primaryNavbar->addChild('wabek_whatsapp');
        if ($menu) {
            $menu->setLabel('WhatsApp');
            $menu->setUri('index.php?m=wabek');
            $menu->setOrder(70);
            $menu->setIcon('fa-whatsapp');

            // Sub-menu
            $menu->addChild('wa_dashboard', ['label' => 'Dashboard',      'uri' => 'index.php?m=wabek',                       'order' => 1]);
            $menu->addChild('wa_messages',  ['label' => 'Messages',       'uri' => 'index.php?m=wabek&action=messages',        'order' => 2]);
            $menu->addChild('wa_convs',     ['label' => 'Conversations',  'uri' => 'index.php?m=wabek&action=conversations',   'order' => 3]);
            $menu->addChild('wa_settings',  ['label' => 'Settings',       'uri' => 'index.php?m=wabek&action=settings',        'order' => 4]);
        }
    } catch (\Throwable $e) {}
});

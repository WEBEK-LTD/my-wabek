<?php
/**
 * WABEK Queue Processor - Run via WHMCS Cron or System Cron
 *
 * Add to WHMCS: Setup -> Automation Settings -> Custom Cron Jobs
 * Or system cron: * * * * * php /path/to/whmcs/modules/addons/wabek/cron/queue_processor.php >> /dev/null 2>&1
 */

declare(strict_types=1);

// Allow CLI and WHMCS cron execution
if (!defined('WHMCS') && php_sapi_name() !== 'cli') {
    die('Access denied');
}

$start = microtime(true);

// Bootstrap WHMCS if running from CLI
if (php_sapi_name() === 'cli') {
    $whmcsRoot = dirname(__DIR__, 5); // Adjust path if needed
    if (file_exists($whmcsRoot . '/init.php')) {
        require_once $whmcsRoot . '/init.php';
    } else {
        die("Could not find WHMCS init.php. Please run from WHMCS context.\n");
    }
}

$addonDir = dirname(__DIR__);
require_once $addonDir . '/src/Bootstrap/Autoloader.php';
\Wabek\Bootstrap\Autoloader::register($addonDir . '/src');

try {
    \Wabek\Bootstrap\App::boot($addonDir);

    $batchSize = \Wabek\Config\Settings::int('queue_batch_size', 50);
    $stats     = \Wabek\Services\QueueService::process($batchSize);

    $elapsed = round((microtime(true) - $start) * 1000);
    $msg = sprintf(
        '[WABEK Queue] Processed: %d | Sent: %d | Failed: %d | Time: %dms',
        $stats['processed'], $stats['sent'], $stats['failed'], $elapsed
    );

    if (function_exists('logActivity')) {
        logActivity($msg);
    }

    if (php_sapi_name() === 'cli') {
        echo $msg . PHP_EOL;
    }

    // ── Process scheduled campaigns ──────────────────────────────────
    $scheduledCampaigns = \WHMCS\Database\Capsule::table('mod_wabek_campaigns')
        ->where('status', 'scheduled')
        ->where('scheduled_at', '<=', date('Y-m-d H:i:s'))
        ->get();

    foreach ($scheduledCampaigns as $camp) {
        \Wabek\Models\Campaign::updateStatus((int)$camp->id, \Wabek\Models\Campaign::STATUS_RUNNING);
        $batchResult = \Wabek\Services\CampaignService::processBatch((int)$camp->id, 20);
        if (function_exists('logActivity')) {
            logActivity("[WABEK Cron] Campaign #{$camp->id} "{$camp->name}": processed {$batchResult['processed']}");
        }
    }

    // ── Continue running campaigns ─────────────────────────────────
    $runningCampaigns = \WHMCS\Database\Capsule::table('mod_wabek_campaigns')
        ->where('status', \Wabek\Models\Campaign::STATUS_RUNNING)
        ->get();

    foreach ($runningCampaigns as $camp) {
        $batchResult = \Wabek\Services\CampaignService::processBatch((int)$camp->id, 20);
    }

    // ── Daily Statistics Aggregation ──────────────────────────────────
    // Aggregate yesterday's stats into mod_wabek_statistics for fast reporting
    try {
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $exists    = \WHMCS\Database\Capsule::table('mod_wabek_statistics')
            ->where('date', $yesterday)
            ->whereNull('event')
            ->exists();

        if (!$exists) {
            // Aggregate by event for yesterday
            $rows = \WHMCS\Database\Capsule::table('mod_wabek_messages')
                ->select(
                    \WHMCS\Database\Capsule::raw('DATE(created_at) as stat_date'),
                    'event',
                    \WHMCS\Database\Capsule::raw('COUNT(*) as sent'),
                    \WHMCS\Database\Capsule::raw('SUM(status="delivered") as delivered'),
                    \WHMCS\Database\Capsule::raw('SUM(status="read") as `read`'),
                    \WHMCS\Database\Capsule::raw('SUM(status="failed") as failed')
                )
                ->whereDate('created_at', $yesterday)
                ->groupBy('stat_date', 'event')
                ->get();

            foreach ($rows as $row) {
                \WHMCS\Database\Capsule::table('mod_wabek_statistics')->updateOrInsert(
                    ['date' => $yesterday, 'event' => $row->event, 'country' => null],
                    [
                        'sent'      => (int)$row->sent,
                        'delivered' => (int)$row->delivered,
                        'read'      => (int)$row->read,
                        'failed'    => (int)$row->failed,
                    ]
                );
            }
        }
    } catch (\Throwable $e) {}

    // ── Webhook Auto-Retry ─────────────────────────────────────────────
    // Retry failed webhook deliveries (status updates that didn't match a message)
    try {
        if (\WHMCS\Database\Capsule::schema()->hasTable('mod_wabek_webhooks')) {
            // Find webhooks with error that haven't been retried in last hour
            $failedWebhooks = \WHMCS\Database\Capsule::table('mod_wabek_webhooks')
                ->whereNotNull('error_code')
                ->whereNotNull('message_id')
                ->where('created_at', '>=', date('Y-m-d H:i:s', strtotime('-24 hours')))
                ->where('updated_at', '<=', date('Y-m-d H:i:s', strtotime('-60 minutes')))
                ->limit(20)
                ->get();

            foreach ($failedWebhooks as $wh) {
                // Re-attempt status update
                $msgId  = $wh->message_id ?? '';
                $status = $wh->status ?? 'failed';
                if ($msgId && $status) {
                    \Wabek\Models\Message::updateStatus($msgId, $status, [
                        'error_code' => $wh->error_code,
                        'error_msg'  => $wh->error_msg,
                    ]);
                    // Mark as retried
                    \WHMCS\Database\Capsule::table('mod_wabek_webhooks')
                        ->where('id', $wh->id)
                        ->update(['updated_at' => date('Y-m-d H:i:s')]);
                }
            }
        }
    } catch (\Throwable $e) {}

    // ── Process Abandoned Cart reminders ─────────────────────────────
    try {
        $cartStats = \Wabek\Services\AbandonedCartService::processReminders();
        if ($cartStats['sent'] > 0 && function_exists('logActivity')) {
            logActivity("[WABEK Cron] Abandoned cart: sent={$cartStats['sent']} processed={$cartStats['processed']}");
        }
    } catch (\Throwable $e) {
        if (function_exists('logActivity')) logActivity('[WABEK Cron] AbandonedCart error: ' . $e->getMessage());
    }

    // Clean old logs if configured
    $retentionDays = \Wabek\Config\Settings::int('log_retention_days', 90);
    if ($retentionDays > 0) {
        \WHMCS\Database\Capsule::table('mod_wabek_messages')
            ->where('created_at', '<', date('Y-m-d H:i:s', strtotime("-{$retentionDays} days")))
            ->delete();

        \WHMCS\Database\Capsule::table('mod_wabek_queue')
            ->whereIn('status', ['sent', 'cancelled'])
            ->where('updated_at', '<', date('Y-m-d H:i:s', strtotime('-7 days')))
            ->delete();
    }

} catch (\Throwable $e) {
    $msg = '[WABEK Queue Error] ' . $e->getMessage();
    if (function_exists('logActivity')) logActivity($msg);
    if (php_sapi_name() === 'cli') echo $msg . PHP_EOL;
}

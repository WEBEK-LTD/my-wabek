<?php
/**
 * WABEK WhatsApp - WHMCS Hooks Entry Point
 * This file registers all WHMCS event hooks for WABEK.
 */

declare(strict_types=1);

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

// Bootstrap
$addonDir = dirname(__DIR__, 2) . '/modules/addons/wabek';

if (!file_exists($addonDir . '/wabek.php')) return;
if (!file_exists($addonDir . '/src/Bootstrap/Autoloader.php')) return;

// Only load if module is active
try {
    $isActive = \WHMCS\Database\Capsule::table('tbladdonmodules')
        ->where('module', 'wabek')
        ->where('setting', 'api_key')
        ->whereNotNull('value')
        ->where('value', '!=', '')
        ->exists();

    if (!$isActive) return;
} catch (\Throwable $e) {
    return;
}

require_once $addonDir . '/src/Bootstrap/Autoloader.php';
\Wabek\Bootstrap\Autoloader::register($addonDir . '/src');

try {
    \Wabek\Bootstrap\App::boot($addonDir);
    \Wabek\Hooks\EventHandler::register();
    // ── Admin Client Profile Widget ──────────────────────────────────────
    add_hook('AdminClientSummaryPage', 1, function (array $vars): string {
        $clientId = (int)($vars['userid'] ?? 0);
        if (!$clientId) return '';

        try {
            \Wabek\Bootstrap\App::boot($addonDir);
            return \Wabek\Hooks\ClientProfileHook::render($clientId, $vars);
        } catch (\Throwable $e) {
            return '';
        }
    });

    // ── Client Area Header Icon ───────────────────────────────────────────
    add_hook('ClientAreaHeadOutput', 1, function (array $vars): string {
        try {
            if (!\Wabek\Config\Settings::apiKey()) return '';
            $clientId = (int)($_SESSION['uid'] ?? 0);
            if (!$clientId) return '';
            $moduleLink = $vars['modulelink'] ?? 'index.php?m=wabek';
            return '<style>
                .wabek-wa-btn{display:inline-flex;align-items:center;gap:6px;background:#25D366;color:#fff;border-radius:20px;padding:4px 12px;font-size:12px;font-weight:600;text-decoration:none;transition:all .2s}
                .wabek-wa-btn:hover{background:#1da851;color:#fff;text-decoration:none}
                .wabek-wa-btn svg{width:14px;height:14px;fill:#fff}
            </style>';
        } catch (\Throwable $e) { return ''; }
    });

    add_hook('ClientAreaHeaderOutput', 1, function (array $vars): string {
        try {
            if (!\Wabek\Config\Settings::apiKey()) return '';
            $clientId = (int)($_SESSION['uid'] ?? 0);
            if (!$clientId) return '';
            $unread = (int)\WHMCS\Database\Capsule::table('mod_wabek_incoming_messages')
                ->where('client_id', $clientId)
                ->where('is_read', false)
                ->count();

            $badgeHtml = $unread > 0
                ? '<span style="background:#DC2626;color:#fff;font-size:9px;border-radius:99px;padding:0 4px;margin-left:2px">' . $unread . '</span>'
                : '';

            return '<a href="index.php?m=wabek" class="wabek-wa-btn" title="WhatsApp">'
                . '<svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M11.963 0C5.358 0 0 5.358 0 11.963c0 2.08.535 4.03 1.476 5.726L0 24l6.484-1.451c1.64.896 3.507 1.414 5.479 1.414C18.568 23.963 24 18.605 24 12S18.568 0 11.963 0zm0 21.927a9.93 9.93 0 01-5.062-1.382l-.363-.215-3.756.841.855-3.65-.236-.375a9.897 9.897 0 01-1.518-5.183c0-5.476 4.451-9.927 9.927-9.927 5.476 0 9.927 4.451 9.927 9.927s-4.451 9.927-9.927 9.927h.153z"/></svg>'
                . 'WhatsApp' . $badgeHtml
                . '</a>';
        } catch (\Throwable $e) { return ''; }
    });


    // Register webhook handler for WABEK delivery receipts
    // WABEK sends POST to: /includes/hooks/wabek_notifications.php?wabek_webhook=1
    // ── One-click unsubscribe ─────────────────────────────────────────
    if (isset($_GET['wabek_unsub']) && !empty($_GET['wabek_unsub'])) {
        $token = preg_replace('/[^a-f0-9]/', '', (string)$_GET['wabek_unsub']);
        if ($token) {
            try {
                $settings = \Wabek\Models\ClientSettings::findByToken($token);
                if ($settings) {
                    \Wabek\Models\ClientSettings::setOptOut((int)$settings->client_id, true);
                    $sysUrl = \WHMCS\Config\Setting::getValue('SystemURL') ?? '/';
                    header('Content-Type: text/html; charset=utf-8');
                    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Unsubscribed</title>
                    <style>body{font-family:sans-serif;text-align:center;padding:60px;color:#475569}
                    h2{color:#16A34A}a{color:#2563EB}</style></head><body>
                    <h2>&#10003; Unsubscribed</h2>
                    <p>You have been unsubscribed from WhatsApp notifications.</p>
                    <p><a href="' . htmlspecialchars($sysUrl) . '">Return to portal</a></p>
                    </body></html>';
                } else {
                    echo '<p style="font-family:sans-serif;text-align:center;padding:40px">Invalid or expired link.</p>';
                }
            } catch (\Throwable $e) {
                echo '<p style="font-family:sans-serif;text-align:center;padding:40px">Error processing request.</p>';
            }
        }
        exit;
    }

    if (isset($_GET['wabek_webhook']) && $_REQUEST['wabek_webhook'] === '1') {
        $payload = file_get_contents('php://input');

        // ── Webhook signature verification (HMAC-SHA256) ─────────────
        $secret    = \Wabek\Config\Settings::get('webhook_secret', '');
        $sigHeader = $_SERVER['HTTP_X_WABEK_SIGNATURE']
                  ?? $_SERVER['HTTP_X_SIGNATURE']
                  ?? $_SERVER['HTTP_X_HUB_SIGNATURE_256']
                  ?? '';

        if ($secret && $sigHeader) {
            $expected = 'sha256=' . hash_hmac('sha256', $payload, $secret);
            if (!hash_equals($expected, $sigHeader)) {
                http_response_code(401);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Invalid webhook signature']);
                exit;
            }
        }

        // Log raw receipt
        try {
            \WHMCS\Database\Capsule::table('mod_wabek_activity_log')->insert([
                'action'     => 'webhook_received',
                'data'       => json_encode([
                    'size'      => strlen($payload),
                    'signed'    => !empty($sigHeader),
                    'ip'        => $_SERVER['REMOTE_ADDR'] ?? '',
                ]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {}
        $data    = json_decode($payload, true);

        if ($data) {
            try {
                // ── Normalise payload fields ──────────────────────────────
                $whEvent    = (string)($data['event']      ?? $data['type']       ?? 'unknown');
                $whMsgId    = (string)($data['messageId']  ?? $data['id']         ?? $data['message_id'] ?? '');
                $whPhone    = (string)($data['phone']      ?? $data['from']       ?? $data['to']   ?? '');
                $whStatus   = (string)($data['status']     ?? '');
                $whErrCode  = isset($data['error_code'])   ? (int)$data['error_code']   : null;
                // Never log 'undefined' - use null
                $rawErr     = $data['error'] ?? $data['error_message'] ?? null;
                $whErrMsg   = ($rawErr && $rawErr !== 'undefined') ? (string)$rawErr : null;
                $whInstId   = (string)($data['instance_id'] ?? $data['instanceId'] ?? '');

                // ── Log webhook ───────────────────────────────────────────
                \WHMCS\Database\Capsule::table('mod_wabek_webhooks')->insert([
                    'event_type' => $whEvent,
                    'message_id' => $whMsgId  ?: null,
                    'phone'      => $whPhone  ?: null,
                    'status'     => $whStatus ?: null,
                    'error_code' => $whErrCode,
                    'error_msg'  => $whErrMsg,
                    'payload'    => $payload,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);

                // ── Update message status ─────────────────────────────────
                $evtLower = strtolower($whEvent);
                if (in_array($evtLower, ['message.delivered','message.read','message.sent','message.failed',
                                          'delivered','read','sent','failed'])) {
                    $msgStatus = match(true) {
                        str_contains($evtLower, 'delivered') => 'delivered',
                        str_contains($evtLower, 'read')      => 'read',
                        str_contains($evtLower, 'failed')    => 'failed',
                        str_contains($evtLower, 'sent')      => 'sent',
                        default                              => $whStatus ?: 'sent',
                    };

                    if ($whMsgId) {
                        \Wabek\Models\Message::updateStatus($whMsgId, $msgStatus, [
                            'error_code' => $whErrCode,
                            'error_msg'  => $whErrMsg,
                        ]);

                        \WHMCS\Database\Capsule::table('mod_wabek_campaign_recipients')
                            ->where('message_id', $whMsgId)
                            ->update(['status' => $msgStatus, 'updated_at' => date('Y-m-d H:i:s')]);
                    }
                }

                // ── Validate instance before processing incoming ──────────
                $instanceValid   = false;
                $instanceLookup  = null;
                if ($whInstId) {
                    $instanceLookup = \WHMCS\Database\Capsule::table('mod_wabek_conversations')
                        ->where('instance_id', $whInstId)->first();
                    $instanceValid = true; // Instance ID from webhook = authoritative
                    // Log the lookup for debugging
                    \WHMCS\Database\Capsule::table('mod_wabek_activity_log')->insert([
                        'action'     => 'webhook_instance_lookup',
                        'data'       => json_encode([
                            'instance_id'      => $whInstId,
                            'found_in_convs'   => $instanceLookup ? 'yes' : 'no (first webhook from this instance)',
                            'lookup_method'    => 'mod_wabek_conversations.instance_id',
                        ]),
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s'),
                    ]);
                }

                // Handle incoming messages
                if ($event === 'message.incoming' || $event === 'message.received') {
                    $phone      = $data['from']   ?? $data['phone'] ?? null;
                    $instanceId = $data['instance_id'] ?? null;
                    $content    = $data['message'] ?? $data['text'] ?? $data['body'] ?? null;
                    $msgType    = $data['type']    ?? 'text';
                    $waId       = $data['messageId'] ?? $data['id'] ?? null;

                    if ($phone && $content) {
                        // Find or create conversation
                        $existing = \WHMCS\Database\Capsule::table('mod_wabek_conversations')
                            ->where('phone', $phone)
                            ->where('instance_id', $instanceId)
                            ->first();

                        if ($existing) {
                            $convId = $existing->id;
                            \WHMCS\Database\Capsule::table('mod_wabek_conversations')
                                ->where('id', $convId)
                                ->update([
                                    'last_message'    => substr($content, 0, 200),
                                    'last_message_at' => date('Y-m-d H:i:s'),
                                    'unread_count'    => $existing->unread_count + 1,
                                    'status'          => 'open',
                                    'updated_at'      => date('Y-m-d H:i:s'),
                                ]);
                        } else {
                            // Find client by phone
                            $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
                            $client     = \WHMCS\Database\Capsule::table('tblclients')
                                ->where('phonenumber', 'like', '%' . substr($cleanPhone, -8) . '%')
                                ->first();

                            $convId = \WHMCS\Database\Capsule::table('mod_wabek_conversations')->insertGetId([
                                'client_id'       => $client->id ?? null,
                                'phone'           => $phone,
                                'client_name'     => $client ? trim(($client->firstname??'').(' '.($client->lastname??''))) : null,
                                'instance_id'     => $instanceId,
                                'status'          => 'open',
                                'unread_count'    => 1,
                                'last_message'    => substr($content, 0, 200),
                                'last_message_at' => date('Y-m-d H:i:s'),
                                'created_at'      => date('Y-m-d H:i:s'),
                                'updated_at'      => date('Y-m-d H:i:s'),
                            ]);
                        }

                        // Store incoming message
                        \WHMCS\Database\Capsule::table('mod_wabek_incoming_messages')->insert([
                            'conversation_id' => $convId,
                            'client_id'       => null,
                            'phone'           => $phone,
                            'instance_id'     => $instanceId,
                            'wa_message_id'   => $waId,
                            'direction'       => 'inbound',
                            'message_type'    => in_array($msgType, ['text','image','document','audio','video']) ? $msgType : 'text',
                            'content'         => $content,
                            'media_url'       => $data['media_url'] ?? null,
                            'is_read'         => false,
                            'received_at'     => date('Y-m-d H:i:s'),
                            'created_at'      => date('Y-m-d H:i:s'),
                            'updated_at'      => date('Y-m-d H:i:s'),
                        ]);
                    }
                }

                header('Content-Type: application/json');
                echo json_encode(['success' => true]);
                exit;

            } catch (\Throwable $e) {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(['error' => $e->getMessage()]);
                exit;
            }
        }

        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Invalid payload']);
        exit;
    }

} catch (\Throwable $e) {
    // Never crash WHMCS
    if (function_exists('logActivity')) {
        logActivity('WABEK Bootstrap Error: ' . $e->getMessage());
    }
}

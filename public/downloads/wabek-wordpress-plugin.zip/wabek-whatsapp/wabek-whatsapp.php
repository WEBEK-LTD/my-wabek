<?php
/**
 * Plugin Name: WABEK WhatsApp Notifications
 * Plugin URI: https://waabek.com
 * Description: Send WhatsApp notifications for WooCommerce orders, Tutor LMS enrollments, and customer events.
 * Version: 2.1.0
 * Author: WABEK
 * Author URI: https://waabek.com
 * License: GPL v2 or later
 * Text Domain: wabek-whatsapp
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 10.7.0
 */

if (!defined('ABSPATH')) exit;

// ── WooCommerce HPOS + Blocks compatibility ───────────────────────────────────
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

define('WABEK_VERSION',    '2.1.0');
define('WABEK_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WABEK_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WABEK_OPTION_KEY', 'wabek_settings');

add_action('plugins_loaded', function () {
    // WooCommerce check
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>WABEK WhatsApp:</strong> WooCommerce is required.</p></div>';
        });
        return;
    }
    require_once WABEK_PLUGIN_DIR . 'includes/class-wabek.php';
    WABEK::init();
});

register_activation_hook(__FILE__, function () {
    add_option(WABEK_OPTION_KEY, [
        'api_key'                    => '',
        'api_url'                    => 'https://waabek.com/api/v1/send',
        'instance_id'                => '',
        'phone_field'                => 'billing_phone',
        'default_country_code'       => '',
        // WooCommerce
        'enable_order_new'           => '1',
        'enable_order_processing'    => '1',
        'enable_order_completed'     => '1',
        'enable_order_cancelled'     => '1',
        'enable_order_refunded'      => '1',
        'enable_abandoned_cart'      => '0',
        'abandoned_cart_delay'       => '60',
        // Tutor LMS
        'enable_tutor_enrolled'      => '1',
        'enable_tutor_completed'     => '1',
        'enable_tutor_certificate'   => '1',
        'enable_tutor_lesson'        => '0',
        'enable_tutor_quiz_passed'   => '1',
        'enable_tutor_quiz_failed'   => '0',
        // Chat widget
        'enable_chat_widget'         => '0',
        'chat_widget_phone'          => '',
        'chat_widget_message'        => 'Hello! I need help.',
        'chat_widget_color'          => '#25D366',
        'chat_widget_position'       => 'right',
    ]);
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('wabek_abandoned_cart_check');
});

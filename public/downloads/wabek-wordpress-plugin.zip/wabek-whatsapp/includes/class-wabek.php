<?php
if (!defined('ABSPATH')) exit;

class WABEK {

    public static function init(): void {
        // Admin
        add_action('admin_menu',    [__CLASS__, 'admin_menu']);
        add_action('admin_init',    [__CLASS__, 'admin_init']);
        add_action('admin_notices', [__CLASS__, 'admin_notices']);

        // ── WooCommerce hooks ─────────────────────────────────────────────────
        add_action('woocommerce_new_order',               [__CLASS__, 'on_new_order'],        10, 1);
        add_action('woocommerce_order_status_processing', [__CLASS__, 'on_order_processing'], 10, 2);
        add_action('woocommerce_order_status_completed',  [__CLASS__, 'on_order_completed'],  10, 2);
        add_action('woocommerce_order_status_cancelled',  [__CLASS__, 'on_order_cancelled'],  10, 2);
        add_action('woocommerce_order_status_refunded',   [__CLASS__, 'on_order_refunded'],   10, 2);
        add_action('woocommerce_order_status_on-hold',    [__CLASS__, 'on_order_on_hold'],    10, 2);

        // ── Tutor LMS hooks ───────────────────────────────────────────────────
        // Course enrollment
        add_action('tutor_after_enrolled',               [__CLASS__, 'on_tutor_enrolled'],    10, 3);
        // Course completed
        add_action('tutor_course_complete_after',        [__CLASS__, 'on_tutor_completed'],   10, 2);
        // Certificate generated
        add_action('tutor_certificate_generated',        [__CLASS__, 'on_tutor_certificate'], 10, 2);
        // Lesson completed
        add_action('tutor_lesson_completed_after',       [__CLASS__, 'on_tutor_lesson'],      10, 2);
        // Quiz passed
        add_action('tutor_quiz_attempt_ended',           [__CLASS__, 'on_tutor_quiz'],        10, 1);
        // Announcements
        add_action('save_post_tutor_announcements',      [__CLASS__, 'on_tutor_announcement'], 10, 3);

        // ── Abandoned cart ────────────────────────────────────────────────────
        $s = self::settings();
        if ($s['enable_abandoned_cart'] === '1') {
            add_action('woocommerce_add_to_cart',  [__CLASS__, 'track_cart']);
            add_action('woocommerce_cart_emptied', [__CLASS__, 'clear_cart_track']);
            add_action('woocommerce_thankyou',     [__CLASS__, 'clear_cart_track']);
            if (!wp_next_scheduled('wabek_abandoned_cart_check')) {
                wp_schedule_event(time(), 'hourly', 'wabek_abandoned_cart_check');
            }
            add_action('wabek_abandoned_cart_check', [__CLASS__, 'check_abandoned_carts']);
        }

        // ── Chat widget ───────────────────────────────────────────────────────
        if ($s['enable_chat_widget'] === '1' && $s['chat_widget_phone']) {
            add_action('wp_footer', [__CLASS__, 'chat_widget']);
        }
    }

    // ── Settings ──────────────────────────────────────────────────────────────
    public static function settings(): array {
        return wp_parse_args(get_option(WABEK_OPTION_KEY, []), [
            'api_key'                  => '',
            'api_url'                  => 'https://waabek.com/api/v1/send',
            'instance_id'              => '',
            'phone_field'              => 'billing_phone',
            'default_country_code'     => '',
            'enable_order_new'         => '1',
            'enable_order_processing'  => '1',
            'enable_order_completed'   => '1',
            'enable_order_cancelled'   => '1',
            'enable_order_refunded'    => '1',
            'enable_abandoned_cart'    => '0',
            'abandoned_cart_delay'     => '60',
            'enable_tutor_enrolled'    => '1',
            'enable_tutor_completed'   => '1',
            'enable_tutor_certificate' => '1',
            'enable_tutor_lesson'      => '0',
            'enable_tutor_quiz_passed' => '1',
            'enable_tutor_quiz_failed'     => '0',
            'enable_tutor_announcement'   => '1',
            'enable_chat_widget'       => '0',
            'chat_widget_phone'        => '',
            'chat_widget_message'      => 'Hello! I need help.',
            'chat_widget_color'        => '#25D366',
            'chat_widget_position'     => 'right',
            // WooCommerce templates
            'tpl_order_new'        => "🛒 New Order #{{order_id}}\n\nHi {{first_name}}, we received your order!\n💰 Total: {{total}}\n📦 Items: {{items}}\n\nWe'll notify you when it ships.",
            'tpl_order_processing' => "⚙️ Order #{{order_id}} Processing\n\nHi {{first_name}}, your order is being prepared!\n💰 Total: {{total}}\n📅 Estimated: {{estimated_delivery}}",
            'tpl_order_completed'  => "✅ Order #{{order_id}} Delivered!\n\nHi {{first_name}}, your order has been delivered.\nThank you for shopping with us! 🙏",
            'tpl_order_cancelled'  => "❌ Order #{{order_id}} Cancelled\n\nHi {{first_name}}, your order has been cancelled.\nContact us if you have questions.",
            'tpl_order_refunded'   => "💸 Order #{{order_id}} Refunded\n\nHi {{first_name}}, your refund of {{total}} has been processed.\nIt may take 3-5 business days.",
            'tpl_order_on_hold'    => "⏸ Order #{{order_id}} On Hold\n\nHi {{first_name}}, your order is pending payment confirmation.\nContact us if you need help.",
            'tpl_abandoned_cart'   => "🛒 You left something behind!\n\nHi {{first_name}}, items in your cart:\n{{items}}\n\nComplete your order: {{cart_url}}",
            // Tutor LMS templates
            'tpl_tutor_enrolled'    => "🎓 Enrollment Confirmed!\n\nHi {{first_name}}, you're now enrolled in:\n📚 {{course_name}}\n\nStart learning: {{course_url}}",
            'tpl_tutor_completed'   => "🏆 Course Completed!\n\nCongratulations {{first_name}}! You've completed:\n📚 {{course_name}}\n\nExcellent work! 🎉",
            'tpl_tutor_certificate' => "📜 Certificate Ready!\n\nHi {{first_name}}, your certificate for:\n📚 {{course_name}}\nis now available.\n\nDownload: {{certificate_url}}",
            'tpl_tutor_lesson'      => "📖 Lesson Completed!\n\nGreat job {{first_name}}!\nYou completed: {{lesson_name}}\nCourse: {{course_name}}\n\nKeep it up! 💪",
            'tpl_tutor_quiz_passed' => "✅ Quiz Passed!\n\nCongratulations {{first_name}}!\nQuiz: {{quiz_name}}\nScore: {{score}}%\n\nWell done! 🎉",
            'tpl_tutor_quiz_failed'     => "📝 Quiz Result\n\nHi {{first_name}},\nQuiz: {{quiz_name}}\nScore: {{score}}%\n\nDon't give up — you can retake it! 💪",
            'tpl_tutor_announcement' => "📢 New Announcement\n\nHi {{first_name}},\n{{course_name}} has a new announcement:\n\n📌 {{title}}\n\n{{content}}",
        ]);
    }

    // ── Send ──────────────────────────────────────────────────────────────────
    public static function send(string $phone, string $message, string $customer_name = ''): bool {
        $s      = self::settings();
        $apiKey = trim($s['api_key']);
        $apiUrl = trim($s['api_url'] ?: 'https://waabek.com/api/v1/send');
        $instId = trim($s['instance_id']);

        if (!$apiKey || !$phone || !$message) return false;

        $p = preg_replace('/[^\\d]/', '', $phone);
        $cc = trim($s['default_country_code']);
        if ($cc && strlen($p) <= 10) $p = ltrim($cc, '0+') . $p;
        if (!$p) return false;

        $body = ['to' => $p, 'message' => $message];
        if ($instId) $body['instance_id'] = $instId;
        // Outside the 24h window, the API auto-falls-back to a Marketing
        // template using {{customer_name}} when the message isn't a code.
        if ($customer_name) $body['customer_name'] = $customer_name;

        $response = wp_remote_post($apiUrl, [
            'timeout' => 15,
            'headers' => ['X-API-Key' => $apiKey, 'Content-Type' => 'application/json'],
            'body'    => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) return false;
        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return $code === 200 && ($data['success'] ?? false);
    }

    public static function parse(string $tpl, array $vars): string {
        foreach ($vars as $k => $v) {
            $tpl = str_replace('{{' . $k . '}}', (string)$v, $tpl);
        }
        return $tpl;
    }

    // ── WooCommerce helpers ───────────────────────────────────────────────────
    private static function order_phone(\WC_Order $order): string {
        $s = self::settings();
        return $order->get_meta($s['phone_field']) ?: $order->get_billing_phone() ?: '';
    }

    private static function order_vars(\WC_Order $order): array {
        $items = [];
        foreach ($order->get_items() as $item) {
            $items[] = $item->get_name() . ' x' . $item->get_quantity();
        }
        return [
            'order_id'           => $order->get_order_number(),
            'first_name'         => $order->get_billing_first_name(),
            'last_name'          => $order->get_billing_last_name(),
            'total'              => $order->get_formatted_order_total(),
            'items'              => implode(', ', $items),
            'status'             => wc_get_order_status_name($order->get_status()),
            'order_url'          => $order->get_view_order_url(),
            'estimated_delivery' => date('M j, Y', strtotime('+3 days')),
            'shop_name'          => get_bloginfo('name'),
        ];
    }

    // ── WooCommerce order hooks ───────────────────────────────────────────────
    public static function on_new_order(int $id): void {
        $s = self::settings(); if ($s['enable_order_new'] !== '1') return;
        $o = wc_get_order($id); if (!$o) return;
        $p = self::order_phone($o); if (!$p) return;
        self::send($p, self::parse($s['tpl_order_new'], self::order_vars($o)));
    }

    public static function on_order_processing(int $id, \WC_Order $o): void {
        $s = self::settings(); if ($s['enable_order_processing'] !== '1') return;
        $p = self::order_phone($o); if (!$p) return;
        self::send($p, self::parse($s['tpl_order_processing'], self::order_vars($o)));
    }

    public static function on_order_completed(int $id, \WC_Order $o): void {
        $s = self::settings(); if ($s['enable_order_completed'] !== '1') return;
        $p = self::order_phone($o); if (!$p) return;
        self::send($p, self::parse($s['tpl_order_completed'], self::order_vars($o)));
    }

    public static function on_order_cancelled(int $id, \WC_Order $o): void {
        $s = self::settings(); if ($s['enable_order_cancelled'] !== '1') return;
        $p = self::order_phone($o); if (!$p) return;
        self::send($p, self::parse($s['tpl_order_cancelled'], self::order_vars($o)));
    }

    public static function on_order_refunded(int $id, \WC_Order $o): void {
        $s = self::settings(); if ($s['enable_order_refunded'] !== '1') return;
        $p = self::order_phone($o); if (!$p) return;
        self::send($p, self::parse($s['tpl_order_refunded'], self::order_vars($o)));
    }

    public static function on_order_on_hold(int $id, \WC_Order $o): void {
        $p = self::order_phone($o); if (!$p) return;
        $s = self::settings();
        self::send($p, self::parse($s['tpl_order_on_hold'], self::order_vars($o)));
    }

    // ── Tutor LMS hooks ───────────────────────────────────────────────────────
    public static function on_tutor_enrolled(int $course_id, int $user_id, int $enroll_id): void {
        $s = self::settings(); if ($s['enable_tutor_enrolled'] !== '1') return;
        $phone = self::tutor_user_phone($user_id); if (!$phone) return;
        $user  = get_userdata($user_id);
        $vars  = self::tutor_course_vars($course_id, $user);
        self::send($phone, self::parse($s['tpl_tutor_enrolled'], $vars));
    }

    public static function on_tutor_completed(int $course_id, int $user_id): void {
        $s = self::settings(); if ($s['enable_tutor_completed'] !== '1') return;
        $phone = self::tutor_user_phone($user_id); if (!$phone) return;
        $user  = get_userdata($user_id);
        $vars  = self::tutor_course_vars($course_id, $user);
        self::send($phone, self::parse($s['tpl_tutor_completed'], $vars));
    }

    public static function on_tutor_certificate(int $course_id, int $user_id): void {
        $s = self::settings(); if ($s['enable_tutor_certificate'] !== '1') return;
        $phone = self::tutor_user_phone($user_id); if (!$phone) return;
        $user  = get_userdata($user_id);
        $vars  = self::tutor_course_vars($course_id, $user);
        // Try to get certificate URL
        $cert_url = '';
        if (function_exists('tutor_utils')) {
            $cert = tutor_utils()->get_certificate_by_user($course_id, $user_id);
            if ($cert) $cert_url = $cert->certificate_url ?? '';
        }
        $vars['certificate_url'] = $cert_url ?: get_permalink($course_id);
        self::send($phone, self::parse($s['tpl_tutor_certificate'], $vars));
    }

    public static function on_tutor_lesson(int $lesson_id, int $user_id): void {
        $s = self::settings(); if ($s['enable_tutor_lesson'] !== '1') return;
        $phone = self::tutor_user_phone($user_id); if (!$phone) return;
        $user  = get_userdata($user_id);
        // Get course from lesson
        $course_id = 0;
        if (function_exists('tutor_utils')) {
            $course_id = tutor_utils()->get_course_id_by_content($lesson_id) ?: 0;
        }
        $vars = self::tutor_course_vars($course_id, $user);
        $vars['lesson_name'] = get_the_title($lesson_id);
        self::send($phone, self::parse($s['tpl_tutor_lesson'], $vars));
    }

    public static function on_tutor_quiz(object $attempt): void {
        $s       = self::settings();
        $user_id = (int)($attempt->user_id ?? 0);
        $quiz_id = (int)($attempt->quiz_id ?? 0);
        if (!$user_id) return;

        $total_marks   = (float)($attempt->total_marks ?? 0);
        $earned_marks  = (float)($attempt->earned_marks ?? 0);
        $passing_grade = (float)($attempt->passing_grade ?? 80);
        $score         = $total_marks > 0 ? round(($earned_marks / $total_marks) * 100) : 0;
        $passed        = $score >= $passing_grade;

        if ($passed && $s['enable_tutor_quiz_passed'] !== '1') return;
        if (!$passed && $s['enable_tutor_quiz_failed'] !== '1') return;

        $phone = self::tutor_user_phone($user_id); if (!$phone) return;
        $user  = get_userdata($user_id);

        $course_id = 0;
        if (function_exists('tutor_utils')) {
            $course_id = tutor_utils()->get_course_id_by_content($quiz_id) ?: 0;
        }

        $vars = self::tutor_course_vars($course_id, $user);
        $vars['quiz_name'] = get_the_title($quiz_id);
        $vars['score']     = $score;
        $vars['passed']    = $passed ? 'Passed' : 'Failed';

        $tpl = $passed ? $s['tpl_tutor_quiz_passed'] : $s['tpl_tutor_quiz_failed'];
        self::send($phone, self::parse($tpl, $vars));
    }

    // ── Tutor Announcement ───────────────────────────────────────────────────────
    public static function on_tutor_announcement(int $post_id, \WP_Post $post, bool $update): void {
        // Only fire on publish, not update
        if ($post->post_status !== 'publish') return;
        if ($update) return;

        $s = self::settings();
        if ($s['enable_tutor_announcement'] !== '1') return;

        // Get course ID from announcement
        $course_id = (int)($post->post_parent ?? 0);
        if (!$course_id) return;

        // Get all students enrolled in this course
        $enrolled_users = [];
        if (function_exists('tutor_utils')) {
            $enrolled = tutor_utils()->get_enrolled_users_by_course($course_id);
            if ($enrolled) {
                $enrolled_users = is_array($enrolled) ? $enrolled : (array)$enrolled;
            }
        }

        if (empty($enrolled_users)) return;

        $course_name = get_the_title($course_id);
        $title       = $post->post_title;
        $content     = wp_strip_all_tags($post->post_content);
        // Trim content to avoid very long messages
        if (strlen($content) > 300) $content = substr($content, 0, 300) . '...';

        $delay = 3; // seconds between sends
        foreach ($enrolled_users as $student) {
            $user_id = is_object($student) ? (int)$student->ID : (int)$student;
            $phone   = self::tutor_user_phone($user_id);
            if (!$phone) continue;

            $user = get_userdata($user_id);
            $msg  = self::parse($s['tpl_tutor_announcement'], [
                'first_name'  => $user->first_name ?: $user->display_name,
                'course_name' => $course_name,
                'title'       => $title,
                'content'     => $content,
                'course_url'  => get_permalink($course_id),
                'shop_name'   => get_bloginfo('name'),
            ]);
            self::send($phone, $msg);
            sleep($delay);
        }
    }

    // ── Tutor LMS helpers ─────────────────────────────────────────────────────
    private static function tutor_user_phone(int $user_id): string {
        $s = self::settings();
        // Try billing_phone (WooCommerce), then wabek_phone custom field
        $phone = get_user_meta($user_id, 'billing_phone', true)
              ?: get_user_meta($user_id, 'wabek_phone', true)
              ?: get_user_meta($user_id, $s['phone_field'], true)
              ?: '';
        return trim($phone);
    }

    private static function tutor_course_vars(int $course_id, $user): array {
        return [
            'first_name'  => $user->first_name ?: $user->display_name,
            'last_name'   => $user->last_name ?? '',
            'course_name' => $course_id ? get_the_title($course_id) : '',
            'course_url'  => $course_id ? get_permalink($course_id) : '',
            'shop_name'   => get_bloginfo('name'),
        ];
    }

    // ── Abandoned cart ────────────────────────────────────────────────────────
    public static function track_cart(): void {
        if (!is_user_logged_in()) return;
        update_user_meta(get_current_user_id(), '_wabek_cart_time', time());
        update_user_meta(get_current_user_id(), '_wabek_cart_sent', '0');
    }

    public static function clear_cart_track(): void {
        if (!is_user_logged_in()) return;
        delete_user_meta(get_current_user_id(), '_wabek_cart_time');
        delete_user_meta(get_current_user_id(), '_wabek_cart_sent');
    }

    public static function check_abandoned_carts(): void {
        $s      = self::settings();
        $delay  = (int)($s['abandoned_cart_delay'] ?: 60) * 60;
        $cutoff = time() - $delay;
        $users  = get_users([
            'meta_query' => [
                ['key' => '_wabek_cart_time', 'value' => $cutoff, 'compare' => '<', 'type' => 'NUMERIC'],
                ['key' => '_wabek_cart_sent', 'value' => '0'],
            ],
            'number' => 50,
        ]);
        foreach ($users as $user) {
            $phone = get_user_meta($user->ID, 'billing_phone', true);
            if (!$phone) continue;
            $msg = self::parse($s['tpl_abandoned_cart'], [
                'first_name' => $user->first_name ?: $user->display_name,
                'items'      => 'items in your cart',
                'cart_url'   => wc_get_cart_url(),
                'shop_name'  => get_bloginfo('name'),
            ]);
            if (self::send($phone, $msg)) {
                update_user_meta($user->ID, '_wabek_cart_sent', '1');
            }
        }
    }

    // ── Chat widget ───────────────────────────────────────────────────────────
    public static function chat_widget(): void {
        $s     = self::settings();
        $phone = preg_replace('/[^\d]/', '', $s['chat_widget_phone']);
        if (!$phone) return;
        $msg  = rawurlencode($s['chat_widget_message'] ?: 'Hello!');
        $col  = preg_replace('/[^#a-fA-F0-9]/', '', $s['chat_widget_color'] ?: '#25D366');
        $side = $s['chat_widget_position'] === 'left' ? 'left:20px' : 'right:20px';
        echo "<style>.wb-fl{position:fixed;bottom:24px;{$side};z-index:9999;width:56px;height:56px;border-radius:50%;background:{$col};display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(0,0,0,.25);text-decoration:none;transition:transform .2s}.wb-fl:hover{transform:scale(1.1)}.wb-fl svg{width:28px;height:28px;fill:#fff}</style><a class='wb-fl' href='https://wa.me/{$phone}?text={$msg}' target='_blank' rel='noopener'><svg viewBox='0 0 24 24'><path d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z'/><path d='M12 0C5.373 0 0 5.373 0 12c0 2.125.554 4.122 1.524 5.855L.057 23.213a.75.75 0 00.921.902l5.455-1.43A11.943 11.943 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.907 0-3.695-.498-5.246-1.369l-.376-.219-3.889 1.02 1.041-3.796-.237-.389A9.955 9.955 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z'/></svg></a>";
    }

    // ── Admin ─────────────────────────────────────────────────────────────────
    public static function admin_menu(): void {
        add_menu_page('WABEK WhatsApp', 'WABEK WhatsApp', 'manage_options', 'wabek', [__CLASS__, 'admin_page'], 'dashicons-whatsapp', 58);
        add_submenu_page('wabek', 'Settings',   'Settings',   'manage_options', 'wabek',           [__CLASS__, 'admin_page']);
        add_submenu_page('wabek', 'Templates',  'Templates',  'manage_options', 'wabek-templates', [__CLASS__, 'templates_page']);
        add_submenu_page('wabek', 'Campaigns',  'Campaigns',  'manage_options', 'wabek-campaigns', [__CLASS__, 'campaigns_page']);
        add_submenu_page('wabek', 'Sync Contacts', 'Sync Contacts', 'manage_options', 'wabek-contacts', [__CLASS__, 'contacts_page']);
    }

    public static function admin_init(): void {
        register_setting('wabek_settings_group', WABEK_OPTION_KEY, ['sanitize_callback' => [__CLASS__, 'sanitize_settings']]);
    }

    public static function sanitize_settings(array $input): array {
        $s = self::settings();
        foreach ($input as $k => $v) $s[$k] = sanitize_textarea_field($v);
        return $s;
    }

    public static function admin_notices(): void {
        $s = self::settings();
        if (empty($s['api_key']) && current_user_can('manage_options')) {
            echo '<div class="notice notice-warning is-dismissible"><p><strong>WABEK WhatsApp:</strong> API Key not configured. <a href="' . admin_url('admin.php?page=wabek') . '">Configure now →</a></p></div>';
        }
    }

    public static function admin_page():     void { require_once WABEK_PLUGIN_DIR . 'includes/admin-settings.php'; }
    public static function templates_page(): void { require_once WABEK_PLUGIN_DIR . 'includes/admin-templates.php'; }
    public static function campaigns_page(): void { require_once WABEK_PLUGIN_DIR . 'includes/admin-campaigns.php'; }
    public static function contacts_page():  void { require_once WABEK_PLUGIN_DIR . 'includes/admin-contacts.php'; }
}

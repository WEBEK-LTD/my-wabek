<?php if (!defined('ABSPATH')) exit;
$s = WABEK::settings();
if (isset($_POST['wabek_save_tpl']) && check_admin_referer('wabek_tpl_nonce')) {
    $cur = get_option(WABEK_OPTION_KEY, []);
    $keys = ['tpl_order_new','tpl_order_processing','tpl_order_completed','tpl_order_cancelled','tpl_order_refunded','tpl_order_on_hold','tpl_abandoned_cart','tpl_tutor_enrolled','tpl_tutor_completed','tpl_tutor_certificate','tpl_tutor_lesson','tpl_tutor_quiz_passed','tpl_tutor_quiz_failed'];
    foreach ($keys as $k) { if (isset($_POST[$k])) $cur[$k] = sanitize_textarea_field($_POST[$k]); }
    update_option(WABEK_OPTION_KEY, $cur);
    $s = WABEK::settings();
    echo '<div class="notice notice-success"><p>✅ Templates saved!</p></div>';
}
$groups = [
    '🛒 WooCommerce' => [
        'tpl_order_new'        => ['New Order',       'order_id, first_name, last_name, total, items, shop_name'],
        'tpl_order_processing' => ['Processing',      'order_id, first_name, total, estimated_delivery'],
        'tpl_order_completed'  => ['Completed',       'order_id, first_name, total'],
        'tpl_order_cancelled'  => ['Cancelled',       'order_id, first_name, total'],
        'tpl_order_refunded'   => ['Refunded',        'order_id, first_name, total'],
        'tpl_order_on_hold'    => ['On Hold',         'order_id, first_name, total'],
        'tpl_abandoned_cart'   => ['Abandoned Cart',  'first_name, items, cart_url, shop_name'],
    ],
    '🎓 Tutor LMS' => [
        'tpl_tutor_enrolled'    => ['Enrolled',           'first_name, course_name, course_url, shop_name'],
        'tpl_tutor_completed'   => ['Course Completed',   'first_name, course_name, course_url'],
        'tpl_tutor_certificate' => ['Certificate Ready',  'first_name, course_name, certificate_url'],
        'tpl_tutor_lesson'      => ['Lesson Completed',   'first_name, lesson_name, course_name'],
        'tpl_tutor_quiz_passed' => ['Quiz Passed',        'first_name, quiz_name, score, course_name'],
        'tpl_tutor_quiz_failed'   => ['Quiz Failed',        'first_name, quiz_name, score, course_name'],
        'tpl_tutor_announcement'  => ['Course Announcement', 'first_name, course_name, title, content, course_url, shop_name'],
    ],
];
?>
<div class="wrap">
<h1>📝 Message Templates</h1>
<p>Use <code>{{variable}}</code> to insert dynamic values.</p>
<form method="post">
<?php wp_nonce_field('wabek_tpl_nonce'); ?>
<input type="hidden" name="wabek_save_tpl" value="1">
<?php foreach ($groups as $group => $tpls): ?>
<h2><?= $group ?></h2>
<table class="form-table">
<?php foreach ($tpls as $key => [$label, $vars]): ?>
<tr><th><?= $label ?></th><td>
    <textarea name="<?= $key ?>" rows="4" class="large-text"><?= esc_textarea($s[$key] ?? '') ?></textarea>
    <p class="description">Variables: <?= implode(', ', array_map(fn($v) => "<code>{{$v}}</code>", explode(', ', $vars))) ?></p>
</td></tr>
<?php endforeach; ?>
</table>
<?php endforeach; ?>
<?php submit_button('Save Templates'); ?>
</form>
</div>

<?php if (!defined('ABSPATH')) exit;
$s     = WABEK::settings();
$saved = isset($_GET['settings-updated']) ? '<div class="notice notice-success"><p>✅ Settings saved!</p></div>' : '';
$test  = '';
if (isset($_POST['wabek_test']) && check_admin_referer('wabek_test_nonce')) {
    $phone = sanitize_text_field($_POST['test_phone'] ?? '');
    if ($phone) {
        $ok   = WABEK::send($phone, '✅ WABEK test message from WordPress! Your integration is working. 🎉');
        $test = $ok
            ? '<div class="notice notice-success"><p>✅ Test message sent successfully!</p></div>'
            : '<div class="notice notice-error"><p>❌ Failed. Check API Key and phone number.</p></div>';
    }
}
?>
<div class="wrap">
<h1>📱 WABEK WhatsApp Settings</h1>
<?= $saved . $test ?>

<form method="post" action="options.php">
<?php settings_fields('wabek_settings_group'); ?>
<table class="form-table">

<tr><th colspan="2"><h2>⚙️ API Configuration</h2></th></tr>
<tr><th>API Key</th><td>
    <input type="password" name="<?= WABEK_OPTION_KEY ?>[api_key]" value="<?= esc_attr($s['api_key']) ?>" class="regular-text">
    <p class="description">Get from <a href="https://waabek.com/dashboard/api-keys" target="_blank">Dashboard → API Keys</a></p>
</td></tr>
<tr><th>API URL</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[api_url]" value="<?= esc_attr($s['api_url']) ?>" class="regular-text">
</td></tr>
<tr><th>Instance ID</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[instance_id]" value="<?= esc_attr($s['instance_id']) ?>" class="regular-text">
    <p class="description">Leave empty to use default WhatsApp instance.</p>
</td></tr>
<tr><th>Phone Field</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[phone_field]" value="<?= esc_attr($s['phone_field']) ?>" class="small-text">
    <p class="description">WooCommerce/user meta field for phone. Default: <code>billing_phone</code></p>
</td></tr>
<tr><th>Default Country Code</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[default_country_code]" value="<?= esc_attr($s['default_country_code']) ?>" class="small-text" placeholder="20">
    <p class="description">e.g. 20 (Egypt), 966 (Saudi), 44 (UK)</p>
</td></tr>

<tr><th colspan="2"><h2>🛒 WooCommerce Notifications</h2></th></tr>
<?php foreach ([
    'enable_order_new'        => 'New Order Placed',
    'enable_order_processing' => 'Order Processing',
    'enable_order_completed'  => 'Order Completed',
    'enable_order_cancelled'  => 'Order Cancelled',
    'enable_order_refunded'   => 'Order Refunded',
] as $key => $label): ?>
<tr><th><?= $label ?></th><td>
    <input type="checkbox" name="<?= WABEK_OPTION_KEY ?>[<?= $key ?>]" value="1" <?= checked($s[$key], '1') ?>>
</td></tr>
<?php endforeach; ?>

<tr><th colspan="2"><h2>🎓 Tutor LMS Notifications</h2></th></tr>
<?php foreach ([
    'enable_tutor_enrolled'    => 'Student Enrolled in Course',
    'enable_tutor_completed'   => 'Course Completed',
    'enable_tutor_certificate' => 'Certificate Generated',
    'enable_tutor_lesson'      => 'Lesson Completed',
    'enable_tutor_quiz_passed' => 'Quiz Passed',
    'enable_tutor_quiz_failed'   => 'Quiz Failed',
    'enable_tutor_announcement'  => 'Course Announcements (sends to all enrolled students)',
] as $key => $label): ?>
<tr><th><?= $label ?></th><td>
    <input type="checkbox" name="<?= WABEK_OPTION_KEY ?>[<?= $key ?>]" value="1" <?= checked($s[$key], '1') ?>>
</td></tr>
<?php endforeach; ?>

<tr><th colspan="2"><h2>🛒 Abandoned Cart</h2></th></tr>
<tr><th>Enable</th><td>
    <input type="checkbox" name="<?= WABEK_OPTION_KEY ?>[enable_abandoned_cart]" value="1" <?= checked($s['enable_abandoned_cart'], '1') ?>>
    <p class="description">Remind logged-in users who leave items in cart.</p>
</td></tr>
<tr><th>Delay (minutes)</th><td>
    <input type="number" name="<?= WABEK_OPTION_KEY ?>[abandoned_cart_delay]" value="<?= esc_attr($s['abandoned_cart_delay']) ?>" class="small-text" min="15">
</td></tr>

<tr><th colspan="2"><h2>💬 Chat Widget</h2></th></tr>
<tr><th>Enable Widget</th><td>
    <input type="checkbox" name="<?= WABEK_OPTION_KEY ?>[enable_chat_widget]" value="1" <?= checked($s['enable_chat_widget'], '1') ?>>
</td></tr>
<tr><th>Widget Phone</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[chat_widget_phone]" value="<?= esc_attr($s['chat_widget_phone']) ?>" class="regular-text" placeholder="+201234567890">
</td></tr>
<tr><th>Pre-filled Message</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[chat_widget_message]" value="<?= esc_attr($s['chat_widget_message']) ?>" class="large-text">
</td></tr>
<tr><th>Widget Color</th><td>
    <input type="text" name="<?= WABEK_OPTION_KEY ?>[chat_widget_color]" value="<?= esc_attr($s['chat_widget_color']) ?>" class="small-text" placeholder="#25D366">
</td></tr>
<tr><th>Position</th><td>
    <select name="<?= WABEK_OPTION_KEY ?>[chat_widget_position]">
        <option value="right" <?= selected($s['chat_widget_position'], 'right') ?>>Right</option>
        <option value="left"  <?= selected($s['chat_widget_position'], 'left')  ?>>Left</option>
    </select>
</td></tr>

</table>
<?php submit_button('Save Settings'); ?>
</form>

<hr>
<h2>🧪 Test Message</h2>
<form method="post">
<?php wp_nonce_field('wabek_test_nonce'); ?>
<input type="hidden" name="wabek_test" value="1">
<table class="form-table">
<tr><th>Phone Number</th><td>
    <input type="text" name="test_phone" class="regular-text" placeholder="+201234567890" value="<?= esc_attr($_POST['test_phone'] ?? '') ?>">
    <p class="description">Include country code.</p>
</td></tr>
</table>
<?php submit_button('📤 Send Test', 'secondary'); ?>
</form>
</div>

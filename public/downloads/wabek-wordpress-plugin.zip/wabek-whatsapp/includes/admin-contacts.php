<?php if (!defined('ABSPATH')) exit;
$s   = WABEK::settings();
$msg = '';

// Resolve the base API URL (e.g. https://waabek.com/api/v1/send -> https://waabek.com/api/v1)
$api_base = trim($s['api_url'] ?: 'https://waabek.com/api/v1/send');
$api_base = preg_replace('#/send/?$#', '', $api_base);
$contacts_url = rtrim($api_base, '/') . '/contacts';

if (isset($_POST['wabek_sync_contacts']) && check_admin_referer('wabek_sync_contacts_nonce')) {
    $source = sanitize_text_field($_POST['source'] ?? 'customers');
    $tag    = sanitize_text_field($_POST['tag'] ?? '');

    if (!$s['api_key']) {
        $msg = "<div class='notice notice-error'><p>⚠️ Configure your API Key in Settings first.</p></div>";
    } else {
        $args = ['number' => -1];
        if ($source === 'customers')   $args['role'] = 'customer';
        elseif ($source === 'subscribers') $args['role'] = 'subscriber';
        // 'all' = no role filter

        $users   = get_users($args);
        $synced  = 0;
        $skipped = 0;
        $failed  = 0;

        $cc = trim($s['default_country_code']);

        foreach ($users as $user) {
            $phone = get_user_meta($user->ID, 'billing_phone', true)
                  ?: get_user_meta($user->ID, 'wabek_phone', true)
                  ?: '';

            $phone = preg_replace('/[^\d]/', '', (string)$phone);
            if (!$phone) { $skipped++; continue; }
            if ($cc && strlen($phone) <= 10) $phone = ltrim($cc, '0+') . $phone;

            $name = trim($user->first_name . ' ' . $user->last_name) ?: $user->display_name;
            $tags = $tag ? [$tag] : [];

            $body = [
                'phone' => $phone,
                'name'  => $name,
                'email' => $user->user_email,
                'tags'  => $tags,
            ];

            $response = wp_remote_post($contacts_url, [
                'timeout' => 15,
                'headers' => ['X-API-Key' => $s['api_key'], 'Content-Type' => 'application/json'],
                'body'    => wp_json_encode($body),
            ]);

            if (is_wp_error($response)) { $failed++; continue; }
            $code = wp_remote_retrieve_response_code($response);
            if ($code === 200) $synced++; else $failed++;
        }

        $msg = "<div class='notice notice-success'><p>✅ Sync done: <strong>{$synced}</strong> synced, "
             . "<strong>{$skipped}</strong> skipped (no phone), <strong>{$failed}</strong> failed.</p></div>";
    }
}

$counts = [
    'customers'   => count(get_users(['role' => 'customer',   'number' => -1, 'fields' => 'ID'])),
    'subscribers' => count(get_users(['role' => 'subscriber', 'number' => -1, 'fields' => 'ID'])),
    'all'         => count(get_users(['number' => -1, 'fields' => 'ID'])),
];
?>
<div class="wrap">
<h1>📇 Sync Contacts to WABEK</h1>
<?= $msg ?>
<?php if (!$s['api_key']): ?>
    <div class="notice notice-warning"><p>Configure API Key in <a href="<?= admin_url('admin.php?page=wabek') ?>">Settings</a> first.</p></div>
<?php else: ?>
<div class="notice notice-info">
    <p>
        Pulls WordPress users with a phone number (<code>billing_phone</code> from WooCommerce,
        or <code>wabek_phone</code> custom field) and saves them as Contacts in your WABEK
        account, ready for use in Campaigns and Segments.
    </p>
</div>
<form method="post">
<?php wp_nonce_field('wabek_sync_contacts_nonce'); ?>
<input type="hidden" name="wabek_sync_contacts" value="1">
<table class="form-table">
<tr><th>Source</th><td>
    <select name="source">
        <option value="customers">WooCommerce Customers (<?= $counts['customers'] ?>)</option>
        <option value="subscribers">Subscribers (<?= $counts['subscribers'] ?>)</option>
        <option value="all">All Users (<?= $counts['all'] ?>)</option>
    </select>
</td></tr>
<tr><th>Tag (optional)</th><td>
    <input type="text" name="tag" class="regular-text" placeholder="e.g. wordpress, woocommerce">
    <p class="description">Adds this tag to every synced contact, so you can filter/segment them later in WABEK.</p>
</td></tr>
</table>
<div class="notice notice-warning" style="margin:0 0 16px"><p>
    ⚠️ Only sync contacts who have consented to receive WhatsApp messages, in line with
    Meta's WhatsApp Business policy.
</p></div>
<?php submit_button('📥 Sync Contacts', 'primary', '', true, ['onclick' => "return confirm('Sync the selected users to WABEK Contacts now?')"]); ?>
</form>
<?php endif; ?>
</div>

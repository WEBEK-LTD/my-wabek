<?php if (!defined('ABSPATH')) exit;
$s   = WABEK::settings();
$msg = '';
if (isset($_POST['wabek_send_campaign']) && check_admin_referer('wabek_campaign_nonce')) {
    $text   = sanitize_textarea_field($_POST['campaign_message'] ?? '');
    $target = sanitize_text_field($_POST['target'] ?? 'customers');
    $delay  = max(3, (int)($_POST['delay'] ?? 5));

    if ($text && $s['api_key']) {

        if ($target === 'single') {
            // ── Send to a single phone number ──────────────────────────
            $phone = sanitize_text_field($_POST['single_phone'] ?? '');
            $name  = sanitize_text_field($_POST['single_name']  ?? '');

            if (!$phone) {
                $msg = "<div class='notice notice-error'><p>⚠️ Please enter a phone number.</p></div>";
            } else {
                $parsed = WABEK::parse($text, [
                    'first_name' => $name ?: 'Customer',
                    'last_name'  => '',
                    'email'      => '',
                    'shop_name'  => get_bloginfo('name'),
                ]);
                $ok  = WABEK::send($phone, $parsed, $name ?: 'Customer');
                $msg = $ok
                    ? "<div class='notice notice-success'><p>📤 Message sent to <strong>{$phone}</strong>.</p></div>"
                    : "<div class='notice notice-error'><p>❌ Failed to send message to <strong>{$phone}</strong>. Check your API settings and phone number format.</p></div>";
            }
        } else {
            // ── Send to a group of users ────────────────────────────────
            $args = ['number' => -1];
            if ($target === 'customers') $args['role'] = 'customer';
            elseif ($target === 'subscribers') $args['role'] = 'subscriber';
            $users = get_users($args);
            $sent = $fail = 0;
            foreach ($users as $user) {
                $phone = get_user_meta($user->ID, 'billing_phone', true) ?: get_user_meta($user->ID, 'wabek_phone', true) ?: '';
                if (!$phone) { $fail++; continue; }
                $parsed = WABEK::parse($text, ['first_name'=>$user->first_name?:$user->display_name,'last_name'=>$user->last_name,'email'=>$user->user_email,'shop_name'=>get_bloginfo('name')]);
                WABEK::send($phone, $parsed, $user->first_name ?: $user->display_name ?: 'Customer') ? $sent++ : $fail++;
                if (count($users) > 1) sleep($delay);
            }
            $msg = "<div class='notice notice-success'><p>📢 Campaign done: <strong>{$sent}</strong> sent, <strong>{$fail}</strong> failed.</p></div>";
        }
    }
}
$counts = [
    'customers'   => count(get_users(['role'=>'customer',    'number'=>-1,'fields'=>'ID'])),
    'subscribers' => count(get_users(['role'=>'subscriber',  'number'=>-1,'fields'=>'ID'])),
    'all'         => count(get_users(['number'=>-1,'fields'=>'ID'])),
];
?>
<div class="wrap">
<h1>📢 WhatsApp Campaigns</h1>
<?= $msg ?>
<?php if (!$s['api_key']): ?>
    <div class="notice notice-warning"><p>Configure API Key in <a href="<?= admin_url('admin.php?page=wabek') ?>">Settings</a> first.</p></div>
<?php else: ?>
<div class="notice notice-info"><p>💡 Variables: <code>{{first_name}}</code> <code>{{last_name}}</code> <code>{{email}}</code> <code>{{shop_name}}</code></p></div>
<form method="post" id="wabek-campaign-form">
<?php wp_nonce_field('wabek_campaign_nonce'); ?>
<input type="hidden" name="wabek_send_campaign" value="1">
<table class="form-table">
<tr><th>Target</th><td>
    <select name="target" id="wabek-target">
        <option value="customers">WooCommerce Customers (<?= $counts['customers'] ?>)</option>
        <option value="subscribers">Subscribers (<?= $counts['subscribers'] ?>)</option>
        <option value="all">All Users (<?= $counts['all'] ?>)</option>
        <option value="single">Single Recipient (one phone number)</option>
    </select>
</td></tr>
<tr id="wabek-single-row" style="display:none">
    <th>Recipient</th>
    <td>
        <input type="text" name="single_phone" class="regular-text" placeholder="e.g. 905446731942 (with country code)">
        <p class="description">Phone number including country code, digits only or with leading +.</p>
        <input type="text" name="single_name" class="regular-text" placeholder="Name (optional, used for {{first_name}})" style="margin-top:6px">
    </td>
</tr>
<tr><th>Message</th><td>
    <textarea name="campaign_message" rows="7" class="large-text" placeholder="Hi {{first_name}}, we have something special for you..."></textarea>
</td></tr>
<tr id="wabek-delay-row"><th>Delay (seconds)</th><td>
    <input type="number" name="delay" value="5" min="3" max="60" class="small-text">
    <p class="description">Minimum 3 seconds between messages.</p>
</td></tr>
</table>
<div class="notice notice-warning" style="margin:0 0 16px"><p>⚠️ Only send to contacts who have consented to receive WhatsApp messages.</p></div>
<?php submit_button('📤 Send Campaign', 'primary', '', true, ['onclick'=>"return confirm('Send this message?')"]); ?>
</form>
<script>
(function(){
    var target = document.getElementById('wabek-target');
    var singleRow = document.getElementById('wabek-single-row');
    var delayRow  = document.getElementById('wabek-delay-row');
    function toggle(){
        var isSingle = target.value === 'single';
        singleRow.style.display = isSingle ? '' : 'none';
        delayRow.style.display  = isSingle ? 'none' : '';
    }
    target.addEventListener('change', toggle);
    toggle();
})();
</script>
<?php endif; ?>
</div>

jQuery(function ($) {
    'use strict';

    var wk = window.waabek || {};

    // ── Helpers ────────────────────────────────────────────────────────

    function showNotice(msg, type) {
        var $n = $('#waabek-notice');
        $n.removeClass('success error').addClass(type).text(msg).show();
        setTimeout(function () { $n.fadeOut(); }, 4000);
    }

    function showInline($el, msg, type) {
        $el.removeClass('success error').addClass(type).text(msg).show();
        setTimeout(function () { $el.fadeOut(300, function () { $el.removeClass('success error').empty(); }); }, 4000);
    }

    // ── Toggle password visibility ──────────────────────────────────────

    $(document).on('click', '.waabek-toggle-password', function () {
        var id = $(this).data('target');
        var $input = $('#' + id);
        $input.attr('type', $input.attr('type') === 'password' ? 'text' : 'password');
    });

    // ── Mode change ─────────────────────────────────────────────────────

    $('#waabek_mode').on('change', function () {
        $('#cloud_api_notice').toggle($(this).val() === 'cloud_api');
    });

    // ── Test Connection ─────────────────────────────────────────────────

    $('#waabek-test-btn').on('click', function () {
        var $btn = $(this), $res = $('#waabek-test-result');
        $btn.prop('disabled', true).text(wk.strings.testing);
        $res.hide();
        $.post(wk.ajax_url, { action: 'waabek_test_connection', nonce: wk.nonce }, function (r) {
            if (r.success) {
                showInline($res, '✅ ' + wk.strings.connected, 'success');
            } else {
                showInline($res, '❌ ' + (r.data && r.data.message ? r.data.message : wk.strings.failed), 'error');
            }
        }).always(function () { $btn.prop('disabled', false).html('⚡ Test Connection'); });
    });

    // ── Save Settings — handled below in Admin notify toggle section ────

    // ── Send Test Message ───────────────────────────────────────────────

    $('#waabek-test-msg-btn').on('click', function () {
        var $btn = $(this), $res = $('#waabek-test-msg-result');
        var phone = $('#test_phone').val().trim();
        var msg   = $('#test_message').val().trim();

        if (!phone || !msg) {
            showInline($res, '❌ Phone and message are required.', 'error');
            return;
        }
        $btn.prop('disabled', true).text(wk.strings.sending);
        $.post(wk.ajax_url, {
            action:  'waabek_send_test_message',
            nonce:   wk.nonce,
            phone:   phone,
            message: msg,
        }, function (r) {
            if (r.success) {
                showInline($res, '✅ ' + wk.strings.sent, 'success');
            } else {
                showInline($res, '❌ ' + (r.data && r.data.message ? r.data.message : 'Failed'), 'error');
            }
        }).always(function () { $btn.prop('disabled', false).html('📱 Send Test Message'); });
    });

    // ── Templates page ──────────────────────────────────────────────────

    // Toggle template body
    $(document).on('change', '.tpl-enabled', function () {
        $(this).closest('.waabek-template-card').find('.waabek-template-body')
            .toggleClass('waabek-disabled', !$(this).is(':checked'));
    });

    // Char counter
    function updateCharCount($ta) {
        $ta.closest('.waabek-template-body').find('.char-count-num').text($ta.val().length);
    }
    $(document).on('input', '.tpl-message', function () { updateCharCount($(this)); });
    $('.tpl-message').each(function () { updateCharCount($(this)); });

    // Copy variable on click
    $(document).on('click', '.waabek-var-code', function () {
        var text = $(this).text();
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            var $tmp = $('<input>').val(text).appendTo('body').select();
            document.execCommand('copy');
            $tmp.remove();
        }
        var $el = $(this);
        var orig = $el.css('background');
        $el.css('background', '#dcfce7');
        setTimeout(function () { $el.css('background', orig); }, 800);
    });

    // Toggle vars visibility
    $('.waabek-toggle-vars').on('click', function () {
        $('#waabek-vars-grid').slideToggle(200);
    });

    // Fix 1: Reset template using waabek.defaults passed from PHP
    $(document).on('click', '.waabek-reset-tpl', function () {
        var event   = $(this).data('event');
        var defaults = wk.defaults || {};
        if (!defaults[event]) return;
        if (!confirm('Reset "' + event + '" to default template?')) return;
        var $ta = $(this).closest('.waabek-template-card').find('.tpl-message');
        $ta.val(defaults[event]).trigger('input');
    });

    // Save templates
    $('#waabek-save-tpl-btn').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text(wk.strings.saving);

        var templates = {};
        $('.waabek-template-card').each(function () {
            var ev = $(this).data('event');
            templates[ev] = {
                enabled: $(this).find('.tpl-enabled').is(':checked') ? '1' : '0',
                message: $(this).find('.tpl-message').val(),
            };
        });

        $.post(wk.ajax_url, {
            action:    'waabek_save_templates',
            nonce:     wk.nonce,
            templates: templates,
        }, function (r) {
            if (r.success) {
                showNotice('✅ ' + (r.data && r.data.message ? r.data.message : 'Saved!'), 'success');
            } else {
                showNotice('❌ ' + (r.data && r.data.message ? r.data.message : 'Error'), 'error');
            }
        }).always(function () { $btn.prop('disabled', false).html('💾 Save All Templates'); });
    });

    // ── Admin notify toggle ────────────────────────────────────────────

    $('#waabek_admin_notify').on('change', function () {
        $('#admin_phone_field').toggle($(this).is(':checked'));
    });

    // Save settings
    $('#waabek-save-btn').off('click.waabek').on('click.waabek', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text(wk.strings.saving);

        var events = {};
        // Fix 1: target event checkboxes by name attribute, not data-event
        $('input[name^="events["]').each(function () {
            var name = $(this).attr('name');
            var ev   = name.replace('events[', '').replace(']', '');
            if (ev) events[ev] = $(this).is(':checked') ? '1' : '0';
        });

        $.post(wk.ajax_url, {
            action:       'waabek_save_settings',
            nonce:        wk.nonce,
            api_key:      $('#waabek_api_key').val(),
            api_url:      $('#waabek_api_url').val(),
            instance_id:  $('#waabek_instance_id').val(),
            mode:         $('#waabek_mode').val(),
            enabled:      $('#waabek_enabled').is(':checked') ? '1' : '0',
            admin_notify: $('#waabek_admin_notify').is(':checked') ? '1' : '0',
            admin_phone:    $('#waabek_admin_phone').val(),
            admin_template:  $('#waabek_admin_template').val(),
            show_wa_field:   $('#waabek_show_wa_field').is(':checked') ? '1' : '0',
            events:       events,
        }, function (r) {
            if (r.success) showNotice('✅ ' + wk.strings.saved, 'success');
            else showNotice('❌ ' + (r.data && r.data.message ? r.data.message : 'Error'), 'error');
        }).always(function () { $btn.prop('disabled', false).html('💾 Save Settings'); });
    });

    // ── Template Preview ────────────────────────────────────────────────

    $(document).on('click', '.waabek-preview-tpl', function () {
        var event   = $(this).data('event');
        var message = $('#preview-' + event).closest('.waabek-template-card').find('.tpl-message').val();
        var $box    = $('#preview-' + event);
        var $bubble = $box.find('.waabek-preview-bubble');

        $bubble.text(wk.strings.previewing);
        $box.show();

        $.post(wk.ajax_url, {
            action:  'waabek_preview_template',
            nonce:   wk.nonce,
            message: message,
        }, function (r) {
            if (r.success) {
                // Preserve line breaks
                var raw = r.data.preview || '';
                var txt = raw.replace(/\\n/g, '\n').replace(/\r\n|\r|\n/g, '<br>');
                $bubble.html(txt);
            } else {
                $bubble.text('Preview failed.');
            }
        });
    });

    $(document).on('click', '.waabek-close-preview', function () {
        var event = $(this).data('event');
        $('#preview-' + event).hide();
    });

    // ── Logs page ───────────────────────────────────────────────────────

    // Fix 3: Export ALL logs via AJAX (not just visible page)
    $('#waabek-export-logs').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Exporting...');
        var params = new URLSearchParams(window.location.search);
        $.post(wk.ajax_url, {
            action: 'waabek_export_logs',
            nonce:  wk.nonce,
            status: params.get('status') || '',
            search: params.get('s')      || '',
            date:   params.get('date')   || '',
        }, function (r) {
            if (!r.success) return;
            var blob = new Blob([r.data.csv], { type: 'text/csv;charset=utf-8;' });
            var url  = URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href   = url;
            a.download = 'waabek-logs-' + new Date().toISOString().split('T')[0] + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }).always(function () { $btn.prop('disabled', false).html('📥 Export CSV'); });
    });

    // Clear logs
    $('#waabek-clear-logs').on('click', function () {
        if (!confirm('Are you sure you want to clear ALL logs? This cannot be undone.')) return;
        var $btn = $(this);
        $btn.prop('disabled', true).text('Clearing...');
        $.post(wk.ajax_url, { action: 'waabek_clear_logs', nonce: wk.nonce }, function (r) {
            if (r.success) {
                $('#waabek-logs-table tbody').html(
                    '<tr><td colspan="6" style="text-align:center;padding:30px;color:#94a3b8;">No logs yet.</td></tr>'
                );
                showNotice('✅ Logs cleared.', 'success');
            }
        }).always(function () { $btn.prop('disabled', false).text('🗑 Clear All Logs'); });
    });

    // Retry failed
    $(document).on('click', '.waabek-retry-btn', function () {
        var $btn  = $(this);
        var logId = $btn.data('id');
        $btn.prop('disabled', true).text('Retrying...');
        $.post(wk.ajax_url, { action: 'waabek_retry_log', nonce: wk.nonce, log_id: logId }, function (r) {
            if (r.success) {
                $btn.closest('tr').find('.waabek-status-badge').removeClass('failed').addClass('sent').text('sent');
                $btn.remove();
                showNotice('✅ Message sent successfully.', 'success');
            } else {
                showNotice('❌ ' + (r.data && r.data.message ? r.data.message : 'Retry failed'), 'error');
                $btn.prop('disabled', false).text('↩ Retry');
            }
        });
    });

});

<?php
if (!defined('ABSPATH')) exit;

class WAABEK_Templates {

    public static function get_locale(): string {
        return strpos(get_locale(), 'ar') === 0 ? 'ar' : 'en';
    }

    public static function get_defaults(): array {
        return self::get_locale() === 'ar'
            ? self::defaults_ar()
            : self::defaults_en();
    }

    private static function defaults_en(): array {
        return [
            'new_order' => [
                'label'   => __('New Order', 'waabek-woo'),
                'enabled' => true,
                'message' => "Hi {customer_name} 👋\n\nThank you for your order!\n\n🛍️ Order: #{order_number}\n💰 Total: {order_total}\n📦 Status: {order_status}\n\nItems:\n{items_list}\n\nWe'll notify you when your order ships.\n\n{shop_name}",
            ],
            'order_processing' => [
                'label'   => __('Order Processing', 'waabek-woo'),
                'enabled' => true,
                'message' => "Hi {customer_name} 👋\n\nYour order #{order_number} is now being processed! 🔄\n\n💰 Total: {order_total}\n\nWe'll keep you updated.\n\n{shop_name}",
            ],
            'order_completed' => [
                'label'   => __('Order Completed', 'waabek-woo'),
                'enabled' => true,
                'message' => "Hi {customer_name} 🎉\n\nYour order #{order_number} has been completed!\n\n✅ Status: Completed\n💰 Total: {order_total}\n\nThank you for shopping with us!\n\n{shop_name}",
            ],
            'order_cancelled' => [
                'label'   => __('Order Cancelled', 'waabek-woo'),
                'enabled' => true,
                'message' => "Hi {customer_name},\n\nYour order #{order_number} has been cancelled.\n\n❌ Status: Cancelled\n💰 Total: {order_total}\n\nContact us if you have any questions.\n\n{shop_name}",
            ],
            'order_refunded' => [
                'label'   => __('Order Refunded', 'waabek-woo'),
                'enabled' => true,
                'message' => "Hi {customer_name},\n\nYour refund for order #{order_number} has been processed. 💸\n\nRefund Amount: {order_total}\n\nPlease allow 5-7 business days.\n\n{shop_name}",
            ],
            'order_on_hold' => [
                'label'   => __('Order On Hold', 'waabek-woo'),
                'enabled' => false,
                'message' => "Hi {customer_name},\n\nYour order #{order_number} is currently on hold. ⏸️\n\nWe'll contact you shortly.\n\n{shop_name}",
            ],
            'order_failed' => [
                'label'   => __('Order Failed', 'waabek-woo'),
                'enabled' => false,
                'message' => "Hi {customer_name},\n\nYour order #{order_number} has failed. ❌\n\nPlease try again or contact us.\n\n{shop_name}",
            ],
        ];
    }

    private static function defaults_ar(): array {
        return [
            'new_order' => [
                'label'   => __('New Order', 'waabek-woo'),
                'enabled' => true,
                'message' => "مرحباً {first_name} 👋\n\nشكراً لطلبك!\n\n🛍️ رقم الطلب: #{order_number}\n💰 الإجمالي: {order_total}\n📦 الحالة: {order_status}\n\nالمنتجات:\n{items_list}\n\nسنُخطرك عند شحن طلبك.\n\n{shop_name}",
            ],
            'order_processing' => [
                'label'   => __('Order Processing', 'waabek-woo'),
                'enabled' => true,
                'message' => "مرحباً {first_name} 👋\n\nطلبك رقم #{order_number} قيد المعالجة الآن! 🔄\n\n💰 الإجمالي: {order_total}\n\nسنبقيك على اطلاع.\n\n{shop_name}",
            ],
            'order_completed' => [
                'label'   => __('Order Completed', 'waabek-woo'),
                'enabled' => true,
                'message' => "مرحباً {first_name} 🎉\n\nتم إكمال طلبك رقم #{order_number}!\n\n✅ الحالة: مكتمل\n💰 الإجمالي: {order_total}\n\nشكراً لتسوقك معنا!\n\n{shop_name}",
            ],
            'order_cancelled' => [
                'label'   => __('Order Cancelled', 'waabek-woo'),
                'enabled' => true,
                'message' => "مرحباً {first_name}،\n\nتم إلغاء طلبك رقم #{order_number}.\n\n❌ الحالة: ملغي\n💰 الإجمالي: {order_total}\n\nتواصل معنا إن كان لديك استفسار.\n\n{shop_name}",
            ],
            'order_refunded' => [
                'label'   => __('Order Refunded', 'waabek-woo'),
                'enabled' => true,
                'message' => "مرحباً {first_name}،\n\nتمت معالجة استرداد مبلغ طلبك رقم #{order_number}. 💸\n\nالمبلغ المُسترد: {order_total}\n\nيرجى الانتظار 5-7 أيام عمل.\n\n{shop_name}",
            ],
            'order_on_hold' => [
                'label'   => __('Order On Hold', 'waabek-woo'),
                'enabled' => false,
                'message' => "مرحباً {first_name}،\n\nطلبك رقم #{order_number} قيد الانتظار. ⏸️\n\nسنتواصل معك قريباً.\n\n{shop_name}",
            ],
            'order_failed' => [
                'label'   => __('Order Failed', 'waabek-woo'),
                'enabled' => false,
                'message' => "مرحباً {first_name}،\n\nفشل طلبك رقم #{order_number}. ❌\n\nيرجى المحاولة مجدداً أو التواصل معنا.\n\n{shop_name}",
            ],
        ];
    }

    public static function get_all(): array {
        $saved    = get_option('waabek_templates', []);
        $defaults = self::get_defaults();
        $result   = [];
        foreach ($defaults as $event => $default) {
            $result[$event] = array_merge($default, is_array($saved[$event] ?? null) ? $saved[$event] : []);
        }
        return $result;
    }

    public static function get(string $event): ?array {
        return self::get_all()[$event] ?? null;
    }

    public static function render(string $event, WC_Order $order): string {
        $tpl = self::get($event);
        if (!$tpl || empty($tpl['message'])) return '';
        return self::render_raw($tpl['message'], $order);
    }

    // Fix 1: render_raw restored
    public static function render_raw(string $message, WC_Order $order): string {
        $items_lines = [];
        foreach ($order->get_items() as $item) {
            $price         = self::clean_price(wc_price($item->get_total()));
            $items_lines[] = sprintf('%s x%d — %s', $item->get_name(), $item->get_quantity(), $price);
        }

        $vars = [
            '{customer_name}'  => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            '{first_name}'     => $order->get_billing_first_name(),
            '{last_name}'      => $order->get_billing_last_name(),
            '{order_number}'   => $order->get_order_number(),
            '{order_total}'    => self::clean_price($order->get_formatted_order_total()),
            '{order_status}'   => wc_get_order_status_name($order->get_status()),
            '{order_date}'     => wc_format_datetime($order->get_date_created()),
            '{order_url}'      => self::shorten_url(self::get_order_url($order)),
            '{payment_method}' => $order->get_payment_method_title(),
            '{shop_name}'      => get_bloginfo('name'),
            '{shop_url}'       => get_site_url(),
            '{shipping_method}'=> $order->get_shipping_method(),
            '{billing_address}'=> wp_strip_all_tags($order->get_formatted_billing_address()),
            '{items_count}'    => $order->get_item_count(),
            '{items_list}'     => implode("\n", $items_lines),
            '{currency}'       => get_woocommerce_currency_symbol(),
        ];

        return str_replace(array_keys($vars), array_values($vars), $message);
    }

    // Strip HTML tags + decode entities (fixes &#8378; → ₺)
    private static function clean_price(string $html): string {
        return html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    private static function get_order_url(WC_Order $order): string {
        if ($order->get_customer_id()) {
            return $order->get_view_order_url();
        }
        $key = $order->get_order_key();
        if ($key) {
            return add_query_arg(
                ['key' => $key, 'order_id' => $order->get_id()],
                wc_get_endpoint_url('order-received', $order->get_id(), wc_get_page_permalink('checkout'))
            );
        }
        return $order->get_view_order_url();
    }

    private static function shorten_url(string $url): string {
        if (function_exists('wp_get_shortlink') && preg_match('/orders\/([0-9]+)/i', $url, $m)) {
            $short = wp_get_shortlink((int)$m[1], 'post');
            if (!empty($short) && strlen($short) < strlen($url)) return $short;
        }
        return $url;
    }

    public static function get_variables_list(): array {
        return [
            '{customer_name}'  => __('Full customer name', 'waabek-woo'),
            '{first_name}'     => __('Customer first name', 'waabek-woo'),
            '{last_name}'      => __('Customer last name', 'waabek-woo'),
            '{order_number}'   => __('Order number', 'waabek-woo'),
            '{order_total}'    => __('Order total with currency symbol', 'waabek-woo'),
            '{order_status}'   => __('Order status label', 'waabek-woo'),
            '{order_date}'     => __('Order date', 'waabek-woo'),
            '{order_url}'      => __('Link to view order', 'waabek-woo'),
            '{payment_method}' => __('Payment method name', 'waabek-woo'),
            '{shop_name}'      => __('Your store name', 'waabek-woo'),
            '{shop_url}'       => __('Your store URL', 'waabek-woo'),
            '{shipping_method}'=> __('Shipping method name', 'waabek-woo'),
            '{billing_address}'=> __('Customer billing address', 'waabek-woo'),
            '{items_count}'    => __('Number of items in order', 'waabek-woo'),
            '{items_list}'     => __('List of ordered items with quantity and price', 'waabek-woo'),
            '{currency}'       => __('Currency symbol', 'waabek-woo'),
        ];
    }
}

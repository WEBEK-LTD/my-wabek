<?php
if (!defined('ABSPATH')) exit;

class WAABEK_API {

    public static function send_message(string $phone, string $message): array {
        $api_key     = trim(get_option('waabek_api_key', ''));
        $api_url     = rtrim(get_option('waabek_api_url', 'https://waabek.com'), '/');
        $instance_id = get_option('waabek_instance_id', '');

        if (empty($api_key)) {
            return ['success' => false, 'error' => __('API key not configured. Go to WAABEK WA → Settings to add your key.', 'waabek-woo')];
        }
        if (strlen($api_key) < 10) {
            return ['success' => false, 'error' => __('API key appears invalid (too short). Please check your key in Settings.', 'waabek-woo')];
        }

        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (empty($phone)) {
            return ['success' => false, 'error' => 'Invalid phone number'];
        }

        $body = ['to' => $phone, 'message' => $message];
        if (!empty($instance_id)) {
            $body['instance_id'] = $instance_id;
        }

        $response = wp_remote_post($api_url . '/api/v1/send', [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'body' => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200 && !empty($data['success'])) {
            return ['success' => true, 'message_id' => $data['message_id'] ?? null];
        }

        // Fix 3: handle 422 = outside 24h window (Cloud API)
        if ($code === 422) {
            return [
                'success'  => false,
                'error'    => __('Message not delivered: customer is outside the 24-hour messaging window. An approved WhatsApp template is required.', 'waabek-woo'),
                'code'     => 422,
                'skip_retry' => true, // no point retrying — it will keep failing
            ];
        }

        return ['success' => false, 'error' => $data['error'] ?? 'Unknown error', 'code' => $code];
    }

    public static function test_connection(): array {
        $api_key = trim(get_option('waabek_api_key', ''));
        $api_url = rtrim(get_option('waabek_api_url', 'https://waabek.com'), '/');

        if (empty($api_key)) {
            return ['success' => false, 'error' => __('API key not configured.', 'waabek-woo')];
        }
        if (strlen($api_key) < 10) {
            return ['success' => false, 'error' => __('API key appears invalid (too short).', 'waabek-woo')];
        }

        $response = wp_remote_get($api_url . '/api/v1/contacts', [
            'timeout' => 10,
            'headers' => ['Authorization' => 'Bearer ' . $api_key, 'Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) return ['success' => true];
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return ['success' => false, 'error' => $data['error'] ?? "HTTP $code"];
    }
}

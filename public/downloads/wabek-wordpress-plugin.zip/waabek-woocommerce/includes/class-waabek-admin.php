<?php
if (!defined('ABSPATH')) exit;

class WAABEK_Admin {

    public static function init(): void {
        add_action('admin_menu',            [__CLASS__, 'add_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('wp_ajax_waabek_save_settings',     [__CLASS__, 'ajax_save_settings']);
        add_action('wp_ajax_waabek_test_connection',   [__CLASS__, 'ajax_test_connection']);
        add_action('wp_ajax_waabek_save_templates',    [__CLASS__, 'ajax_save_templates']);
        add_action('wp_ajax_waabek_send_test_message', [__CLASS__, 'ajax_send_test_message']);
        add_action('wp_ajax_waabek_clear_logs',        [__CLASS__, 'ajax_clear_logs']);
        add_action('wp_ajax_waabek_retry_log',         [__CLASS__, 'ajax_retry_log']);
        add_action('wp_ajax_waabek_export_logs',        [__CLASS__, 'ajax_export_logs']);
        add_action('wp_ajax_waabek_preview_template',  [__CLASS__, 'ajax_preview_template']);
    }

    public static function add_menu(): void {
        $icon = 'data:image/svg+xml;base64,' . base64_encode(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#25D366">'
            . '<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>'
            . '<path d="M12 0C5.373 0 0 5.373 0 12c0 2.126.555 4.126 1.526 5.856L.057 23.882l6.206-1.447A11.946 11.946 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.817 9.817 0 01-5.002-1.373l-.359-.213-3.717.867.934-3.614-.234-.373A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>'
        );

        add_menu_page(__('WAABEK WhatsApp', 'waabek-woo'), __('WAABEK WA', 'waabek-woo'),
            'manage_woocommerce', 'waabek-woo', [__CLASS__, 'render_settings_page'], $icon, 58);
        add_submenu_page('waabek-woo', __('Settings', 'waabek-woo'), __('Settings', 'waabek-woo'),
            'manage_woocommerce', 'waabek-woo', [__CLASS__, 'render_settings_page']);
        add_submenu_page('waabek-woo', __('Templates', 'waabek-woo'), __('Templates', 'waabek-woo'),
            'manage_woocommerce', 'waabek-woo-templates', [__CLASS__, 'render_templates_page']);
        add_submenu_page('waabek-woo', __('Logs', 'waabek-woo'), __('Logs', 'waabek-woo'),
            'manage_woocommerce', 'waabek-woo-logs', [__CLASS__, 'render_logs_page']);
    }

    public static function enqueue_assets(string $hook): void {
        if (strpos($hook, 'waabek') === false) return;
        wp_enqueue_style('waabek-admin',  WAABEK_WOO_URL . 'assets/css/admin.css',  [], WAABEK_WOO_VERSION);
        wp_enqueue_script('waabek-admin', WAABEK_WOO_URL . 'assets/js/admin.js', ['jquery'], WAABEK_WOO_VERSION, true);

        $defaults_js = [];
        foreach (WAABEK_Templates::get_defaults() as $event => $tpl) {
            $defaults_js[$event] = $tpl['message'];
        }

        wp_localize_script('waabek-admin', 'waabek', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('waabek_nonce'),
            'defaults' => $defaults_js,
            'strings'  => [
                'saving'      => __('Saving...', 'waabek-woo'),
                'saved'       => __('Settings saved!', 'waabek-woo'),
                'testing'     => __('Testing...', 'waabek-woo'),
                'connected'   => __('Connected successfully!', 'waabek-woo'),
                'failed'      => __('Connection failed', 'waabek-woo'),
                'sending'     => __('Sending...', 'waabek-woo'),
                'sent'        => __('Test message sent!', 'waabek-woo'),
                'previewing'  => __('Generating preview...', 'waabek-woo'),
            ],
        ]);
    }

    // ── AJAX ──────────────────────────────────────────────────────────

    public static function ajax_save_settings(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');

        update_option('waabek_api_key',      sanitize_text_field($_POST['api_key']      ?? ''));
        update_option('waabek_api_url',      esc_url_raw($_POST['api_url']              ?? 'https://waabek.com'));
        update_option('waabek_instance_id',  sanitize_text_field($_POST['instance_id']  ?? ''));
        update_option('waabek_mode',         in_array($_POST['mode'] ?? '', ['wa_web','cloud_api']) ? $_POST['mode'] : 'wa_web');
        update_option('waabek_enabled',      ($_POST['enabled']      ?? '') === '1' ? '1' : '0');
        update_option('waabek_admin_notify', ($_POST['admin_notify'] ?? '') === '1' ? '1' : '0');
        update_option('waabek_admin_phone',    sanitize_text_field($_POST['admin_phone']    ?? ''));
        update_option('waabek_admin_template',  sanitize_textarea_field($_POST['admin_template']  ?? ''));
        update_option('waabek_show_wa_field',    ($_POST['show_wa_field'] ?? '') === '1' ? '1' : '0');

        $allowed = ['new_order','order_processing','order_completed','order_cancelled','order_refunded','order_on_hold','order_failed'];
        $events  = $_POST['events'] ?? [];
        $save    = [];
        foreach ($allowed as $ev) {
            $save[$ev] = isset($events[$ev]) && $events[$ev] === '1' ? '1' : '0';
        }
        update_option('waabek_events', $save);
        wp_send_json_success(['message' => __('Settings saved successfully.', 'waabek-woo')]);
    }

    public static function ajax_test_connection(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');
        $result = WAABEK_API::test_connection();
        $result['success']
            ? wp_send_json_success(['message' => __('Connected successfully!', 'waabek-woo')])
            : wp_send_json_error(['message'   => $result['error'] ?? __('Connection failed', 'waabek-woo')]);
    }

    public static function ajax_save_templates(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');
        $input    = $_POST['templates'] ?? [];
        $defaults = WAABEK_Templates::get_defaults();
        $save     = [];
        foreach ($defaults as $event => $def) {
            $save[$event] = [
                'label'   => $def['label'],
                'enabled' => isset($input[$event]['enabled']) && $input[$event]['enabled'] === '1',
                'message' => sanitize_textarea_field($input[$event]['message'] ?? $def['message']),
            ];
        }
        update_option('waabek_templates', $save);
        wp_send_json_success(['message' => __('Templates saved successfully.', 'waabek-woo')]);
    }

    public static function ajax_send_test_message(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');
        $phone   = sanitize_text_field($_POST['phone']   ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        if (!$phone || !$message) {
            wp_send_json_error(['message' => __('Phone and message are required.', 'waabek-woo')]);
            return;
        }
        $result = WAABEK_API::send_message($phone, $message);
        $result['success']
            ? wp_send_json_success(['message' => __('Test message sent successfully!', 'waabek-woo')])
            : wp_send_json_error(['message'   => $result['error'] ?? __('Failed to send message.', 'waabek-woo')]);
    }

    public static function ajax_clear_logs(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');
        global $wpdb;
        $result = $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}waabek_logs");
        if ($result === false) {
            wp_send_json_error(['message' => 'Failed to clear logs: ' . $wpdb->last_error]);
            return;
        }
        wp_send_json_success();
    }

    public static function ajax_retry_log(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');
        $log_id = (int)($_POST['log_id'] ?? 0);
        if (!$log_id) { wp_send_json_error(['message' => 'Invalid log ID']); return; }
        global $wpdb;
        $log = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}waabek_logs WHERE id = %d", $log_id
        ), ARRAY_A);
        if (!$log) { wp_send_json_error(['message' => 'Log not found']); return; }
        $result = WAABEK_API::send_message($log['phone'], $log['message']);
        if ($result['success']) {
            $wpdb->update($wpdb->prefix . 'waabek_logs',
                ['status' => 'sent', 'retried_at' => current_time('mysql')],
                ['id' => $log_id], ['%s','%s'], ['%d']
            );
            wp_send_json_success();
        } else {
            wp_send_json_error(['message' => $result['error'] ?? 'Failed']);
        }
    }

    // Fix 4: Template preview with dummy order data
    public static function ajax_preview_template(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');

        $message = sanitize_textarea_field($_POST['message'] ?? '');
        if (empty($message)) { wp_send_json_error(['message' => 'No message']); return; }

        $currency = get_woocommerce_currency_symbol();
        $shop     = get_bloginfo('name');
        $vars = [
            '{customer_name}'  => 'Ahmed Mohamed',
            '{first_name}'     => 'Ahmed',
            '{last_name}'      => 'Mohamed',
            '{order_number}'   => '1234',
            '{order_total}'    => $currency . '150.00',
            '{order_status}'   => 'Processing',
            '{order_date}'     => date_i18n(get_option('date_format')),
            '{order_url}'      => get_site_url() . '/my-account/orders/1234/',
            '{payment_method}' => 'Credit Card',
            '{shop_name}'      => $shop,
            '{shop_url}'       => get_site_url(),
            '{shipping_method}'=> 'Flat rate',
            '{billing_address}'=> '123 Main St, Cairo, Egypt',
            '{items_count}'    => '3',
            '{items_list}'     => "Product A x1 — {$currency}50.00\nProduct B x2 — {$currency}100.00",
            '{currency}'       => $currency,
        ];

        $preview = str_replace(array_keys($vars), array_values($vars), $message);
        wp_send_json_success(['preview' => $preview]);
    }

    public static function ajax_export_logs(): void {
        check_ajax_referer('waabek_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) wp_die('Unauthorized');

        global $wpdb;
        $table  = $wpdb->prefix . 'waabek_logs';
        $exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        if (!$exists) { wp_send_json_error(['message' => 'No logs']); return; }

        // Apply same filters as logs page
        $status = sanitize_text_field($_POST['status'] ?? '');
        $search = sanitize_text_field($_POST['search'] ?? '');
        $date_raw = sanitize_text_field($_POST['date'] ?? '');
        $date     = preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $date_raw) ? $date_raw : '';

        $where  = ['1=1'];
        $params = [];
        if ($status) { $where[] = 'status = %s'; $params[] = $status; }
        if ($search) { $where[] = '(order_num LIKE %s OR phone LIKE %s)'; $params[] = '%'.$search.'%'; $params[] = '%'.$search.'%'; }
        if ($date)   { $where[] = 'DATE(created_at) = %s'; $params[] = $date; }
        $where_sql = implode(' AND ', $where);

        $sql  = "SELECT id, created_at, order_num, event, phone, status, error FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT 10000";
        $logs = $params
            ? $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A)
            : $wpdb->get_results($sql, ARRAY_A);

        $rows = [['ID','Time','Order','Event','Phone','Status','Error']];
        foreach ($logs as $log) {
            $rows[] = [
                $log['id'],
                $log['created_at'],
                $log['order_num'] ?? '',
                $log['event'],
                $log['phone'] ?? '',
                $log['status'],
                $log['error'] ?? '',
            ];
        }

        $csv = implode("\r\n", array_map(function ($r) {
            return implode(',', array_map(function ($v) {
                return '"' . str_replace('"', '""', (string)$v) . '"';
            }, $r));
        }, $rows));

        wp_send_json_success(['csv' => $csv, 'count' => count($logs)]);
    }

    // ── Pages ─────────────────────────────────────────────────────────

    public static function render_settings_page(): void {
        $api_key        = get_option('waabek_api_key', '');
        $api_url        = get_option('waabek_api_url', 'https://waabek.com');
        $instance_id    = get_option('waabek_instance_id', '');
        $mode           = get_option('waabek_mode', 'wa_web');
        $enabled        = get_option('waabek_enabled', '1');
        $admin_notify   = get_option('waabek_admin_notify', '0');
        $admin_phone    = get_option('waabek_admin_phone', '');
        $admin_template = get_option('waabek_admin_template', "🛍️ New Order #{order_number}\nCustomer: {customer_name}\nTotal: {order_total}\nItems: {items_count}\nPayment: {payment_method}");
        $show_wa_field  = get_option('waabek_show_wa_field', '1');
        $events         = get_option('waabek_events', []);
        require_once WAABEK_WOO_DIR . 'templates/settings-page.php';
    }

    public static function render_templates_page(): void {
        $templates = WAABEK_Templates::get_all();
        $variables = WAABEK_Templates::get_variables_list();
        require_once WAABEK_WOO_DIR . 'templates/templates-page.php';
    }

    public static function render_logs_page(): void {
        // Pagination + filtering handled inside the template
        require_once WAABEK_WOO_DIR . 'templates/logs-page.php';
    }
}

<?php
if (!defined('ABSPATH')) exit;

class WAABEK_Notifications {

    private static bool $table_checked = false;

    public static function init(): void {
        if (!get_option('waabek_enabled', '1')) return;

        $event_hooks = [
            'new_order'        => 'woocommerce_checkout_order_created',
            'order_processing' => 'woocommerce_order_status_processing',
            'order_completed'  => 'woocommerce_order_status_completed',
            'order_cancelled'  => 'woocommerce_order_status_cancelled',
            'order_refunded'   => 'woocommerce_order_status_refunded',
            'order_on_hold'    => 'woocommerce_order_status_on-hold',
            'order_failed'     => 'woocommerce_order_status_failed',
        ];

        foreach ($event_hooks as $event => $hook) {
            add_action($hook, function ($order_or_id) use ($event) {
                self::handle($event, $order_or_id);
            }, 10, 1);
        }

        // Fix 3: Retry queue on admin_init
        add_action('admin_init', [__CLASS__, 'process_retry_queue']);

        // Fix 7: WooCommerce Bookings
        add_action('woocommerce_booking_confirmed', function ($booking_id) {
            if (!class_exists('WC_Booking')) return;
            $booking = new WC_Booking($booking_id);
            if ($booking && $booking->get_order()) {
                self::handle('order_completed', $booking->get_order());
            }
        }, 10, 1);

        // Fix 4: WooCommerce Subscriptions
        add_action('woocommerce_subscription_renewal_payment_complete', function ($subscription, $order) {
            self::handle('order_processing', $order);
        }, 10, 2);
        add_action('woocommerce_subscription_status_cancelled', function ($subscription) {
            $orders = $subscription->get_related_orders('all', 'renewal');
            if (!empty($orders)) {
                $last = wc_get_order(end($orders));
                if ($last) self::handle('order_cancelled', $last);
            }
        }, 10, 1);

        // Fix 5: Custom order statuses — only if processing template enabled
        add_action('woocommerce_order_status_changed', function ($order_id, $old_status, $new_status) {
            $core_statuses = ['processing','completed','cancelled','refunded','on-hold','failed','pending'];
            if (in_array($new_status, $core_statuses)) return;
            $events = get_option('waabek_events', []);
            if (($events['order_processing'] ?? '0') !== '1') return;
            self::handle('order_processing', $order_id);
        }, 10, 3);

        // Fix 7: Opt-out fields
        add_filter('woocommerce_checkout_fields',       [__CLASS__, 'add_optout_checkout_field']);
        add_action('woocommerce_checkout_create_order', [__CLASS__, 'save_optout_checkout_field'], 10, 2);
        add_action('woocommerce_save_account_details',  [__CLASS__, 'save_optout_account']);
        add_action('woocommerce_edit_account_form',     [__CLASS__, 'add_optout_account_field']);

        // WhatsApp custom field — only if enabled in settings
        if (get_option('waabek_show_wa_field', '1') === '1') {
            add_filter('woocommerce_checkout_fields',       [__CLASS__, 'add_whatsapp_checkout_field']);
            add_action('woocommerce_checkout_create_order', [__CLASS__, 'save_whatsapp_checkout_field'], 10, 2);
        }
    }

    public static function handle(string $event, $order_or_id): void {
        // Fix 1: extract order_id FIRST before using in lock key
        $order_id = ($order_or_id instanceof WC_Order)
            ? (int)$order_or_id->get_id()
            : (int)$order_or_id;
        if (!$order_id) return;

        // Rate limiting — deduplicate sends within 60 seconds
        $lock_key = "waabek_lock_{$event}_{$order_id}";
        if (get_transient($lock_key)) return;
        set_transient($lock_key, 1, 60);
        $tpl = WAABEK_Templates::get($event);
        if (!$tpl || empty($tpl['enabled'])) return;

        $order = ($order_or_id instanceof WC_Order)
            ? $order_or_id
            : wc_get_order($order_or_id);

        if (!$order || !($order instanceof WC_Order)) return;

        // Opt-out check
        $customer_id = $order->get_customer_id();
        if ($customer_id && get_user_meta($customer_id, 'waabek_optout', true) === '1') {
            self::log_entry($event, $order, '', '', 'skipped', 'Customer opted out');
            return;
        }
        if ($order->get_meta('_waabek_optout') === '1') {
            $order->add_order_note(__('WAABEK: Customer opted out of WhatsApp notifications.', 'waabek-woo'));
            self::log_entry($event, $order, '', '', 'skipped', 'Customer opted out');
            return;
        }

        $phone = self::get_phone($order);
        if (empty($phone)) {
            self::log_entry($event, $order, '', '', 'skipped', 'No phone number found');
            return;
        }

        $message = WAABEK_Templates::render($event, $order);
        if (empty($message)) return;

        $result = WAABEK_API::send_message($phone, $message);

        if ($result['success']) {
            $order->add_order_note(sprintf(
                __('✅ WAABEK WhatsApp sent to %s', 'waabek-woo'), $phone
            ));
            self::log_entry($event, $order, $phone, $message, 'sent', '');
        } else {
            $error = $result['error'] ?? 'Unknown error';
            $order->add_order_note(sprintf(
                __('❌ WAABEK WhatsApp failed (%s): %s', 'waabek-woo'), $phone, $error
            ));
            self::log_entry($event, $order, $phone, $message, 'failed', $error);
            if (empty($result['skip_retry'])) {
                self::add_to_retry_queue($event, $order, $phone, $message);
            }
        }

        // Fix 5+8: Admin notification — uses customizable template
        if ($event === 'new_order' && get_option('waabek_admin_notify', '0') === '1') {
            $admin_phone = get_option('waabek_admin_phone', '');
            $admin_phone = preg_replace('/[^0-9]/', '', $admin_phone);
            if (!empty($admin_phone)) {
                $admin_tpl = get_option('waabek_admin_template',
                    "🛍️ New Order #{order_number}\nCustomer: {customer_name}\nTotal: {order_total}\nItems: {items_count}\nPayment: {payment_method}"
                );
                $admin_msg = WAABEK_Templates::render_raw($admin_tpl, $order);
                WAABEK_API::send_message($admin_phone, $admin_msg);
            }
        }
    }

    // Fix 2: get phone — also checks custom WhatsApp field
    private static function get_phone(WC_Order $order): string {
        // 1. Custom WhatsApp field
        $phone = trim($order->get_meta('_waabek_whatsapp') ?? '');
        if (!empty($phone)) return preg_replace('/[^0-9]/', '', $phone);

        // 2. Billing phone
        $phone = trim($order->get_billing_phone() ?? '');
        if (!empty($phone)) return preg_replace('/[^0-9]/', '', $phone);

        // 3. Shipping phone (WC 5.6+)
        if (method_exists($order, 'get_shipping_phone')) {
            $phone = trim($order->get_shipping_phone() ?? '');
            if (!empty($phone)) return preg_replace('/[^0-9]/', '', $phone);
        }

        // 4. Custom meta keys used by popular themes
        foreach (['_billing_phone2', '_phone', 'whatsapp_number', '_whatsapp'] as $key) {
            $phone = trim($order->get_meta($key) ?? '');
            if (!empty($phone)) return preg_replace('/[^0-9]/', '', $phone);
        }

        // 5. User meta
        if ($order->get_customer_id()) {
            $phone = trim(get_user_meta($order->get_customer_id(), 'billing_phone', true) ?? '');
            if (!empty($phone)) return preg_replace('/[^0-9]/', '', $phone);
        }

        return '';
    }

    // Fix 2: Add WhatsApp number field to checkout
    public static function add_whatsapp_checkout_field(array $fields): array {
        $fields['billing']['waabek_whatsapp'] = [
            'type'        => 'tel',
            'label'       => __('WhatsApp Number', 'waabek-woo'),
            'placeholder' => __('If different from phone number', 'waabek-woo'),
            'required'    => false,
            'class'       => ['form-row-wide'],
            'priority'    => 115,
        ];
        return $fields;
    }

    public static function save_whatsapp_checkout_field(WC_Order $order, array $data): void {
        if (!empty($_POST['waabek_whatsapp'])) {
            $order->update_meta_data('_waabek_whatsapp', sanitize_text_field($_POST['waabek_whatsapp']));
        }
    }

    // Fix 7: Opt-out checkout field
    public static function add_optout_checkout_field(array $fields): array {
        $fields['billing']['waabek_optout'] = [
            'type'     => 'checkbox',
            'label'    => __('Do not send me WhatsApp order notifications', 'waabek-woo'),
            'required' => false,
            'class'    => ['form-row-wide', 'waabek-optout-field'],
            'priority' => 125,
            'default'  => 0,
        ];
        return $fields;
    }

    public static function save_optout_checkout_field(WC_Order $order, array $data): void {
        $optout = !empty($_POST['waabek_optout']) ? '1' : '0';
        $order->update_meta_data('_waabek_optout', $optout);
        if ($order->get_customer_id()) {
            update_user_meta($order->get_customer_id(), 'waabek_optout', $optout);
        }
    }

    public static function add_optout_account_field(): void {
        $optout = get_user_meta(get_current_user_id(), 'waabek_optout', true);
        ?>
        <fieldset class="waabek-account-optout">
            <legend><?php esc_html_e('WhatsApp Notifications', 'waabek-woo'); ?></legend>
            <p class="woocommerce-form-row form-row-wide">
                <label class="woocommerce-form__label woocommerce-form__label-for-checkbox">
                    <input type="checkbox" name="waabek_optout" value="1" <?php checked($optout, '1'); ?> class="woocommerce-form__input woocommerce-form__input-checkbox">
                    <span><?php esc_html_e('Do not send me WhatsApp order notifications', 'waabek-woo'); ?></span>
                </label>
            </p>
        </fieldset>
        <?php
    }

    public static function save_optout_account(int $user_id): void {
        update_user_meta($user_id, 'waabek_optout', !empty($_POST['waabek_optout']) ? '1' : '0');
    }

    // Logging to DB
    private static function log_entry(string $event, WC_Order $order, string $phone, string $message, string $status, string $error): void {
        global $wpdb;
        $table = $wpdb->prefix . 'waabek_logs';

        // Fix 4: check table once per request, not on every log entry
        if (!self::$table_checked) {
            if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
                waabek_create_tables();
            }
            self::$table_checked = true;
        }

        $wpdb->insert($table, [
            'event'      => $event,
            'order_id'   => $order->get_id() ?: null,
            'order_num'  => $order->get_order_number() ?: null,
            'phone'      => $phone ?: null,
            'message'    => $message ?: null,
            'status'     => $status,
            'error'      => $error ?: null,
            'created_at' => current_time('mysql'),
        ], ['%s','%d','%s','%s','%s','%s','%s','%s']);

        // Keep max 1000 rows
        $count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        if ($count > 1000) {
            $wpdb->query("DELETE FROM {$table} ORDER BY id ASC LIMIT " . ($count - 1000));
        }
    }

    // Fix 6: Retry queue in DB
    private static function add_to_retry_queue(string $event, WC_Order $order, string $phone, string $message): void {
        global $wpdb;
        $table = $wpdb->prefix . 'waabek_logs';
        // Mark with retry_count=0 — scheduler will pick it up
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET retry_count = 0 WHERE order_id = %d AND event = %s AND status = 'failed' ORDER BY id DESC LIMIT 1",
            $order->get_id(), $event
        ));
        // Store next retry time in options (lightweight)
        $queue   = get_option('waabek_retry_queue', []);
        $queue[] = [
            'order_id'    => $order->get_id(),
            'event'       => $event,
            'phone'       => $phone,
            'message'     => $message,
            'retry_count' => 0,
            'next_retry'  => time() + 300,
        ];
        update_option('waabek_retry_queue', $queue, false);
    }

    public static function process_retry_queue(): void {
        $queue = get_option('waabek_retry_queue', []);
        if (empty($queue)) return;

        $now = time();
        $remaining = [];

        global $wpdb;
        foreach ($queue as $item) {
            if ($item['retry_count'] >= 3) continue;
            if ($item['next_retry'] > $now) { $remaining[] = $item; continue; }

            $result = WAABEK_API::send_message($item['phone'], $item['message']);
            if ($result['success']) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}waabek_logs SET status='sent', retried_at=%s WHERE order_id=%d AND event=%s AND status='failed' LIMIT 1",
                    current_time('mysql'), $item['order_id'], $item['event']
                ));
            } else {
                $item['retry_count']++;
                $item['next_retry'] = time() + (300 * pow(2, $item['retry_count']));
                $remaining[] = $item;
            }
        }

        // Fix 6: remove items older than 24 hours
        $remaining = array_filter($remaining, function ($item) {
            return isset($item['next_retry']) && $item['next_retry'] > (time() - 86400);
        });
        update_option('waabek_retry_queue', array_values($remaining), false);
    }
}

<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap waabek-wrap">

    <div class="waabek-header">
        <div class="waabek-header-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.126.555 4.126 1.526 5.856L.057 23.882l6.206-1.447A11.946 11.946 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.817 9.817 0 01-5.002-1.373l-.359-.213-3.717.867.934-3.614-.234-.373A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
            <div>
                <h1><?php _e('Message Templates', 'waabek-woo'); ?></h1>
                <p><?php _e('Customize WhatsApp messages for each order event', 'waabek-woo'); ?></p>
            </div>
        </div>
        <div class="waabek-nav">
            <a href="?page=waabek-woo" class="waabek-nav-link"><?php _e('Settings', 'waabek-woo'); ?></a>
            <a href="?page=waabek-woo-templates" class="waabek-nav-link active"><?php _e('Templates', 'waabek-woo'); ?></a>
            <a href="?page=waabek-woo-logs" class="waabek-nav-link"><?php _e('Logs', 'waabek-woo'); ?></a>
        </div>
    </div>

    <div id="waabek-notice" class="waabek-notice" style="display:none;"></div>

    <!-- Variables Reference -->
    <div class="waabek-card waabek-vars-card">
        <div class="waabek-card-header">
            <span class="waabek-card-icon">📋</span>
            <h2><?php _e('Available Variables', 'waabek-woo'); ?></h2>
            <button type="button" class="waabek-toggle-vars waabek-btn waabek-btn-secondary waabek-btn-sm">
                <?php _e('Show / Hide', 'waabek-woo'); ?>
            </button>
        </div>
        <div class="waabek-vars-grid" id="waabek-vars-grid">
            <?php foreach ($variables as $var => $desc): ?>
            <div class="waabek-var-item">
                <code class="waabek-var-code" title="<?php _e('Click to copy', 'waabek-woo'); ?>"><?php echo esc_html($var); ?></code>
                <span><?php echo esc_html($desc); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Cloud API Notice -->
    <?php
    $mode = get_option('waabek_mode', 'wa_web');
    if ($mode === 'cloud_api'): ?>
    <div class="waabek-alert waabek-alert-warning">
        <strong>☁️ <?php _e('Cloud API Mode — Template Requirements', 'waabek-woo'); ?></strong>
        <p><?php _e('You are using Cloud API mode. Messages to customers who have not contacted you in the last 24 hours must use a Meta-approved template.', 'waabek-woo'); ?></p>
        <p><?php _e('Your approved templates must match this format — create them in Meta Business Manager with these variable names:', 'waabek-woo'); ?></p>
        <div class="waabek-code-block">
            <strong><?php _e('New Order / Processing / Completed template body:', 'waabek-woo'); ?></strong><br>
            <code>Hi {{customer_name}}, your order #{{order_number}} is {{order_status}}. Total: {{order_total}}. Thank you — {{shop_name}}</code>
        </div>
        <p><strong><?php _e('Required template parameters:', 'waabek-woo'); ?></strong> <code>customer_name</code>, <code>order_number</code>, <code>order_status</code>, <code>order_total</code>, <code>shop_name</code></p>
        <p>
            <?php _e('Manage templates at:', 'waabek-woo'); ?>
            <a href="https://business.facebook.com/wa/manage/message-templates/" target="_blank">Meta Business Manager → Message Templates</a>
            <?php _e('and', 'waabek-woo'); ?>
            <a href="https://waabek.com/dashboard/templates" target="_blank">WAABEK Dashboard → Templates</a>
        </p>
    </div>
    <?php endif; ?>

    <!-- Templates -->
    <?php foreach ($templates as $event => $tpl): ?>
    <div class="waabek-card waabek-template-card" data-event="<?php echo esc_attr($event); ?>">
        <div class="waabek-card-header">
            <div class="waabek-template-title">
                <h2><?php echo esc_html($tpl['label']); ?></h2>
                <span class="waabek-event-badge"><?php echo esc_html($event); ?></span>
            </div>
            <label class="waabek-toggle">
                <input type="checkbox" class="tpl-enabled" data-event="<?php echo esc_attr($event); ?>" value="1" <?php checked(!empty($tpl['enabled'])); ?>>
                <span class="waabek-toggle-slider"></span>
            </label>
        </div>
        <div class="waabek-template-body <?php echo empty($tpl['enabled']) ? 'waabek-disabled' : ''; ?>">
            <textarea class="waabek-textarea tpl-message" data-event="<?php echo esc_attr($event); ?>" rows="6"><?php echo esc_textarea($tpl['message']); ?></textarea>
            <div class="waabek-template-actions">
                <div style="display:flex;gap:8px;">
                    <button type="button" class="waabek-btn waabek-btn-ghost waabek-reset-tpl" data-event="<?php echo esc_attr($event); ?>">
                        🔄 <?php _e('Reset to Default', 'waabek-woo'); ?>
                    </button>
                    <button type="button" class="waabek-btn waabek-btn-secondary waabek-preview-tpl" data-event="<?php echo esc_attr($event); ?>">
                        👁 <?php _e('Preview', 'waabek-woo'); ?>
                    </button>
                </div>
                <div class="waabek-char-count">
                    <span class="char-count-num">0</span> <?php _e('chars', 'waabek-woo'); ?>
                </div>
            </div>
            <div class="waabek-preview-box" id="preview-<?php echo esc_attr($event); ?>" style="display:none;">
                <div class="waabek-preview-header">
                    <span>📱 <?php _e('Message Preview', 'waabek-woo'); ?></span>
                    <button type="button" class="waabek-close-preview" data-event="<?php echo esc_attr($event); ?>">✕</button>
                </div>
                <div class="waabek-preview-bubble"></div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="waabek-save-bar">
        <button type="button" id="waabek-save-tpl-btn" class="waabek-btn waabek-btn-primary waabek-btn-lg">
            💾 <?php _e('Save All Templates', 'waabek-woo'); ?>
        </button>
    </div>

</div>

<?php
if (!defined('ABSPATH')) exit;

// Pagination + filters
$per_page    = 50;
$current_page = max(1, (int)($_GET['paged'] ?? 1));
$allowed_statuses = ['sent', 'failed', 'skipped'];
$filter_status_raw = sanitize_text_field($_GET['status'] ?? '');
$filter_status = in_array($filter_status_raw, $allowed_statuses, true) ? $filter_status_raw : '';
$filter_search = sanitize_text_field($_GET['s']      ?? '');
$filter_date_raw = sanitize_text_field($_GET['date'] ?? '');
$filter_date     = (preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $filter_date_raw)) ? $filter_date_raw : '';

global $wpdb;
$table  = $wpdb->prefix . 'waabek_logs';
$exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;

$total_sent    = 0;
$total_failed  = 0;
$total_skipped = 0;
$total_all     = 0;
$logs          = [];

if ($exists) {
    // Stats
    $stats = $wpdb->get_results("SELECT status, COUNT(*) as cnt FROM {$table} GROUP BY status", ARRAY_A);
    foreach ($stats as $s) {
        if ($s['status'] === 'sent')    $total_sent    = (int)$s['cnt'];
        if ($s['status'] === 'failed')  $total_failed  = (int)$s['cnt'];
        if ($s['status'] === 'skipped') $total_skipped = (int)$s['cnt'];
        $total_all += (int)$s['cnt'];
    }
    $denominator  = $total_sent + $total_failed;
    $success_rate = $denominator > 0 ? round(($total_sent / $denominator) * 100) : 0;

    // Build WHERE
    $where  = ['1=1'];
    $params = [];
    if ($filter_status) { $where[] = 'status = %s'; $params[] = $filter_status; }
    if ($filter_search) { $where[] = '(order_num LIKE %s OR phone LIKE %s)'; $params[] = '%'.$filter_search.'%'; $params[] = '%'.$filter_search.'%'; }
    if ($filter_date)   { $where[] = 'DATE(created_at) = %s'; $params[] = $filter_date; }
    $where_sql = implode(' AND ', $where);

    // Count for pagination
    $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
    $total_rows = $params ? (int)$wpdb->get_var($wpdb->prepare($count_sql, ...$params)) : (int)$wpdb->get_var($count_sql);
    $total_pages = max(1, ceil($total_rows / $per_page));
    $offset      = ($current_page - 1) * $per_page;

    // Fetch logs
    $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";
    $all_params = array_merge($params, [$per_page, $offset]);
    $logs = $wpdb->get_results($wpdb->prepare($sql, ...$all_params), ARRAY_A);
} else {
    $total_pages = 1;
    $total_rows  = 0;
    $success_rate = 0;
}

$base_url = admin_url('admin.php?page=waabek-woo-logs');
?>
<div class="wrap waabek-wrap">

    <div class="waabek-header">
        <div class="waabek-header-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.126.555 4.126 1.526 5.856L.057 23.882l6.206-1.447A11.946 11.946 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.817 9.817 0 01-5.002-1.373l-.359-.213-3.717.867.934-3.614-.234-.373A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
            <div>
                <h1><?php _e('Message Logs', 'waabek-woo'); ?></h1>
                <p><?php printf(__('%d total log entries', 'waabek-woo'), $total_all); ?></p>
            </div>
        </div>
        <div class="waabek-nav">
            <a href="?page=waabek-woo"           class="waabek-nav-link"><?php _e('Settings',  'waabek-woo'); ?></a>
            <a href="?page=waabek-woo-templates" class="waabek-nav-link"><?php _e('Templates', 'waabek-woo'); ?></a>
            <a href="?page=waabek-woo-logs"      class="waabek-nav-link active"><?php _e('Logs', 'waabek-woo'); ?></a>
        </div>
    </div>

    <div id="waabek-notice" class="waabek-notice" style="display:none;"></div>

    <!-- Fix 5: Stats Summary -->
    <div class="waabek-stats-row">
        <div class="waabek-stat-card">
            <span class="waabek-stat-num"><?php echo $total_sent; ?></span>
            <span class="waabek-stat-label">✅ <?php _e('Sent', 'waabek-woo'); ?></span>
        </div>
        <div class="waabek-stat-card">
            <span class="waabek-stat-num waabek-red"><?php echo $total_failed; ?></span>
            <span class="waabek-stat-label">❌ <?php _e('Failed', 'waabek-woo'); ?></span>
        </div>
        <div class="waabek-stat-card">
            <span class="waabek-stat-num waabek-gray"><?php echo $total_skipped; ?></span>
            <span class="waabek-stat-label">⏭️ <?php _e('Skipped', 'waabek-woo'); ?></span>
        </div>
        <div class="waabek-stat-card">
            <span class="waabek-stat-num waabek-green"><?php echo $success_rate; ?>%</span>
            <span class="waabek-stat-label">📊 <?php _e('Success Rate', 'waabek-woo'); ?></span>
        </div>
    </div>

    <div class="waabek-card">
        <div class="waabek-card-header">
            <span class="waabek-card-icon">📋</span>
            <h2><?php _e('Message History', 'waabek-woo'); ?></h2>
            <div class="waabek-logs-toolbar">
                <!-- Fix 1+2+4: search + status + date filters -->
                <form method="get" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    <input type="hidden" name="page" value="waabek-woo-logs">
                    <input type="text" name="s" value="<?php echo esc_attr($filter_search); ?>"
                        placeholder="<?php _e('Order # or phone', 'waabek-woo'); ?>"
                        class="waabek-input waabek-input-sm" style="width:160px;">
                    <input type="date" name="date" value="<?php echo esc_attr($filter_date); ?>"
                        class="waabek-input waabek-input-sm" style="width:140px;">
                    <select name="status" class="waabek-select waabek-select-sm" style="width:120px;">
                        <option value=""><?php _e('All Status', 'waabek-woo'); ?></option>
                        <option value="sent"    <?php selected($filter_status,'sent');    ?>><?php _e('Sent',    'waabek-woo'); ?></option>
                        <option value="failed"  <?php selected($filter_status,'failed');  ?>><?php _e('Failed',  'waabek-woo'); ?></option>
                        <option value="skipped" <?php selected($filter_status,'skipped'); ?>><?php _e('Skipped', 'waabek-woo'); ?></option>
                    </select>
                    <button type="submit" class="waabek-btn waabek-btn-secondary waabek-btn-sm">🔍</button>
                    <?php if ($filter_status || $filter_search || $filter_date): ?>
                    <a href="<?php echo esc_url($base_url); ?>" class="waabek-btn waabek-btn-ghost waabek-btn-sm">✕ <?php _e('Clear', 'waabek-woo'); ?></a>
                    <?php endif; ?>
                </form>
                <div style="display:flex;gap:6px;">
                    <button type="button" id="waabek-export-logs" class="waabek-btn waabek-btn-secondary waabek-btn-sm">📥 <?php _e('Export CSV', 'waabek-woo'); ?></button>
                    <button type="button" id="waabek-clear-logs"  class="waabek-btn waabek-btn-ghost    waabek-btn-sm">🗑 <?php _e('Clear All', 'waabek-woo'); ?></button>
                </div>
            </div>
        </div>

        <table class="waabek-logs-table" id="waabek-logs-table">
            <thead>
                <tr>
                    <th><?php _e('Time', 'waabek-woo'); ?></th>
                    <th><?php _e('Order', 'waabek-woo'); ?></th>
                    <th><?php _e('Event', 'waabek-woo'); ?></th>
                    <th><?php _e('Phone', 'waabek-woo'); ?></th>
                    <th><?php _e('Status', 'waabek-woo'); ?></th>
                    <th><?php _e('Actions', 'waabek-woo'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                <tr>
                    <td colspan="6" style="text-align:center;padding:30px;color:#94a3b8;">
                        <?php _e('No logs found.', 'waabek-woo'); ?>
                    </td>
                </tr>
                <?php else: foreach ($logs as $log):
                    $status     = $log['status'] ?? 'unknown';
                    // Fix 6: HPOS-compatible order edit link
                    $order_edit_url = '';
                    if ($log['order_id']) {
                        $wc_order = wc_get_order($log['order_id']);
                        $order_edit_url = $wc_order ? $wc_order->get_edit_order_url() : get_edit_post_link($log['order_id']);
                    }
                    $order_link = $log['order_id']
                        ? '<a href="' . esc_url($order_edit_url) . '">#' . esc_html($log['order_num'] ?? $log['order_id']) . '</a>'
                        : '—';
                ?>
                <tr class="waabek-log-row" data-status="<?php echo esc_attr($status); ?>" data-id="<?php echo (int)$log['id']; ?>">
                    <td class="waabek-log-time"><?php echo esc_html($log['created_at'] ?? ''); ?></td>
                    <td><?php echo $order_link; ?></td>
                    <td><code class="waabek-event-code"><?php echo esc_html($log['event'] ?? ''); ?></code></td>
                    <td class="waabek-log-phone"><?php echo esc_html($log['phone'] ?? '—'); ?></td>
                    <td>
                        <span class="waabek-status-badge <?php echo esc_attr($status); ?>"><?php echo esc_html($status); ?></span>
                        <?php if (!empty($log['error'])): ?>
                        <div class="waabek-log-error"><?php echo esc_html($log['error']); ?></div>
                        <?php endif; ?>
                        <?php if (!empty($log['retried_at'])): ?>
                        <div class="waabek-log-retried"><?php printf(__('Retried: %s', 'waabek-woo'), esc_html($log['retried_at'])); ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($status === 'failed'): ?>
                        <button type="button" class="waabek-btn waabek-btn-ghost waabek-btn-sm waabek-retry-btn" data-id="<?php echo (int)$log['id']; ?>">
                            ↩ <?php _e('Retry', 'waabek-woo'); ?>
                        </button>
                        <?php else: ?>
                        <span style="color:#94a3b8;font-size:12px;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>

        <!-- Fix 1: Real pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="waabek-pagination-bar">
            <span class="waabek-pagination-info">
                <?php printf(__('Page %d of %d (%d records)', 'waabek-woo'), $current_page, $total_pages, $total_rows); ?>
            </span>
            <div class="waabek-pagination-links">
                <?php if ($current_page > 1): ?>
                <a href="<?php echo esc_url(add_query_arg(['paged' => 1,                  'status' => $filter_status, 's' => $filter_search, 'date' => $filter_date], $base_url)); ?>" class="waabek-btn waabek-btn-ghost waabek-btn-sm">«</a>
                <a href="<?php echo esc_url(add_query_arg(['paged' => $current_page - 1, 'status' => $filter_status, 's' => $filter_search, 'date' => $filter_date], $base_url)); ?>" class="waabek-btn waabek-btn-ghost waabek-btn-sm">‹</a>
                <?php endif; ?>
                <?php
                $start = max(1, $current_page - 2);
                $end   = min($total_pages, $current_page + 2);
                for ($p = $start; $p <= $end; $p++):
                ?>
                <a href="<?php echo esc_url(add_query_arg(['paged' => $p, 'status' => $filter_status, 's' => $filter_search, 'date' => $filter_date], $base_url)); ?>"
                   class="waabek-btn waabek-btn-sm <?php echo $p === $current_page ? 'waabek-btn-primary' : 'waabek-btn-ghost'; ?>">
                    <?php echo $p; ?>
                </a>
                <?php endfor; ?>
                <?php if ($current_page < $total_pages): ?>
                <a href="<?php echo esc_url(add_query_arg(['paged' => $current_page + 1, 'status' => $filter_status, 's' => $filter_search, 'date' => $filter_date], $base_url)); ?>" class="waabek-btn waabek-btn-ghost waabek-btn-sm">›</a>
                <a href="<?php echo esc_url(add_query_arg(['paged' => $total_pages,       'status' => $filter_status, 's' => $filter_search, 'date' => $filter_date], $base_url)); ?>" class="waabek-btn waabek-btn-ghost waabek-btn-sm">»</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

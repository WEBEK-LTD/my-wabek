<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap waabek-wrap">

    <div class="waabek-header">
        <div class="waabek-header-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.126.555 4.126 1.526 5.856L.057 23.882l6.206-1.447A11.946 11.946 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.817 9.817 0 01-5.002-1.373l-.359-.213-3.717.867.934-3.614-.234-.373A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
            <div>
                <h1><?php _e('WAABEK for WooCommerce', 'waabek-woo'); ?></h1>
                <p><?php _e('WhatsApp notifications for your store', 'waabek-woo'); ?></p>
            </div>
        </div>
        <div class="waabek-nav">
            <a href="?page=waabek-woo" class="waabek-nav-link active"><?php _e('Settings', 'waabek-woo'); ?></a>
            <a href="?page=waabek-woo-templates" class="waabek-nav-link"><?php _e('Templates', 'waabek-woo'); ?></a>
            <a href="?page=waabek-woo-logs" class="waabek-nav-link"><?php _e('Logs', 'waabek-woo'); ?></a>
        </div>
    </div>

    <div id="waabek-notice" class="waabek-notice" style="display:none;"></div>

    <div class="waabek-grid">

        <!-- API Settings -->
        <div class="waabek-card">
            <div class="waabek-card-header">
                <span class="waabek-card-icon">🔑</span>
                <h2><?php _e('API Connection', 'waabek-woo'); ?></h2>
            </div>

            <div class="waabek-field">
                <label><?php _e('WAABEK API Key', 'waabek-woo'); ?></label>
                <div class="waabek-input-group">
                    <input type="password" id="waabek_api_key" value="<?php echo esc_attr($api_key); ?>" placeholder="wabek_live_..." class="waabek-input">
                    <button type="button" class="waabek-btn waabek-btn-secondary waabek-toggle-password" data-target="waabek_api_key">
                        👁
                    </button>
                </div>
                <p class="waabek-hint">
                    <?php _e('Get your API key from', 'waabek-woo'); ?>
                    <a href="https://waabek.com/dashboard/settings" target="_blank"><?php _e('WAABEK Dashboard → Settings', 'waabek-woo'); ?></a>
                </p>
            </div>

            <div class="waabek-field">
                <label><?php _e('WAABEK API URL', 'waabek-woo'); ?></label>
                <input type="url" id="waabek_api_url" value="<?php echo esc_attr($api_url); ?>" placeholder="https://waabek.com" class="waabek-input">
                <p class="waabek-hint"><?php _e('Leave as default unless you have a custom domain.', 'waabek-woo'); ?></p>
            </div>

            <div class="waabek-field">
                <label><?php _e('Instance ID', 'waabek-woo'); ?> <span class="waabek-optional"><?php _e('(Optional)', 'waabek-woo'); ?></span></label>
                <input type="text" id="waabek_instance_id" value="<?php echo esc_attr($instance_id); ?>" placeholder="<?php _e('Leave empty to use default instance', 'waabek-woo'); ?>" class="waabek-input">
                <p class="waabek-hint"><?php _e('Get the instance ID from WAABEK Dashboard → WhatsApp Instances.', 'waabek-woo'); ?></p>
            </div>

            <div class="waabek-field">
                <label><?php _e('WhatsApp Mode', 'waabek-woo'); ?></label>
                <select id="waabek_mode" class="waabek-select">
                    <option value="wa_web" <?php selected($mode, 'wa_web'); ?>><?php _e('WhatsApp Web (Scan QR)', 'waabek-woo'); ?></option>
                    <option value="cloud_api" <?php selected($mode, 'cloud_api'); ?>><?php _e('Cloud API (Meta Business)', 'waabek-woo'); ?></option>
                </select>
                <div id="cloud_api_notice" class="waabek-alert waabek-alert-info" style="<?php echo $mode !== 'cloud_api' ? 'display:none;' : ''; ?> margin-top:10px;">
                    <strong><?php _e('Cloud API Mode', 'waabek-woo'); ?></strong>
                    <p><?php _e('When using Cloud API, messages sent to customers who have not contacted you in the last 24 hours must use an approved WhatsApp template. Make sure your templates are approved in Meta Business Manager.', 'waabek-woo'); ?></p>
                    <p><?php _e('Go to', 'waabek-woo'); ?> <a href="https://waabek.com/dashboard/templates" target="_blank"><?php _e('WAABEK Dashboard → Templates', 'waabek-woo'); ?></a> <?php _e('to manage approved templates.', 'waabek-woo'); ?></p>
                </div>
            </div>

            <div class="waabek-row">
                <button type="button" id="waabek-test-btn" class="waabek-btn waabek-btn-secondary">
                    ⚡ <?php _e('Test Connection', 'waabek-woo'); ?>
                </button>
                <div id="waabek-test-result" class="waabek-inline-result"></div>
            </div>
        </div>

        <!-- General Settings -->
        <div class="waabek-card">
            <div class="waabek-card-header">
                <span class="waabek-card-icon">⚙️</span>
                <h2><?php _e('General Settings', 'waabek-woo'); ?></h2>
            </div>

            <div class="waabek-field">
                <div class="waabek-toggle-row">
                    <div>
                        <strong><?php _e('Enable WhatsApp Notifications', 'waabek-woo'); ?></strong>
                        <p class="waabek-hint"><?php _e('Turn off to pause all WhatsApp notifications without uninstalling the plugin.', 'waabek-woo'); ?></p>
                    </div>
                    <label class="waabek-toggle">
                        <input type="checkbox" id="waabek_enabled" value="1" <?php checked($enabled, '1'); ?>>
                        <span class="waabek-toggle-slider"></span>
                    </label>
                </div>
            </div>

            <div class="waabek-divider"></div>

            <div class="waabek-toggle-row">
                <div>
                    <strong><?php _e('Show WhatsApp Number Field at Checkout', 'waabek-woo'); ?></strong>
                    <p class="waabek-hint"><?php _e('Adds an optional WhatsApp number field on the checkout page.', 'waabek-woo'); ?></p>
                </div>
                <label class="waabek-toggle">
                    <input type="checkbox" id="waabek_show_wa_field" value="1" <?php checked($show_wa_field, '1'); ?>>
                    <span class="waabek-toggle-slider"></span>
                </label>
            </div>

            <div class="waabek-divider"></div>

            <h3 class="waabek-section-title"><?php _e('Order Events', 'waabek-woo'); ?></h3>
            <p class="waabek-hint" style="margin-bottom:12px;"><?php _e('Choose which order events trigger a WhatsApp notification.', 'waabek-woo'); ?></p>

            <?php
            $event_labels = [
                'new_order'        => ['🛍️', __('New Order', 'waabek-woo'),        __('When a customer places a new order', 'waabek-woo')],
                'order_processing' => ['🔄', __('Order Processing', 'waabek-woo'), __('When payment is confirmed', 'waabek-woo')],
                'order_completed'  => ['✅', __('Order Completed', 'waabek-woo'),   __('When order is marked complete', 'waabek-woo')],
                'order_cancelled'  => ['❌', __('Order Cancelled', 'waabek-woo'),   __('When order is cancelled', 'waabek-woo')],
                'order_refunded'   => ['💸', __('Order Refunded', 'waabek-woo'),    __('When a refund is issued', 'waabek-woo')],
                'order_on_hold'    => ['⏸️', __('Order On Hold', 'waabek-woo'),     __('When order is put on hold', 'waabek-woo')],
                'order_failed'     => ['💔', __('Order Failed', 'waabek-woo'),      __('When payment fails', 'waabek-woo')],
            ];
            foreach ($event_labels as $ev => [$icon, $label, $desc]):
                $checked = isset($events[$ev]) ? $events[$ev] === '1' : ($ev === 'new_order' || $ev === 'order_processing' || $ev === 'order_completed' || $ev === 'order_cancelled' || $ev === 'order_refunded');
            ?>
            <div class="waabek-toggle-row waabek-event-row">
                <div class="waabek-event-label">
                    <span><?php echo esc_html($icon); ?></span>
                    <div>
                        <strong><?php echo esc_html($label); ?></strong>
                        <p class="waabek-hint"><?php echo esc_html($desc); ?></p>
                    </div>
                </div>
                <label class="waabek-toggle">
                    <input type="checkbox" name="events[<?php echo esc_attr($ev); ?>]" value="1" <?php checked($checked, true); ?> data-event="<?php echo esc_attr($ev); ?>">
                    <span class="waabek-toggle-slider"></span>
                </label>
            </div>
            <?php endforeach; ?>
        </div>

    </div>

    <!-- Test Message -->
    <div class="waabek-card" style="margin-top:20px;">
        <div class="waabek-card-header">
            <span class="waabek-card-icon">📤</span>
            <h2><?php _e('Send Test Message', 'waabek-woo'); ?></h2>
        </div>
        <div class="waabek-grid waabek-grid-2">
            <div class="waabek-field">
                <label><?php _e('Phone Number', 'waabek-woo'); ?></label>
                <input type="text" id="test_phone" placeholder="201234567890" class="waabek-input">
                <p class="waabek-hint"><?php _e('Include country code, no + sign. e.g. 201234567890', 'waabek-woo'); ?></p>
            </div>
            <div class="waabek-field">
                <label><?php _e('Message', 'waabek-woo'); ?></label>
                <input type="text" id="test_message" placeholder="<?php _e('Hello from WAABEK!', 'waabek-woo'); ?>" class="waabek-input">
            </div>
        </div>
        <div class="waabek-row">
            <button type="button" id="waabek-test-msg-btn" class="waabek-btn waabek-btn-primary">
                📱 <?php _e('Send Test Message', 'waabek-woo'); ?>
            </button>
            <div id="waabek-test-msg-result" class="waabek-inline-result"></div>
        </div>
    </div>

    <!-- Admin Notifications -->
    <div class="waabek-card" style="margin-top:16px;">
        <div class="waabek-card-header">
            <span class="waabek-card-icon">🔔</span>
            <h2><?php _e('Admin Notifications', 'waabek-woo'); ?></h2>
        </div>
        <div class="waabek-field">
            <div class="waabek-toggle-row">
                <div>
                    <strong><?php _e('Notify Admin on New Orders', 'waabek-woo'); ?></strong>
                    <p class="waabek-hint"><?php _e('Send yourself a WhatsApp message when a new order is placed.', 'waabek-woo'); ?></p>
                </div>
                <label class="waabek-toggle">
                    <input type="checkbox" id="waabek_admin_notify" value="1" <?php checked($admin_notify, '1'); ?>>
                    <span class="waabek-toggle-slider"></span>
                </label>
            </div>
        </div>
        <div class="waabek-field" id="admin_phone_field" style="<?php echo $admin_notify !== '1' ? 'display:none;' : ''; ?>">
            <label><?php _e('Admin WhatsApp Number', 'waabek-woo'); ?></label>
            <input type="text" id="waabek_admin_phone" value="<?php echo esc_attr($admin_phone); ?>" placeholder="201234567890" class="waabek-input">
            <p class="waabek-hint"><?php _e('Include country code, no + sign. e.g. 201234567890', 'waabek-woo'); ?></p>
            <label style="margin-top:12px;display:block;"><?php _e('Admin Notification Message', 'waabek-woo'); ?></label>
            <textarea id="waabek_admin_template" class="waabek-textarea" rows="4"><?php echo esc_textarea($admin_template); ?></textarea>
            <p class="waabek-hint"><?php _e('Supports all template variables. This message is sent to you when a new order arrives.', 'waabek-woo'); ?></p>
        </div>
    </div>

    <div class="waabek-save-bar">
        <button type="button" id="waabek-save-btn" class="waabek-btn waabek-btn-primary waabek-btn-lg">
            💾 <?php _e('Save Settings', 'waabek-woo'); ?>
        </button>
    </div>

</div>

=== WAABEK for WooCommerce ===
Contributors: webekltd
Tags: woocommerce, whatsapp, notifications, sms, order notifications
Requires at least: 5.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.0.0
WC requires at least: 3.0
WC tested up to: 10.9.4
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send automatic WhatsApp notifications to your customers for all WooCommerce order events.

== Description ==

WAABEK for WooCommerce connects your WooCommerce store to the WAABEK WhatsApp API, sending automatic WhatsApp messages to customers when their order status changes.

= Features =

* 7 order event notifications (New Order, Processing, Completed, Cancelled, Refunded, On Hold, Failed)
* WhatsApp Web and Cloud API (Meta Business) support
* Fully customizable message templates with 16+ variables
* Arabic and English default templates (auto-detected from WordPress locale)
* Admin WhatsApp notifications for new orders
* Customer opt-out via checkout and account page
* Message logs with retry support
* WooCommerce Subscriptions compatible
* HPOS (Custom Order Tables) compatible
* Multisite compatible

= Available Template Variables =

{customer_name}, {first_name}, {last_name}, {order_number}, {order_total}, {order_status}, {order_date}, {order_url}, {payment_method}, {shop_name}, {shop_url}, {shipping_method}, {billing_address}, {items_count}, {items_list}, {currency}

= Requirements =

* WordPress 5.0+
* WooCommerce 3.0+
* PHP 7.4+
* Active WAABEK account at [waabek.com](https://waabek.com)

== Installation ==

1. Upload the plugin ZIP via Plugins → Add New → Upload Plugin
2. Activate the plugin
3. Go to **WAABEK WA → Settings**
4. Enter your API Key from [WAABEK Dashboard → Settings](https://waabek.com/dashboard/settings)
5. Click **Test Connection** to verify
6. Customize your message templates under **WAABEK WA → Templates**

== Frequently Asked Questions ==

= Where do I get my API key? =
Log in to your WAABEK account at [waabek.com](https://waabek.com) and go to Dashboard → Settings → API Key.

= Does this work with WhatsApp Business Cloud API? =
Yes. Select "Cloud API (Meta Business)" in the plugin settings. Note that messages to customers outside the 24-hour window require approved WhatsApp templates.

= Can customers opt out of WhatsApp notifications? =
Yes. A checkbox appears on the checkout page and in the customer account page.

= Is WooCommerce Subscriptions supported? =
Yes. Renewal payments and subscription cancellations trigger WhatsApp notifications.

= Does this work on WordPress Multisite? =
Yes. The plugin creates a separate database table for each site in the network.

== Changelog ==

= 2.0.0 =
* Initial release

== Upgrade Notice ==

= 2.0.0 =
Initial release.

== Developer ==

Developed by [WEBEK LTD](https://webek.uk)

<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

global $wpdb;

// Remove all plugin options
$options = [
    'waabek_api_key', 'waabek_api_url', 'waabek_instance_id',
    'waabek_mode', 'waabek_enabled', 'waabek_events', 'waabek_templates',
    'waabek_retry_queue', 'waabek_admin_notify', 'waabek_admin_phone',
    'waabek_admin_template',
    'waabek_show_wa_field',
    'waabek_woo_db_version',
];
foreach ($options as $opt) {
    delete_option($opt);
}

// Remove DB table — multisite aware
if (is_multisite()) {
    $sites = get_sites(['fields' => 'ids']);
    foreach ($sites as $site_id) {
        switch_to_blog($site_id);
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}waabek_logs");
        restore_current_blog();
    }
} else {
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}waabek_logs");
}

// Remove user meta
delete_metadata('user', 0, 'waabek_optout', '', true);

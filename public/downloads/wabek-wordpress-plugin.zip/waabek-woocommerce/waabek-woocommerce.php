<?php
/**
 * Plugin Name: WAABEK for WooCommerce
 * Plugin URI:  https://waabek.com
 * Description: Send WhatsApp notifications to customers for all WooCommerce order events.
 * Version:     2.0.0
 * Author:      WEBEK LTD
 * Author URI:  https://webek.uk
 * License:     GPL-2.0+
 * Text Domain: waabek-woo
 * Domain Path: /languages
 * WC requires at least: 3.0
 * WC tested up to: 10.9.4
 * Requires PHP: 7.4
 * Requires at least: 5.0
 */

if (!defined('ABSPATH')) exit;

define('WAABEK_WOO_VERSION', '2.0.0');
define('WAABEK_WOO_FILE',    __FILE__);
define('WAABEK_WOO_DIR',     plugin_dir_path(__FILE__));
define('WAABEK_WOO_URL',     plugin_dir_url(__FILE__));
define('WAABEK_WOO_DB_VERSION', '2');  // bump when schema changes

// HPOS compatibility
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// Create/upgrade DB table — multisite aware
function waabek_create_tables(): void {
    global $wpdb;
    // Fix 9: Multisite — use per-site table prefix
    $table   = $wpdb->prefix . 'waabek_logs';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        event       VARCHAR(50)  NOT NULL DEFAULT '',
        order_id    BIGINT UNSIGNED DEFAULT NULL,
        order_num   VARCHAR(50)  DEFAULT NULL,
        phone       VARCHAR(30)  DEFAULT NULL,
        message     TEXT,
        status      VARCHAR(20)  NOT NULL DEFAULT 'sent',
        error       TEXT,
        retried_at  DATETIME DEFAULT NULL,
        retry_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_status (status),
        KEY idx_order_id (order_id),
        KEY idx_created_at (created_at)
    ) {$charset};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Fix 5: version upgrade handler with proper version_compare
function waabek_maybe_upgrade(): void {
    $installed = get_option('waabek_woo_db_version', '0');
    if (version_compare($installed, WAABEK_WOO_DB_VERSION, '<')) {
        waabek_create_tables();
        // Future schema migrations go here:
        // if (version_compare($installed, '2', '<')) { ... }
        update_option('waabek_woo_db_version', WAABEK_WOO_DB_VERSION);
    }
}
add_action('plugins_loaded', 'waabek_maybe_upgrade', 5);

// Activation
register_activation_hook(__FILE__, function () {
    waabek_create_tables();

    $defaults = [
        'waabek_api_key'       => '',
        'waabek_api_url'       => 'https://waabek.com',
        'waabek_instance_id'   => '',
        'waabek_mode'          => 'wa_web',
        'waabek_enabled'       => '1',
        'waabek_admin_notify'   => '0',
        'waabek_admin_phone'    => '',
        'waabek_show_wa_field'  => '1',
        'waabek_admin_template' => "🛍️ New Order #{order_number}\nCustomer: {customer_name}\nTotal: {order_total}\nItems: {items_count}\nPayment: {payment_method}",
        'waabek_templates'     => [],
        'waabek_events'        => [
            'new_order'        => '1',
            'order_processing' => '1',
            'order_completed'  => '1',
            'order_cancelled'  => '1',
            'order_refunded'   => '1',
            'order_on_hold'    => '0',
            'order_failed'     => '0',
        ],
    ];
    foreach ($defaults as $key => $val) {
        if (get_option($key) === false) update_option($key, $val);
    }
});

// Fix 9: Multisite — run table creation on new site
add_action('wp_initialize_site', function ($new_site) {
    switch_to_blog($new_site->blog_id);
    waabek_create_tables();
    restore_current_blog();
});

// Uninstall is handled by uninstall.php

// Load plugin
add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>'
                . esc_html__('WAABEK for WooCommerce requires WooCommerce to be installed and active.', 'waabek-woo')
                . '</p></div>';
        });
        return;
    }
    load_plugin_textdomain('waabek-woo', false, dirname(plugin_basename(__FILE__)) . '/languages');
    require_once WAABEK_WOO_DIR . 'includes/class-waabek-api.php';
    require_once WAABEK_WOO_DIR . 'includes/class-waabek-templates.php';
    require_once WAABEK_WOO_DIR . 'includes/class-waabek-notifications.php';
    require_once WAABEK_WOO_DIR . 'includes/class-waabek-admin.php';
    WAABEK_Admin::init();
    WAABEK_Notifications::init();
}, 10);
